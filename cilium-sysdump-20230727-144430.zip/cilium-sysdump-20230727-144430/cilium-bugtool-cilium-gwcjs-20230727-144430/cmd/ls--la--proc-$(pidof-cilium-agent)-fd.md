total 0
dr-x------ 2 root root  0 Jul 27 06:41 .
dr-xr-xr-x 9 root root  0 Jul 27 06:41 ..
lrwx------ 1 root root 64 Jul 27 06:41 0 -> /dev/null
l-wx------ 1 root root 64 Jul 27 06:41 1 -> pipe:[7754543]
lrwx------ 1 root root 64 Jul 27 06:41 10 -> anon_inode:bpf-map
lrwx------ 1 root root 64 Jul 27 06:44 11 -> anon_inode:bpf-map
lrwx------ 1 root root 64 Jul 27 06:44 12 -> anon_inode:bpf-map
lrwx------ 1 root root 64 Jul 27 06:44 13 -> anon_inode:bpf-map
lrwx------ 1 root root 64 Jul 27 06:44 14 -> anon_inode:bpf-map
lrwx------ 1 root root 64 Jul 27 06:44 15 -> anon_inode:bpf-map
lrwx------ 1 root root 64 Jul 27 06:44 16 -> socket:[7761041]
lrwx------ 1 root root 64 Jul 27 06:44 17 -> socket:[7755383]
lrwx------ 1 root root 64 Jul 27 06:44 18 -> socket:[7759968]
lrwx------ 1 root root 64 Jul 27 06:44 19 -> socket:[7759969]
l-wx------ 1 root root 64 Jul 27 06:41 2 -> pipe:[7754544]
lrwx------ 1 root root 64 Jul 27 06:44 20 -> socket:[7759159]
lrwx------ 1 root root 64 Jul 27 06:41 3 -> anon_inode:[eventpoll]
lr-x------ 1 root root 64 Jul 27 06:41 4 -> pipe:[7757226]
l-wx------ 1 root root 64 Jul 27 06:41 5 -> pipe:[7757226]
lrwx------ 1 root root 64 Jul 27 06:41 6 -> socket:[7760960]
lrwx------ 1 root root 64 Jul 27 06:41 7 -> socket:[7754555]
lrwx------ 1 root root 64 Jul 27 06:41 8 -> socket:[7759156]
lrwx------ 1 root root 64 Jul 27 06:41 9 -> anon_inode:bpf-map
