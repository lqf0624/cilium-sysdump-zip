alloc: 6.63MB (6954064 bytes)
total-alloc: 13.85MB (14520936 bytes)
sys: 24.41MB (25600167 bytes)
lookups: 0
mallocs: 86386
frees: 58305
heap-alloc: 6.63MB (6954064 bytes)
heap-sys: 14.88MB (15597568 bytes)
heap-idle: 5.47MB (5734400 bytes)
heap-in-use: 9.41MB (9863168 bytes)
heap-released: 3.46MB (3629056 bytes)
heap-objects: 28081
stack-in-use: 1.12MB (1179648 bytes)
stack-sys: 1.12MB (1179648 bytes)
stack-mspan-inuse: 155.79KB (159528 bytes)
stack-mspan-sys: 160.00KB (163840 bytes)
stack-mcache-inuse: 9.38KB (9600 bytes)
stack-mcache-sys: 16.00KB (16384 bytes)
other-sys: 1.43MB (1497857 bytes)
gc-sys: 5.34MB (5604136 bytes)
next-gc: when heap-alloc >= 10.89MB (11420736 bytes)
last-gc: 2023-07-27 06:43:52.195656864 +0000 UTC
gc-pause-total: 1.654129ms
gc-pause: 610127
gc-pause-end: 1690440232195656864
num-gc: 5
num-forced-gc: 0
gc-cpu-fraction: 6.428402696625559e-05
enable-gc: true
debug-gc: false
