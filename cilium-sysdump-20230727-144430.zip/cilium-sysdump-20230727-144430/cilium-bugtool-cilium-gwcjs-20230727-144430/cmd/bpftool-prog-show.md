504: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2023-07-25T10:47:32+0000  uid 0
	xlated 64B  jited 41B  memlock 4096B
507: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2023-07-25T10:47:36+0000  uid 0
	xlated 64B  jited 41B  memlock 4096B
11625: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2023-07-25T12:45:37+0000  uid 0
	xlated 64B  jited 41B  memlock 4096B
11674: cgroup_device  tag e3dbd137be8d6168  gpl
	loaded_at 2023-07-25T22:53:16+0000  uid 0
	xlated 504B  jited 310B  memlock 4096B
11675: cgroup_skb  tag 6deef7357e7b4530  gpl
	loaded_at 2023-07-25T22:53:16+0000  uid 0
	xlated 64B  jited 55B  memlock 4096B
11676: cgroup_skb  tag 6deef7357e7b4530  gpl
	loaded_at 2023-07-25T22:53:16+0000  uid 0
	xlated 64B  jited 55B  memlock 4096B
11678: cgroup_device  tag 8b9c33f36f812014  gpl
	loaded_at 2023-07-25T22:53:16+0000  uid 0
	xlated 744B  jited 448B  memlock 4096B
11679: cgroup_skb  tag 6deef7357e7b4530  gpl
	loaded_at 2023-07-25T22:53:16+0000  uid 0
	xlated 64B  jited 55B  memlock 4096B
11680: cgroup_skb  tag 6deef7357e7b4530  gpl
	loaded_at 2023-07-25T22:53:16+0000  uid 0
	xlated 64B  jited 55B  memlock 4096B
11683: cgroup_device  tag c8b47a902f1cc68b  gpl
	loaded_at 2023-07-25T22:53:16+0000  uid 0
	xlated 464B  jited 289B  memlock 4096B
11684: cgroup_device  tag 0ecd07b7b633809f  gpl
	loaded_at 2023-07-25T22:53:16+0000  uid 0
	xlated 496B  jited 308B  memlock 4096B
11685: cgroup_skb  tag 6deef7357e7b4530  gpl
	loaded_at 2023-07-25T22:53:16+0000  uid 0
	xlated 64B  jited 55B  memlock 4096B
11686: cgroup_skb  tag 6deef7357e7b4530  gpl
	loaded_at 2023-07-25T22:53:16+0000  uid 0
	xlated 64B  jited 55B  memlock 4096B
11687: cgroup_device  tag e3dbd137be8d6168  gpl
	loaded_at 2023-07-25T22:53:16+0000  uid 0
	xlated 504B  jited 310B  memlock 4096B
11688: cgroup_device  tag 28a890580b33b0dc  gpl
	loaded_at 2023-07-25T22:53:16+0000  uid 0
	xlated 560B  jited 352B  memlock 4096B
11808: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2023-07-27T06:40:58+0000  uid 0
	xlated 64B  jited 41B  memlock 4096B
11809: cgroup_device  tag 81dfab3bd7eb416a  gpl
	loaded_at 2023-07-27T06:41:15+0000  uid 0
	xlated 472B  jited 295B  memlock 4096B
11812: cgroup_device  tag ab4bc4523b7fe6b4
	loaded_at 2023-07-27T06:41:15+0000  uid 0
	xlated 552B  jited 357B  memlock 4096B
11825: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2023-07-27T06:41:47+0000  uid 0
	xlated 64B  jited 41B  memlock 4096B
12579: cgroup_device  tag 81dfab3bd7eb416a  gpl
	loaded_at 2023-07-27T06:43:04+0000  uid 0
	xlated 472B  jited 295B  memlock 4096B
12582: cgroup_device  tag ab4bc4523b7fe6b4
	loaded_at 2023-07-27T06:43:04+0000  uid 0
	xlated 552B  jited 357B  memlock 4096B
