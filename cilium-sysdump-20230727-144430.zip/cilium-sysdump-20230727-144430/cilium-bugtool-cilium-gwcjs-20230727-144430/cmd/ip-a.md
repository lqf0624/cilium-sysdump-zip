1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host 
       valid_lft forever preferred_lft forever
2: ens3: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc fq_codel state UP group default qlen 1000
    link/ether fa:16:3e:78:1f:af brd ff:ff:ff:ff:ff:ff
    altname enp0s3
    inet 10.26.65.226/24 metric 100 brd 10.26.65.255 scope global dynamic ens3
       valid_lft 55790sec preferred_lft 55790sec
    inet6 fe80::f816:3eff:fe78:1faf/64 scope link 
       valid_lft forever preferred_lft forever
3: docker0: <NO-CARRIER,BROADCAST,MULTICAST,UP> mtu 1500 qdisc noqueue state DOWN group default 
    link/ether 02:42:5b:a0:b7:df brd ff:ff:ff:ff:ff:ff
    inet 172.17.0.1/16 brd 172.17.255.255 scope global docker0
       valid_lft forever preferred_lft forever
7: vxlan.calico: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1450 qdisc noqueue state UNKNOWN group default 
    link/ether 66:1c:82:36:23:65 brd ff:ff:ff:ff:ff:ff
    inet 10.244.249.64/32 scope global vxlan.calico
       valid_lft forever preferred_lft forever
    inet6 fe80::641c:82ff:fe36:2365/64 scope link 
       valid_lft forever preferred_lft forever
