USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root          94  0.0  0.0 709384  6668 ?        Ssl  06:44   0:00 cilium-bugtool --archiveType=gz
root         114  0.0  0.0   5900  2884 ?        R    06:44   0:00  \_ ps auxfw
root         116  0.0  0.0   6052   972 ?        R    06:44   0:00  \_ ip -4 n
root         117  0.0  0.0   6052   908 ?        R    06:44   0:00  \_ ip -d -s l
root         119  0.0  0.0   1596   304 ?        R    06:44   0:00  \_ ip -4 r
root         121  0.0  0.0   1776   468 ?        R    06:44   0:00  \_ bash -c ip -6 r
root           1  0.5  0.4 782660 68928 ?        Ssl  06:41   0:00 cilium-agent --config-dir=/tmp/cilium/config-map
