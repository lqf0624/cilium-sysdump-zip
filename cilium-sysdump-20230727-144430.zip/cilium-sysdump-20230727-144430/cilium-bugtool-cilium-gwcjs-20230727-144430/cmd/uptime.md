 06:44:38 up 3 days,  3:57,  0 users,  load average: 0.80, 1.79, 1.86
