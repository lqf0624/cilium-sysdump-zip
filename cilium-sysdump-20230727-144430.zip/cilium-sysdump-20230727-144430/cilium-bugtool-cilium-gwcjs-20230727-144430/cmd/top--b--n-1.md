top - 06:44:38 up 3 days,  3:57,  0 users,  load average: 0.80, 1.79, 1.86
Tasks:  11 total,   7 running,   4 sleeping,   0 stopped,   0 zombie
%Cpu(s):  8.9 us, 19.5 sy,  0.0 ni, 70.7 id,  0.0 wa,  0.0 hi,  0.8 si,  0.0 st
MiB Mem :  15622.6 total,   9344.8 free,    657.6 used,   5620.2 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.  14630.5 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
     94 root      20   0  709640   7372   5288 S  20.0   0.0   0:00.09 cilium-+
    128 root      20   0    5972   3240   2816 R   6.7   0.0   0:00.01 top
      1 root      20   0  782660  68928  49204 S   0.0   0.4   0:00.97 cilium-+
    143 root      20   0  703992    984    892 R   0.0   0.0   0:00.00 gops
    147 root      20   0  700724      4      0 R   0.0   0.0   0:00.00 gops
    148 root      20   0    3984   2948   2720 S   0.0   0.0   0:00.00 bash
    151 root      20   0    2508    580    516 R   0.0   0.0   0:00.00 pidof
    152 root      20   0    3984   2872   2644 S   0.0   0.0   0:00.00 bash
    153 root      20   0    3904   1020    876 R   0.0   0.0   0:00.00 bash
    154 root      20   0    3780    476    420 R   0.0   0.0   0:00.00 bash
    155 root      20   0    3780    472    416 R   0.0   0.0   0:00.00 bash
