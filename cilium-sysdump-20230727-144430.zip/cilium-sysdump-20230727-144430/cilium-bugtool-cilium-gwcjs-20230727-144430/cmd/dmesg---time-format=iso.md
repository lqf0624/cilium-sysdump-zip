2023-07-24T02:47:29,000000+00:00 Linux version 5.15.0-67-generic (buildd@lcy02-amd64-116) (gcc (Ubuntu 11.3.0-1ubuntu1~22.04) 11.3.0, GNU ld (GNU Binutils for Ubuntu) 2.38) #74-Ubuntu SMP Wed Feb 22 14:14:39 UTC 2023 (Ubuntu 5.15.0-67.74-generic 5.15.85)
2023-07-24T02:47:29,000000+00:00 Command line: BOOT_IMAGE=/boot/vmlinuz-5.15.0-67-generic root=LABEL=cloudimg-rootfs ro console=tty1 console=ttyS0
2023-07-24T02:47:29,000000+00:00 KERNEL supported cpus:
2023-07-24T02:47:29,000000+00:00   Intel GenuineIntel
2023-07-24T02:47:29,000000+00:00   AMD AuthenticAMD
2023-07-24T02:47:29,000000+00:00   Hygon HygonGenuine
2023-07-24T02:47:29,000000+00:00   Centaur CentaurHauls
2023-07-24T02:47:29,000000+00:00   zhaoxin   Shanghai  
2023-07-24T02:47:29,000000+00:00 x86/fpu: Supporting XSAVE feature 0x001: 'x87 floating point registers'
2023-07-24T02:47:29,000000+00:00 x86/fpu: Supporting XSAVE feature 0x002: 'SSE registers'
2023-07-24T02:47:29,000000+00:00 x86/fpu: Supporting XSAVE feature 0x004: 'AVX registers'
2023-07-24T02:47:29,000000+00:00 x86/fpu: xstate_offset[2]:  576, xstate_sizes[2]:  256
2023-07-24T02:47:29,000000+00:00 x86/fpu: Enabled xstate features 0x7, context size is 832 bytes, using 'standard' format.
2023-07-24T02:47:29,000000+00:00 signal: max sigframe size: 1776
2023-07-24T02:47:29,000000+00:00 BIOS-provided physical RAM map:
2023-07-24T02:47:29,000000+00:00 BIOS-e820: [mem 0x0000000000000000-0x000000000009fbff] usable
2023-07-24T02:47:29,000000+00:00 BIOS-e820: [mem 0x000000000009fc00-0x000000000009ffff] reserved
2023-07-24T02:47:29,000000+00:00 BIOS-e820: [mem 0x00000000000f0000-0x00000000000fffff] reserved
2023-07-24T02:47:29,000000+00:00 BIOS-e820: [mem 0x0000000000100000-0x00000000bffdbfff] usable
2023-07-24T02:47:29,000000+00:00 BIOS-e820: [mem 0x00000000bffdc000-0x00000000bfffffff] reserved
2023-07-24T02:47:29,000000+00:00 BIOS-e820: [mem 0x00000000feffc000-0x00000000feffffff] reserved
2023-07-24T02:47:29,000000+00:00 BIOS-e820: [mem 0x00000000fffc0000-0x00000000ffffffff] reserved
2023-07-24T02:47:29,000000+00:00 BIOS-e820: [mem 0x0000000100000000-0x0000000427ffffff] usable
2023-07-24T02:47:29,000000+00:00 NX (Execute Disable) protection: active
2023-07-24T02:47:29,000000+00:00 SMBIOS 2.8 present.
2023-07-24T02:47:29,000000+00:00 DMI: OpenStack Foundation OpenStack Nova, BIOS 1.10.2-1ubuntu1 04/01/2014
2023-07-24T02:47:29,000000+00:00 Hypervisor detected: KVM
2023-07-24T02:47:29,000000+00:00 kvm-clock: Using msrs 4b564d01 and 4b564d00
2023-07-24T02:47:29,000000+00:00 kvm-clock: cpu 0, msr 300201001, primary cpu clock
2023-07-24T02:47:29,000007+00:00 kvm-clock: using sched offset of 3164177233 cycles
2023-07-24T02:47:29,000021+00:00 clocksource: kvm-clock: mask: 0xffffffffffffffff max_cycles: 0x1cd42e4dffb, max_idle_ns: 881590591483 ns
2023-07-24T02:47:29,000031+00:00 tsc: Detected 1999.993 MHz processor
2023-07-24T02:47:29,001277+00:00 e820: update [mem 0x00000000-0x00000fff] usable ==> reserved
2023-07-24T02:47:29,001283+00:00 e820: remove [mem 0x000a0000-0x000fffff] usable
2023-07-24T02:47:29,001297+00:00 last_pfn = 0x428000 max_arch_pfn = 0x400000000
2023-07-24T02:47:29,001405+00:00 x86/PAT: Configuration [0-7]: WB  WC  UC- UC  WB  WP  UC- WT  
2023-07-24T02:47:29,001460+00:00 last_pfn = 0xbffdc max_arch_pfn = 0x400000000
2023-07-24T02:47:29,020707+00:00 found SMP MP-table at [mem 0x000f69f0-0x000f69ff]
2023-07-24T02:47:29,020767+00:00 Using GB pages for direct mapping
2023-07-24T02:47:29,021332+00:00 RAMDISK: [mem 0x34257000-0x36122fff]
2023-07-24T02:47:29,021361+00:00 ACPI: Early table checksum verification disabled
2023-07-24T02:47:29,021395+00:00 ACPI: RSDP 0x00000000000F69A0 000014 (v00 BOCHS )
2023-07-24T02:47:29,021406+00:00 ACPI: RSDT 0x00000000BFFE1460 00002C (v01 BOCHS  BXPCRSDT 00000001 BXPC 00000001)
2023-07-24T02:47:29,021434+00:00 ACPI: FACP 0x00000000BFFE12BC 000074 (v01 BOCHS  BXPCFACP 00000001 BXPC 00000001)
2023-07-24T02:47:29,021455+00:00 ACPI: DSDT 0x00000000BFFDFC80 00163C (v01 BOCHS  BXPCDSDT 00000001 BXPC 00000001)
2023-07-24T02:47:29,021468+00:00 ACPI: FACS 0x00000000BFFDFC40 000040
2023-07-24T02:47:29,021477+00:00 ACPI: APIC 0x00000000BFFE13B0 0000B0 (v01 BOCHS  BXPCAPIC 00000001 BXPC 00000001)
2023-07-24T02:47:29,021484+00:00 ACPI: Reserving FACP table memory at [mem 0xbffe12bc-0xbffe132f]
2023-07-24T02:47:29,021487+00:00 ACPI: Reserving DSDT table memory at [mem 0xbffdfc80-0xbffe12bb]
2023-07-24T02:47:29,021489+00:00 ACPI: Reserving FACS table memory at [mem 0xbffdfc40-0xbffdfc7f]
2023-07-24T02:47:29,021492+00:00 ACPI: Reserving APIC table memory at [mem 0xbffe13b0-0xbffe145f]
2023-07-24T02:47:29,022445+00:00 No NUMA configuration found
2023-07-24T02:47:29,022450+00:00 Faking a node at [mem 0x0000000000000000-0x0000000427ffffff]
2023-07-24T02:47:29,022471+00:00 NODE_DATA(0) allocated [mem 0x427fd6000-0x427ffffff]
2023-07-24T02:47:29,023954+00:00 Zone ranges:
2023-07-24T02:47:29,023957+00:00   DMA      [mem 0x0000000000001000-0x0000000000ffffff]
2023-07-24T02:47:29,023961+00:00   DMA32    [mem 0x0000000001000000-0x00000000ffffffff]
2023-07-24T02:47:29,023964+00:00   Normal   [mem 0x0000000100000000-0x0000000427ffffff]
2023-07-24T02:47:29,023968+00:00   Device   empty
2023-07-24T02:47:29,023970+00:00 Movable zone start for each node
2023-07-24T02:47:29,023975+00:00 Early memory node ranges
2023-07-24T02:47:29,023977+00:00   node   0: [mem 0x0000000000001000-0x000000000009efff]
2023-07-24T02:47:29,023979+00:00   node   0: [mem 0x0000000000100000-0x00000000bffdbfff]
2023-07-24T02:47:29,023982+00:00   node   0: [mem 0x0000000100000000-0x0000000427ffffff]
2023-07-24T02:47:29,023987+00:00 Initmem setup node 0 [mem 0x0000000000001000-0x0000000427ffffff]
2023-07-24T02:47:29,024763+00:00 On node 0, zone DMA: 1 pages in unavailable ranges
2023-07-24T02:47:29,024824+00:00 On node 0, zone DMA: 97 pages in unavailable ranges
2023-07-24T02:47:29,169405+00:00 On node 0, zone Normal: 36 pages in unavailable ranges
2023-07-24T02:47:29,170620+00:00 ACPI: PM-Timer IO Port: 0x608
2023-07-24T02:47:29,170669+00:00 ACPI: LAPIC_NMI (acpi_id[0xff] dfl dfl lint[0x1])
2023-07-24T02:47:29,170759+00:00 IOAPIC[0]: apic_id 0, version 17, address 0xfec00000, GSI 0-23
2023-07-24T02:47:29,170768+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 0 global_irq 2 dfl dfl)
2023-07-24T02:47:29,170776+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 5 global_irq 5 high level)
2023-07-24T02:47:29,170779+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 9 global_irq 9 high level)
2023-07-24T02:47:29,170802+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 10 global_irq 10 high level)
2023-07-24T02:47:29,170805+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 11 global_irq 11 high level)
2023-07-24T02:47:29,170814+00:00 ACPI: Using ACPI (MADT) for SMP configuration information
2023-07-24T02:47:29,170825+00:00 TSC deadline timer available
2023-07-24T02:47:29,170840+00:00 smpboot: Allowing 8 CPUs, 0 hotplug CPUs
2023-07-24T02:47:29,170911+00:00 PM: hibernation: Registered nosave memory: [mem 0x00000000-0x00000fff]
2023-07-24T02:47:29,170915+00:00 PM: hibernation: Registered nosave memory: [mem 0x0009f000-0x0009ffff]
2023-07-24T02:47:29,170917+00:00 PM: hibernation: Registered nosave memory: [mem 0x000a0000-0x000effff]
2023-07-24T02:47:29,170920+00:00 PM: hibernation: Registered nosave memory: [mem 0x000f0000-0x000fffff]
2023-07-24T02:47:29,170923+00:00 PM: hibernation: Registered nosave memory: [mem 0xbffdc000-0xbfffffff]
2023-07-24T02:47:29,170925+00:00 PM: hibernation: Registered nosave memory: [mem 0xc0000000-0xfeffbfff]
2023-07-24T02:47:29,170928+00:00 PM: hibernation: Registered nosave memory: [mem 0xfeffc000-0xfeffffff]
2023-07-24T02:47:29,170929+00:00 PM: hibernation: Registered nosave memory: [mem 0xff000000-0xfffbffff]
2023-07-24T02:47:29,170931+00:00 PM: hibernation: Registered nosave memory: [mem 0xfffc0000-0xffffffff]
2023-07-24T02:47:29,170935+00:00 [mem 0xc0000000-0xfeffbfff] available for PCI devices
2023-07-24T02:47:29,170938+00:00 Booting paravirtualized kernel on KVM
2023-07-24T02:47:29,170949+00:00 clocksource: refined-jiffies: mask: 0xffffffff max_cycles: 0xffffffff, max_idle_ns: 7645519600211568 ns
2023-07-24T02:47:29,170964+00:00 setup_percpu: NR_CPUS:8192 nr_cpumask_bits:8 nr_cpu_ids:8 nr_node_ids:1
2023-07-24T02:47:29,172166+00:00 percpu: Embedded 60 pages/cpu s208896 r8192 d28672 u262144
2023-07-24T02:47:29,172215+00:00 pcpu-alloc: s208896 r8192 d28672 u262144 alloc=1*2097152
2023-07-24T02:47:29,172220+00:00 pcpu-alloc: [0] 0 1 2 3 4 5 6 7 
2023-07-24T02:47:29,172271+00:00 kvm-guest: stealtime: cpu 0, msr 418232080
2023-07-24T02:47:29,172277+00:00 kvm-guest: PV spinlocks disabled, no host support
2023-07-24T02:47:29,172293+00:00 Built 1 zonelists, mobility grouping on.  Total pages: 4031708
2023-07-24T02:47:29,172296+00:00 Policy zone: Normal
2023-07-24T02:47:29,172299+00:00 Kernel command line: BOOT_IMAGE=/boot/vmlinuz-5.15.0-67-generic root=LABEL=cloudimg-rootfs ro console=tty1 console=ttyS0
2023-07-24T02:47:29,172405+00:00 Unknown kernel command line parameters "BOOT_IMAGE=/boot/vmlinuz-5.15.0-67-generic", will be passed to user space.
2023-07-24T02:47:29,179117+00:00 Dentry cache hash table entries: 2097152 (order: 12, 16777216 bytes, linear)
2023-07-24T02:47:29,182491+00:00 Inode-cache hash table entries: 1048576 (order: 11, 8388608 bytes, linear)
2023-07-24T02:47:29,182834+00:00 mem auto-init: stack:off, heap alloc:on, heap free:off
2023-07-24T02:47:29,295189+00:00 Memory: 15956888K/16383464K available (16393K kernel code, 4379K rwdata, 10820K rodata, 3240K init, 6556K bss, 426316K reserved, 0K cma-reserved)
2023-07-24T02:47:29,295749+00:00 SLUB: HWalign=64, Order=0-3, MinObjects=0, CPUs=8, Nodes=1
2023-07-24T02:47:29,295805+00:00 Kernel/User page tables isolation: enabled
2023-07-24T02:47:29,295855+00:00 ftrace: allocating 50555 entries in 198 pages
2023-07-24T02:47:29,340689+00:00 ftrace: allocated 198 pages with 4 groups
2023-07-24T02:47:29,341814+00:00 rcu: Hierarchical RCU implementation.
2023-07-24T02:47:29,341818+00:00 rcu: 	RCU restricting CPUs from NR_CPUS=8192 to nr_cpu_ids=8.
2023-07-24T02:47:29,341822+00:00 	Rude variant of Tasks RCU enabled.
2023-07-24T02:47:29,341823+00:00 	Tracing variant of Tasks RCU enabled.
2023-07-24T02:47:29,341830+00:00 rcu: RCU calculated value of scheduler-enlistment delay is 25 jiffies.
2023-07-24T02:47:29,341833+00:00 rcu: Adjusting geometry for rcu_fanout_leaf=16, nr_cpu_ids=8
2023-07-24T02:47:29,349376+00:00 NR_IRQS: 524544, nr_irqs: 488, preallocated irqs: 16
2023-07-24T02:47:29,349695+00:00 random: crng init done
2023-07-24T02:47:29,374084+00:00 Console: colour VGA+ 80x25
2023-07-24T02:47:29,452017+00:00 printk: console [tty1] enabled
2023-07-24T02:47:29,857692+00:00 printk: console [ttyS0] enabled
2023-07-24T02:47:29,860915+00:00 ACPI: Core revision 20210730
2023-07-24T02:47:29,864367+00:00 APIC: Switch to symmetric I/O mode setup
2023-07-24T02:47:29,868317+00:00 x2apic enabled
2023-07-24T02:47:29,872074+00:00 Switched APIC routing to physical x2apic.
2023-07-24T02:47:29,879346+00:00 clocksource: tsc-early: mask: 0xffffffffffffffff max_cycles: 0x39a84ecfd44, max_idle_ns: 881590442549 ns
2023-07-24T02:47:29,887955+00:00 Calibrating delay loop (skipped) preset value.. 3999.98 BogoMIPS (lpj=7999972)
2023-07-24T02:47:29,891944+00:00 pid_max: default: 32768 minimum: 301
2023-07-24T02:47:29,891944+00:00 LSM: Security Framework initializing
2023-07-24T02:47:29,891944+00:00 landlock: Up and running.
2023-07-24T02:47:29,891944+00:00 Yama: becoming mindful.
2023-07-24T02:47:29,891944+00:00 AppArmor: AppArmor initialized
2023-07-24T02:47:29,891944+00:00 Mount-cache hash table entries: 32768 (order: 6, 262144 bytes, linear)
2023-07-24T02:47:29,891944+00:00 Mountpoint-cache hash table entries: 32768 (order: 6, 262144 bytes, linear)
2023-07-24T02:47:29,891944+00:00 Last level iTLB entries: 4KB 0, 2MB 0, 4MB 0
2023-07-24T02:47:29,891944+00:00 Last level dTLB entries: 4KB 0, 2MB 0, 4MB 0, 1GB 0
2023-07-24T02:47:29,891944+00:00 Spectre V1 : Mitigation: usercopy/swapgs barriers and __user pointer sanitization
2023-07-24T02:47:29,891944+00:00 Spectre V2 : Mitigation: Retpolines
2023-07-24T02:47:29,891944+00:00 Spectre V2 : Spectre v2 / SpectreRSB mitigation: Filling RSB on context switch
2023-07-24T02:47:29,891944+00:00 Spectre V2 : Spectre v2 / SpectreRSB : Filling RSB on VMEXIT
2023-07-24T02:47:29,891944+00:00 Spectre V2 : Enabling Restricted Speculation for firmware calls
2023-07-24T02:47:29,891944+00:00 Spectre V2 : mitigation: Enabling conditional Indirect Branch Prediction Barrier
2023-07-24T02:47:29,891944+00:00 Speculative Store Bypass: Mitigation: Speculative Store Bypass disabled via prctl and seccomp
2023-07-24T02:47:29,891944+00:00 MDS: Mitigation: Clear CPU buffers
2023-07-24T02:47:29,891944+00:00 MMIO Stale Data: Unknown: No mitigations
2023-07-24T02:47:29,891944+00:00 SRBDS: Unknown: Dependent on hypervisor status
2023-07-24T02:47:29,891944+00:00 Freeing SMP alternatives memory: 44K
2023-07-24T02:47:29,891944+00:00 smpboot: CPU0: Intel Xeon E3-12xx v2 (Ivy Bridge, IBRS) (family: 0x6, model: 0x3a, stepping: 0x9)
2023-07-24T02:47:29,892326+00:00 Performance Events: unsupported p6 CPU model 58 no PMU driver, software events only.
2023-07-24T02:47:29,896045+00:00 rcu: Hierarchical SRCU implementation.
2023-07-24T02:47:29,900686+00:00 NMI watchdog: Perf NMI watchdog permanently disabled
2023-07-24T02:47:29,904292+00:00 smp: Bringing up secondary CPUs ...
2023-07-24T02:47:29,908159+00:00 x86: Booting SMP configuration:
2023-07-24T02:47:29,911081+00:00 .... node  #0, CPUs:      #1
2023-07-24T02:47:29,542269+00:00 kvm-clock: cpu 1, msr 300201041, secondary cpu clock
2023-07-24T02:47:29,542269+00:00 smpboot: CPU 1 Converting physical 0 to logical die 1
2023-07-24T02:47:29,924042+00:00 kvm-guest: stealtime: cpu 1, msr 418272080
2023-07-24T02:47:29,927239+00:00  #2
2023-07-24T02:47:29,542269+00:00 kvm-clock: cpu 2, msr 300201081, secondary cpu clock
2023-07-24T02:47:29,542269+00:00 smpboot: CPU 2 Converting physical 0 to logical die 2
2023-07-24T02:47:29,935994+00:00 kvm-guest: stealtime: cpu 2, msr 4182b2080
2023-07-24T02:47:29,939094+00:00  #3
2023-07-24T02:47:29,542269+00:00 kvm-clock: cpu 3, msr 3002010c1, secondary cpu clock
2023-07-24T02:47:29,542269+00:00 smpboot: CPU 3 Converting physical 0 to logical die 3
2023-07-24T02:47:29,952012+00:00 kvm-guest: stealtime: cpu 3, msr 4182f2080
2023-07-24T02:47:29,954912+00:00  #4
2023-07-24T02:47:29,542269+00:00 kvm-clock: cpu 4, msr 300201101, secondary cpu clock
2023-07-24T02:47:29,542269+00:00 smpboot: CPU 4 Converting physical 0 to logical die 4
2023-07-24T02:47:29,963982+00:00 kvm-guest: stealtime: cpu 4, msr 418332080
2023-07-24T02:47:29,966978+00:00  #5
2023-07-24T02:47:29,542269+00:00 kvm-clock: cpu 5, msr 300201141, secondary cpu clock
2023-07-24T02:47:29,542269+00:00 smpboot: CPU 5 Converting physical 0 to logical die 5
2023-07-24T02:47:29,975986+00:00 kvm-guest: stealtime: cpu 5, msr 418372080
2023-07-24T02:47:29,979136+00:00  #6
2023-07-24T02:47:29,542269+00:00 kvm-clock: cpu 6, msr 300201181, secondary cpu clock
2023-07-24T02:47:29,542269+00:00 smpboot: CPU 6 Converting physical 0 to logical die 6
2023-07-24T02:47:29,987983+00:00 kvm-guest: stealtime: cpu 6, msr 4183b2080
2023-07-24T02:47:29,991035+00:00  #7
2023-07-24T02:47:29,542269+00:00 kvm-clock: cpu 7, msr 3002011c1, secondary cpu clock
2023-07-24T02:47:29,542269+00:00 smpboot: CPU 7 Converting physical 0 to logical die 7
2023-07-24T02:47:30,000055+00:00 kvm-guest: stealtime: cpu 7, msr 4183f2080
2023-07-24T02:47:30,004582+00:00 smp: Brought up 1 node, 8 CPUs
2023-07-24T02:47:30,007671+00:00 smpboot: Max logical packages: 8
2023-07-24T02:47:30,007960+00:00 smpboot: Total of 8 processors activated (31999.88 BogoMIPS)
2023-07-24T02:47:30,014644+00:00 devtmpfs: initialized
2023-07-24T02:47:30,016070+00:00 x86/mm: Memory block size: 128MB
2023-07-24T02:47:30,021731+00:00 clocksource: jiffies: mask: 0xffffffff max_cycles: 0xffffffff, max_idle_ns: 7645041785100000 ns
2023-07-24T02:47:30,024021+00:00 futex hash table entries: 2048 (order: 5, 131072 bytes, linear)
2023-07-24T02:47:30,028187+00:00 pinctrl core: initialized pinctrl subsystem
2023-07-24T02:47:30,032369+00:00 PM: RTC time: 02:47:30, date: 2023-07-24
2023-07-24T02:47:30,036518+00:00 NET: Registered PF_NETLINK/PF_ROUTE protocol family
2023-07-24T02:47:30,041088+00:00 DMA: preallocated 2048 KiB GFP_KERNEL pool for atomic allocations
2023-07-24T02:47:30,044669+00:00 DMA: preallocated 2048 KiB GFP_KERNEL|GFP_DMA pool for atomic allocations
2023-07-24T02:47:30,048684+00:00 DMA: preallocated 2048 KiB GFP_KERNEL|GFP_DMA32 pool for atomic allocations
2023-07-24T02:47:30,051967+00:00 audit: initializing netlink subsys (disabled)
2023-07-24T02:47:30,056093+00:00 audit: type=2000 audit(1690166849.623:1): state=initialized audit_enabled=0 res=1
2023-07-24T02:47:30,056292+00:00 thermal_sys: Registered thermal governor 'fair_share'
2023-07-24T02:47:30,059953+00:00 thermal_sys: Registered thermal governor 'bang_bang'
2023-07-24T02:47:30,063952+00:00 thermal_sys: Registered thermal governor 'step_wise'
2023-07-24T02:47:30,067951+00:00 thermal_sys: Registered thermal governor 'user_space'
2023-07-24T02:47:30,071951+00:00 thermal_sys: Registered thermal governor 'power_allocator'
2023-07-24T02:47:30,075983+00:00 EISA bus registered
2023-07-24T02:47:30,082671+00:00 cpuidle: using governor ladder
2023-07-24T02:47:30,083981+00:00 cpuidle: using governor menu
2023-07-24T02:47:30,087532+00:00 ACPI: bus type PCI registered
2023-07-24T02:47:30,087953+00:00 acpiphp: ACPI Hot Plug PCI Controller Driver version: 0.5
2023-07-24T02:47:30,092310+00:00 PCI: Using configuration type 1 for base access
2023-07-24T02:47:30,098638+00:00 Kprobes globally optimized
2023-07-24T02:47:30,100777+00:00 HugeTLB registered 1.00 GiB page size, pre-allocated 0 pages
2023-07-24T02:47:30,103955+00:00 HugeTLB registered 2.00 MiB page size, pre-allocated 0 pages
2023-07-24T02:47:30,112110+00:00 ACPI: Added _OSI(Module Device)
2023-07-24T02:47:30,115985+00:00 ACPI: Added _OSI(Processor Device)
2023-07-24T02:47:30,119192+00:00 ACPI: Added _OSI(3.0 _SCP Extensions)
2023-07-24T02:47:30,119953+00:00 ACPI: Added _OSI(Processor Aggregator Device)
2023-07-24T02:47:30,123686+00:00 ACPI: Added _OSI(Linux-Dell-Video)
2023-07-24T02:47:30,123960+00:00 ACPI: Added _OSI(Linux-Lenovo-NV-HDMI-Audio)
2023-07-24T02:47:30,127631+00:00 ACPI: Added _OSI(Linux-HPI-Hybrid-Graphics)
2023-07-24T02:47:30,129781+00:00 ACPI: 1 ACPI AML tables successfully acquired and loaded
2023-07-24T02:47:30,134675+00:00 ACPI: Interpreter enabled
2023-07-24T02:47:30,135983+00:00 ACPI: PM: (supports S0 S3 S4 S5)
2023-07-24T02:47:30,139135+00:00 ACPI: Using IOAPIC for interrupt routing
2023-07-24T02:47:30,139994+00:00 PCI: Using host bridge windows from ACPI; if necessary, use "pci=nocrs" and report a bug
2023-07-24T02:47:30,143952+00:00 PCI: Using E820 reservations for host bridge windows
2023-07-24T02:47:30,148200+00:00 ACPI: Enabled 2 GPEs in block 00 to 0F
2023-07-24T02:47:30,158420+00:00 ACPI: PCI Root Bridge [PCI0] (domain 0000 [bus 00-ff])
2023-07-24T02:47:30,159963+00:00 acpi PNP0A03:00: _OSC: OS supports [ASPM ClockPM Segments MSI EDR HPX-Type3]
2023-07-24T02:47:30,163976+00:00 acpi PNP0A03:00: fail to add MMCONFIG information, can't access extended PCI configuration space under this bridge.
2023-07-24T02:47:30,168498+00:00 acpiphp: Slot [3] registered
2023-07-24T02:47:30,171325+00:00 acpiphp: Slot [4] registered
2023-07-24T02:47:30,172003+00:00 acpiphp: Slot [5] registered
2023-07-24T02:47:30,174974+00:00 acpiphp: Slot [6] registered
2023-07-24T02:47:30,175995+00:00 acpiphp: Slot [7] registered
2023-07-24T02:47:30,178715+00:00 acpiphp: Slot [8] registered
2023-07-24T02:47:30,179996+00:00 acpiphp: Slot [9] registered
2023-07-24T02:47:30,182801+00:00 acpiphp: Slot [10] registered
2023-07-24T02:47:30,183999+00:00 acpiphp: Slot [11] registered
2023-07-24T02:47:30,186692+00:00 acpiphp: Slot [12] registered
2023-07-24T02:47:30,187995+00:00 acpiphp: Slot [13] registered
2023-07-24T02:47:30,191000+00:00 acpiphp: Slot [14] registered
2023-07-24T02:47:30,191996+00:00 acpiphp: Slot [15] registered
2023-07-24T02:47:30,194710+00:00 acpiphp: Slot [16] registered
2023-07-24T02:47:30,195998+00:00 acpiphp: Slot [17] registered
2023-07-24T02:47:30,199054+00:00 acpiphp: Slot [18] registered
2023-07-24T02:47:30,199996+00:00 acpiphp: Slot [19] registered
2023-07-24T02:47:30,202601+00:00 acpiphp: Slot [20] registered
2023-07-24T02:47:30,203998+00:00 acpiphp: Slot [21] registered
2023-07-24T02:47:30,207032+00:00 acpiphp: Slot [22] registered
2023-07-24T02:47:30,207996+00:00 acpiphp: Slot [23] registered
2023-07-24T02:47:30,210864+00:00 acpiphp: Slot [24] registered
2023-07-24T02:47:30,211996+00:00 acpiphp: Slot [25] registered
2023-07-24T02:47:30,214685+00:00 acpiphp: Slot [26] registered
2023-07-24T02:47:30,215995+00:00 acpiphp: Slot [27] registered
2023-07-24T02:47:30,218665+00:00 acpiphp: Slot [28] registered
2023-07-24T02:47:30,219999+00:00 acpiphp: Slot [29] registered
2023-07-24T02:47:30,222782+00:00 acpiphp: Slot [30] registered
2023-07-24T02:47:30,223996+00:00 acpiphp: Slot [31] registered
2023-07-24T02:47:30,226950+00:00 PCI host bridge to bus 0000:00
2023-07-24T02:47:30,227955+00:00 pci_bus 0000:00: root bus resource [bus 00-ff]
2023-07-24T02:47:30,231524+00:00 pci_bus 0000:00: root bus resource [io  0x0000-0x0cf7 window]
2023-07-24T02:47:30,231953+00:00 pci_bus 0000:00: root bus resource [io  0x0d00-0xffff window]
2023-07-24T02:47:30,235953+00:00 pci_bus 0000:00: root bus resource [mem 0x000a0000-0x000bffff window]
2023-07-24T02:47:30,239953+00:00 pci_bus 0000:00: root bus resource [mem 0xc0000000-0xfebfffff window]
2023-07-24T02:47:30,243952+00:00 pci_bus 0000:00: root bus resource [mem 0x440000000-0x4bfffffff window]
2023-07-24T02:47:30,248204+00:00 pci 0000:00:00.0: [8086:1237] type 00 class 0x060000
2023-07-24T02:47:30,253516+00:00 pci 0000:00:01.0: [8086:7000] type 00 class 0x060100
2023-07-24T02:47:30,257329+00:00 pci 0000:00:01.1: [8086:7010] type 00 class 0x010180
2023-07-24T02:47:30,263952+00:00 pci 0000:00:01.1: reg 0x20: [io  0xc0c0-0xc0cf]
2023-07-24T02:47:30,269584+00:00 pci 0000:00:01.1: legacy IDE quirk: reg 0x10: [io  0x01f0-0x01f7]
2023-07-24T02:47:30,271953+00:00 pci 0000:00:01.1: legacy IDE quirk: reg 0x14: [io  0x03f6]
2023-07-24T02:47:30,275952+00:00 pci 0000:00:01.1: legacy IDE quirk: reg 0x18: [io  0x0170-0x0177]
2023-07-24T02:47:30,279952+00:00 pci 0000:00:01.1: legacy IDE quirk: reg 0x1c: [io  0x0376]
2023-07-24T02:47:30,284445+00:00 pci 0000:00:01.2: [8086:7020] type 00 class 0x0c0300
2023-07-24T02:47:30,291328+00:00 pci 0000:00:01.2: reg 0x20: [io  0xc080-0xc09f]
2023-07-24T02:47:30,293874+00:00 pci 0000:00:01.3: [8086:7113] type 00 class 0x068000
2023-07-24T02:47:30,296963+00:00 pci 0000:00:01.3: quirk: [io  0x0600-0x063f] claimed by PIIX4 ACPI
2023-07-24T02:47:30,299973+00:00 pci 0000:00:01.3: quirk: [io  0x0700-0x070f] claimed by PIIX4 SMB
2023-07-24T02:47:30,304978+00:00 pci 0000:00:02.0: [1013:00b8] type 00 class 0x030000
2023-07-24T02:47:30,311216+00:00 pci 0000:00:02.0: reg 0x10: [mem 0xfc000000-0xfdffffff pref]
2023-07-24T02:47:30,314034+00:00 pci 0000:00:02.0: reg 0x14: [mem 0xfeb90000-0xfeb90fff]
2023-07-24T02:47:30,324823+00:00 pci 0000:00:02.0: reg 0x30: [mem 0xfeb80000-0xfeb8ffff pref]
2023-07-24T02:47:30,328212+00:00 pci 0000:00:02.0: Video device with shadowed ROM at [mem 0x000c0000-0x000dffff]
2023-07-24T02:47:30,333321+00:00 pci 0000:00:03.0: [1af4:1000] type 00 class 0x020000
2023-07-24T02:47:30,337622+00:00 pci 0000:00:03.0: reg 0x10: [io  0xc000-0xc03f]
2023-07-24T02:47:30,342119+00:00 pci 0000:00:03.0: reg 0x14: [mem 0xfeb91000-0xfeb91fff]
2023-07-24T02:47:30,347952+00:00 pci 0000:00:03.0: reg 0x20: [mem 0xfe000000-0xfe003fff 64bit pref]
2023-07-24T02:47:30,353456+00:00 pci 0000:00:03.0: reg 0x30: [mem 0xfeb00000-0xfeb7ffff pref]
2023-07-24T02:47:30,358046+00:00 pci 0000:00:04.0: [1af4:1001] type 00 class 0x010000
2023-07-24T02:47:30,361933+00:00 pci 0000:00:04.0: reg 0x10: [io  0xc040-0xc07f]
2023-07-24T02:47:30,365809+00:00 pci 0000:00:04.0: reg 0x14: [mem 0xfeb92000-0xfeb92fff]
2023-07-24T02:47:30,373494+00:00 pci 0000:00:04.0: reg 0x20: [mem 0xfe004000-0xfe007fff 64bit pref]
2023-07-24T02:47:30,379897+00:00 pci 0000:00:05.0: [1af4:1002] type 00 class 0x00ff00
2023-07-24T02:47:30,381403+00:00 pci 0000:00:05.0: reg 0x10: [io  0xc0a0-0xc0bf]
2023-07-24T02:47:30,389052+00:00 pci 0000:00:05.0: reg 0x20: [mem 0xfe008000-0xfe00bfff 64bit pref]
2023-07-24T02:47:30,405743+00:00 ACPI: PCI: Interrupt link LNKA configured for IRQ 10
2023-07-24T02:47:30,408260+00:00 ACPI: PCI: Interrupt link LNKB configured for IRQ 10
2023-07-24T02:47:30,412253+00:00 ACPI: PCI: Interrupt link LNKC configured for IRQ 11
2023-07-24T02:47:30,416206+00:00 ACPI: PCI: Interrupt link LNKD configured for IRQ 11
2023-07-24T02:47:30,420086+00:00 ACPI: PCI: Interrupt link LNKS configured for IRQ 9
2023-07-24T02:47:30,425784+00:00 iommu: Default domain type: Translated 
2023-07-24T02:47:30,427953+00:00 iommu: DMA domain TLB invalidation policy: lazy mode 
2023-07-24T02:47:30,432495+00:00 SCSI subsystem initialized
2023-07-24T02:47:30,435536+00:00 libata version 3.00 loaded.
2023-07-24T02:47:30,436005+00:00 pci 0000:00:02.0: vgaarb: setting as boot VGA device
2023-07-24T02:47:30,439944+00:00 pci 0000:00:02.0: vgaarb: VGA device added: decodes=io+mem,owns=io+mem,locks=none
2023-07-24T02:47:30,439953+00:00 pci 0000:00:02.0: vgaarb: bridge control possible
2023-07-24T02:47:30,443952+00:00 vgaarb: loaded
2023-07-24T02:47:30,446011+00:00 ACPI: bus type USB registered
2023-07-24T02:47:30,447995+00:00 usbcore: registered new interface driver usbfs
2023-07-24T02:47:30,451996+00:00 usbcore: registered new interface driver hub
2023-07-24T02:47:30,455986+00:00 usbcore: registered new device driver usb
2023-07-24T02:47:30,460000+00:00 pps_core: LinuxPPS API ver. 1 registered
2023-07-24T02:47:30,463890+00:00 pps_core: Software ver. 5.3.6 - Copyright 2005-2007 Rodolfo Giometti <giometti@linux.it>
2023-07-24T02:47:30,463960+00:00 PTP clock support registered
2023-07-24T02:47:30,466833+00:00 EDAC MC: Ver: 3.0.0
2023-07-24T02:47:30,468536+00:00 NetLabel: Initializing
2023-07-24T02:47:30,471059+00:00 NetLabel:  domain hash size = 128
2023-07-24T02:47:30,471952+00:00 NetLabel:  protocols = UNLABELED CIPSOv4 CALIPSO
2023-07-24T02:47:30,476010+00:00 NetLabel:  unlabeled traffic allowed by default
2023-07-24T02:47:30,480030+00:00 PCI: Using ACPI for IRQ routing
2023-07-24T02:47:30,483064+00:00 PCI: pci_cache_line_size set to 64 bytes
2023-07-24T02:47:30,483422+00:00 e820: reserve RAM buffer [mem 0x0009fc00-0x0009ffff]
2023-07-24T02:47:30,483430+00:00 e820: reserve RAM buffer [mem 0xbffdc000-0xbfffffff]
2023-07-24T02:47:30,484218+00:00 clocksource: Switched to clocksource kvm-clock
2023-07-24T02:47:30,509447+00:00 VFS: Disk quotas dquot_6.6.0
2023-07-24T02:47:30,513272+00:00 VFS: Dquot-cache hash table entries: 512 (order 0, 4096 bytes)
2023-07-24T02:47:30,519499+00:00 AppArmor: AppArmor Filesystem Enabled
2023-07-24T02:47:30,523132+00:00 pnp: PnP ACPI init
2023-07-24T02:47:30,525371+00:00 pnp 00:03: [dma 2]
2023-07-24T02:47:30,526116+00:00 pnp: PnP ACPI: found 5 devices
2023-07-24T02:47:30,537280+00:00 clocksource: acpi_pm: mask: 0xffffff max_cycles: 0xffffff, max_idle_ns: 2085701024 ns
2023-07-24T02:47:30,557040+00:00 NET: Registered PF_INET protocol family
2023-07-24T02:47:30,560982+00:00 IP idents hash table entries: 262144 (order: 9, 2097152 bytes, linear)
2023-07-24T02:47:30,568937+00:00 tcp_listen_portaddr_hash hash table entries: 8192 (order: 5, 131072 bytes, linear)
2023-07-24T02:47:30,575365+00:00 Table-perturb hash table entries: 65536 (order: 6, 262144 bytes, linear)
2023-07-24T02:47:30,582336+00:00 TCP established hash table entries: 131072 (order: 8, 1048576 bytes, linear)
2023-07-24T02:47:30,588254+00:00 TCP bind hash table entries: 65536 (order: 8, 1048576 bytes, linear)
2023-07-24T02:47:30,593643+00:00 TCP: Hash tables configured (established 131072 bind 65536)
2023-07-24T02:47:30,599133+00:00 MPTCP token hash table entries: 16384 (order: 6, 393216 bytes, linear)
2023-07-24T02:47:30,604201+00:00 UDP hash table entries: 8192 (order: 6, 262144 bytes, linear)
2023-07-24T02:47:30,608506+00:00 UDP-Lite hash table entries: 8192 (order: 6, 262144 bytes, linear)
2023-07-24T02:47:30,613320+00:00 NET: Registered PF_UNIX/PF_LOCAL protocol family
2023-07-24T02:47:30,616886+00:00 NET: Registered PF_XDP protocol family
2023-07-24T02:47:30,620148+00:00 pci_bus 0000:00: resource 4 [io  0x0000-0x0cf7 window]
2023-07-24T02:47:30,641238+00:00 pci_bus 0000:00: resource 5 [io  0x0d00-0xffff window]
2023-07-24T02:47:30,645257+00:00 pci_bus 0000:00: resource 6 [mem 0x000a0000-0x000bffff window]
2023-07-24T02:47:30,650047+00:00 pci_bus 0000:00: resource 7 [mem 0xc0000000-0xfebfffff window]
2023-07-24T02:47:30,654947+00:00 pci_bus 0000:00: resource 8 [mem 0x440000000-0x4bfffffff window]
2023-07-24T02:47:30,659582+00:00 pci 0000:00:01.0: PIIX3: Enabling Passive Release
2023-07-24T02:47:30,663222+00:00 pci 0000:00:00.0: Limiting direct PCI/PCI transfers
2023-07-24T02:47:30,666768+00:00 pci 0000:00:01.0: Activating ISA DMA hang workarounds
2023-07-24T02:47:30,710588+00:00 ACPI: \_SB_.LNKD: Enabled at IRQ 11
2023-07-24T02:47:30,753394+00:00 pci 0000:00:01.2: quirk_usb_early_handoff+0x0/0x160 took 80916 usecs
2023-07-24T02:47:30,760147+00:00 PCI: CLS 0 bytes, default 64
2023-07-24T02:47:30,763703+00:00 PCI-DMA: Using software bounce buffering for IO (SWIOTLB)
2023-07-24T02:47:30,764703+00:00 Trying to unpack rootfs image as initramfs...
2023-07-24T02:47:30,768766+00:00 software IO TLB: mapped [mem 0x00000000bbfdc000-0x00000000bffdc000] (64MB)
2023-07-24T02:47:30,780568+00:00 clocksource: tsc: mask: 0xffffffffffffffff max_cycles: 0x39a84ecfd44, max_idle_ns: 881590442549 ns
2023-07-24T02:47:30,790713+00:00 Initialise system trusted keyrings
2023-07-24T02:47:30,794949+00:00 Key type blacklist registered
2023-07-24T02:47:30,799870+00:00 workingset: timestamp_bits=36 max_order=22 bucket_order=0
2023-07-24T02:47:30,807571+00:00 zbud: loaded
2023-07-24T02:47:30,810627+00:00 squashfs: version 4.0 (2009/01/31) Phillip Lougher
2023-07-24T02:47:30,816469+00:00 fuse: init (API version 7.34)
2023-07-24T02:47:30,821022+00:00 integrity: Platform Keyring initialized
2023-07-24T02:47:30,840202+00:00 Key type asymmetric registered
2023-07-24T02:47:30,844227+00:00 Asymmetric key parser 'x509' registered
2023-07-24T02:47:30,848902+00:00 Block layer SCSI generic (bsg) driver version 0.4 loaded (major 243)
2023-07-24T02:47:30,854504+00:00 io scheduler mq-deadline registered
2023-07-24T02:47:30,858746+00:00 shpchp: Standard Hot Plug PCI Controller Driver version: 0.4
2023-07-24T02:47:30,863728+00:00 input: Power Button as /devices/LNXSYSTM:00/LNXPWRBN:00/input/input0
2023-07-24T02:47:30,869387+00:00 ACPI: button: Power Button [PWRF]
2023-07-24T02:47:30,912535+00:00 ACPI: \_SB_.LNKC: Enabled at IRQ 10
2023-07-24T02:47:30,998482+00:00 ACPI: \_SB_.LNKA: Enabled at IRQ 10
2023-07-24T02:47:31,005377+00:00 Serial: 8250/16550 driver, 32 ports, IRQ sharing enabled
2023-07-24T02:47:31,039558+00:00 00:04: ttyS0 at I/O 0x3f8 (irq = 4, base_baud = 115200) is a 16550A
2023-07-24T02:47:31,048133+00:00 Linux agpgart interface v0.103
2023-07-24T02:47:31,061636+00:00 loop: module loaded
2023-07-24T02:47:31,064791+00:00 ata_piix 0000:00:01.1: version 2.13
2023-07-24T02:47:31,067081+00:00 scsi host0: ata_piix
2023-07-24T02:47:31,070502+00:00 scsi host1: ata_piix
2023-07-24T02:47:31,072695+00:00 ata1: PATA max MWDMA2 cmd 0x1f0 ctl 0x3f6 bmdma 0xc0c0 irq 14
2023-07-24T02:47:31,077608+00:00 ata2: PATA max MWDMA2 cmd 0x170 ctl 0x376 bmdma 0xc0c8 irq 15
2023-07-24T02:47:31,082672+00:00 tun: Universal TUN/TAP device driver, 1.6
2023-07-24T02:47:31,088103+00:00 PPP generic driver version 2.4.2
2023-07-24T02:47:31,092349+00:00 VFIO - User Level meta-driver version: 0.3
2023-07-24T02:47:31,096265+00:00 ehci_hcd: USB 2.0 'Enhanced' Host Controller (EHCI) Driver
2023-07-24T02:47:31,101762+00:00 ehci-pci: EHCI PCI platform driver
2023-07-24T02:47:31,105747+00:00 ehci-platform: EHCI generic platform driver
2023-07-24T02:47:31,110034+00:00 ohci_hcd: USB 1.1 'Open' Host Controller (OHCI) Driver
2023-07-24T02:47:31,114604+00:00 ohci-pci: OHCI PCI platform driver
2023-07-24T02:47:31,117973+00:00 ohci-platform: OHCI generic platform driver
2023-07-24T02:47:31,121218+00:00 uhci_hcd: USB Universal Host Controller Interface driver
2023-07-24T02:47:31,165734+00:00 uhci_hcd 0000:00:01.2: UHCI Host Controller
2023-07-24T02:47:31,169281+00:00 uhci_hcd 0000:00:01.2: new USB bus registered, assigned bus number 1
2023-07-24T02:47:31,174086+00:00 uhci_hcd 0000:00:01.2: detected 2 ports
2023-07-24T02:47:31,175557+00:00 Freeing initrd memory: 31536K
2023-07-24T02:47:31,177902+00:00 uhci_hcd 0000:00:01.2: irq 11, io base 0x0000c080
2023-07-24T02:47:31,184524+00:00 usb usb1: New USB device found, idVendor=1d6b, idProduct=0001, bcdDevice= 5.15
2023-07-24T02:47:31,190482+00:00 usb usb1: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2023-07-24T02:47:31,196221+00:00 usb usb1: Product: UHCI Host Controller
2023-07-24T02:47:31,200058+00:00 usb usb1: Manufacturer: Linux 5.15.0-67-generic uhci_hcd
2023-07-24T02:47:31,204777+00:00 usb usb1: SerialNumber: 0000:00:01.2
2023-07-24T02:47:31,208459+00:00 hub 1-0:1.0: USB hub found
2023-07-24T02:47:31,211295+00:00 hub 1-0:1.0: 2 ports detected
2023-07-24T02:47:31,214927+00:00 i8042: PNP: PS/2 Controller [PNP0303:KBD,PNP0f13:MOU] at 0x60,0x64 irq 1,12
2023-07-24T02:47:31,222693+00:00 serio: i8042 KBD port at 0x60,0x64 irq 1
2023-07-24T02:47:31,226287+00:00 serio: i8042 AUX port at 0x60,0x64 irq 12
2023-07-24T02:47:31,230304+00:00 mousedev: PS/2 mouse device common for all mice
2023-07-24T02:47:31,234923+00:00 rtc_cmos 00:00: RTC can wake from S4
2023-07-24T02:47:31,239735+00:00 input: AT Translated Set 2 keyboard as /devices/platform/i8042/serio0/input/input1
2023-07-24T02:47:31,247161+00:00 rtc_cmos 00:00: registered as rtc0
2023-07-24T02:47:31,251529+00:00 rtc_cmos 00:00: setting system clock to 2023-07-24T02:47:31 UTC (1690166851)
2023-07-24T02:47:31,256975+00:00 rtc_cmos 00:00: alarms up to one day, y3k, 114 bytes nvram
2023-07-24T02:47:31,261623+00:00 i2c_dev: i2c /dev entries driver
2023-07-24T02:47:31,264662+00:00 device-mapper: core: CONFIG_IMA_DISABLE_HTABLE is disabled. Duplicate IMA measurements will not be recorded in the IMA log.
2023-07-24T02:47:31,272068+00:00 device-mapper: uevent: version 1.0.3
2023-07-24T02:47:31,275227+00:00 device-mapper: ioctl: 4.45.0-ioctl (2021-03-22) initialised: dm-devel@redhat.com
2023-07-24T02:47:31,280479+00:00 platform eisa.0: Probing EISA bus 0
2023-07-24T02:47:31,283572+00:00 platform eisa.0: EISA: Cannot allocate resource for mainboard
2023-07-24T02:47:31,287359+00:00 platform eisa.0: Cannot allocate resource for EISA slot 1
2023-07-24T02:47:31,290977+00:00 platform eisa.0: Cannot allocate resource for EISA slot 2
2023-07-24T02:47:31,294564+00:00 platform eisa.0: Cannot allocate resource for EISA slot 3
2023-07-24T02:47:31,298175+00:00 platform eisa.0: Cannot allocate resource for EISA slot 4
2023-07-24T02:47:31,301838+00:00 platform eisa.0: Cannot allocate resource for EISA slot 5
2023-07-24T02:47:31,305803+00:00 platform eisa.0: Cannot allocate resource for EISA slot 6
2023-07-24T02:47:31,310042+00:00 platform eisa.0: Cannot allocate resource for EISA slot 7
2023-07-24T02:47:31,315240+00:00 platform eisa.0: Cannot allocate resource for EISA slot 8
2023-07-24T02:47:31,319004+00:00 platform eisa.0: EISA: Detected 0 cards
2023-07-24T02:47:31,322090+00:00 intel_pstate: CPU model not supported
2023-07-24T02:47:31,325971+00:00 ledtrig-cpu: registered to indicate activity on CPUs
2023-07-24T02:47:31,329811+00:00 drop_monitor: Initializing network drop monitor service
2023-07-24T02:47:31,333704+00:00 NET: Registered PF_INET6 protocol family
2023-07-24T02:47:31,358647+00:00 Segment Routing with IPv6
2023-07-24T02:47:31,361101+00:00 In-situ OAM (IOAM) with IPv6
2023-07-24T02:47:31,363534+00:00 NET: Registered PF_PACKET protocol family
2023-07-24T02:47:31,366747+00:00 Key type dns_resolver registered
2023-07-24T02:47:31,371529+00:00 IPI shorthand broadcast: enabled
2023-07-24T02:47:31,374179+00:00 sched_clock: Marking stable (1835846265, 538269366)->(2874194075, -500078444)
2023-07-24T02:47:31,379720+00:00 registered taskstats version 1
2023-07-24T02:47:31,383029+00:00 Loading compiled-in X.509 certificates
2023-07-24T02:47:31,387509+00:00 Loaded X.509 cert 'Build time autogenerated kernel key: 4919d01b97f8f8ece5362917619ef42f1d265e85'
2023-07-24T02:47:31,394123+00:00 Loaded X.509 cert 'Canonical Ltd. Live Patch Signing: 14df34d1a87cf37625abec039ef2bf521249b969'
2023-07-24T02:47:31,400476+00:00 Loaded X.509 cert 'Canonical Ltd. Kernel Module Signing: 88f752e560a1e0737e31163a466ad7b70a850c19'
2023-07-24T02:47:31,406064+00:00 blacklist: Loading compiled-in revocation X.509 certificates
2023-07-24T02:47:31,409804+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing: 61482aa2830d0ab2ad5af10b7250da9033ddcef0'
2023-07-24T02:47:31,415274+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (2017): 242ade75ac4a15e50d50c84b0d45ff3eae707a03'
2023-07-24T02:47:31,421078+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (ESM 2018): 365188c1d374d6b07c3c8f240f8ef722433d6a8b'
2023-07-24T02:47:31,427022+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (2019): c0746fd6c5da3ae827864651ad66ae47fe24b3e8'
2023-07-24T02:47:31,432852+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (2021 v1): a8d54bbb3825cfb94fa13c9f8a594a195c107b8d'
2023-07-24T02:47:31,438892+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (2021 v2): 4cf046892d6fd3c9a5b03f98d845f90851dc6a8c'
2023-07-24T02:47:31,444886+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (2021 v3): 100437bb6de6e469b581e61cd66bce3ef4ed53af'
2023-07-24T02:47:31,450854+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (Ubuntu Core 2019): c1d57b8f6b743f23ee41f4f7ee292f06eecadfb9'
2023-07-24T02:47:31,459156+00:00 zswap: loaded using pool lzo/zbud
2023-07-24T02:47:31,464114+00:00 Key type .fscrypt registered
2023-07-24T02:47:31,466549+00:00 Key type fscrypt-provisioning registered
2023-07-24T02:47:31,477877+00:00 Key type encrypted registered
2023-07-24T02:47:31,480438+00:00 AppArmor: AppArmor sha1 policy hashing enabled
2023-07-24T02:47:31,483731+00:00 ima: No TPM chip found, activating TPM-bypass!
2023-07-24T02:47:31,486915+00:00 Loading compiled-in module X.509 certificates
2023-07-24T02:47:31,491100+00:00 Loaded X.509 cert 'Build time autogenerated kernel key: 4919d01b97f8f8ece5362917619ef42f1d265e85'
2023-07-24T02:47:31,496700+00:00 ima: Allocated hash algorithm: sha1
2023-07-24T02:47:31,499420+00:00 ima: No architecture policies found
2023-07-24T02:47:31,502113+00:00 evm: Initialising EVM extended attributes:
2023-07-24T02:47:31,505091+00:00 evm: security.selinux
2023-07-24T02:47:31,507192+00:00 evm: security.SMACK64
2023-07-24T02:47:31,509212+00:00 evm: security.SMACK64EXEC
2023-07-24T02:47:31,511438+00:00 evm: security.SMACK64TRANSMUTE
2023-07-24T02:47:31,513969+00:00 evm: security.SMACK64MMAP
2023-07-24T02:47:31,516194+00:00 evm: security.apparmor
2023-07-24T02:47:31,518302+00:00 evm: security.ima
2023-07-24T02:47:31,520163+00:00 evm: security.capability
2023-07-24T02:47:31,522348+00:00 evm: HMAC attrs: 0x1
2023-07-24T02:47:31,525170+00:00 PM:   Magic number: 15:255:764
2023-07-24T02:47:31,527836+00:00 event_source breakpoint: hash matches
2023-07-24T02:47:31,531730+00:00 RAS: Correctable Errors collector initialized.
2023-07-24T02:47:31,538458+00:00 Freeing unused decrypted memory: 2036K
2023-07-24T02:47:31,543826+00:00 Freeing unused kernel image (initmem) memory: 3240K
2023-07-24T02:47:31,548023+00:00 usb 1-1: new full-speed USB device number 2 using uhci_hcd
2023-07-24T02:47:31,568130+00:00 Write protecting the kernel read-only data: 30720k
2023-07-24T02:47:31,576240+00:00 Freeing unused kernel image (text/rodata gap) memory: 2036K
2023-07-24T02:47:31,582020+00:00 Freeing unused kernel image (rodata/data gap) memory: 1468K
2023-07-24T02:47:31,655652+00:00 x86/mm: Checked W+X mappings: passed, no W+X pages found.
2023-07-24T02:47:31,659504+00:00 x86/mm: Checking user space page tables
2023-07-24T02:47:31,729674+00:00 x86/mm: Checked W+X mappings: passed, no W+X pages found.
2023-07-24T02:47:31,733999+00:00 Run /init as init process
2023-07-24T02:47:31,736762+00:00   with arguments:
2023-07-24T02:47:31,736765+00:00     /init
2023-07-24T02:47:31,736767+00:00   with environment:
2023-07-24T02:47:31,736768+00:00     HOME=/
2023-07-24T02:47:31,736769+00:00     TERM=linux
2023-07-24T02:47:31,736771+00:00     BOOT_IMAGE=/boot/vmlinuz-5.15.0-67-generic
2023-07-24T02:47:31,737378+00:00 usb 1-1: New USB device found, idVendor=0627, idProduct=0001, bcdDevice= 0.00
2023-07-24T02:47:31,745311+00:00 usb 1-1: New USB device strings: Mfr=1, Product=3, SerialNumber=5
2023-07-24T02:47:31,751517+00:00 usb 1-1: Product: QEMU USB Tablet
2023-07-24T02:47:31,755752+00:00 usb 1-1: Manufacturer: QEMU
2023-07-24T02:47:31,759201+00:00 usb 1-1: SerialNumber: 42
2023-07-24T02:47:31,945060+00:00 cryptd: max_cpu_qlen set to 1000
2023-07-24T02:47:31,945366+00:00 hid: raw HID events driver (C) Jiri Kosina
2023-07-24T02:47:31,952367+00:00 virtio_blk virtio1: [vda] 629145600 512-byte logical blocks (322 GB/300 GiB)
2023-07-24T02:47:31,975883+00:00 AVX version of gcm_enc/dec engaged.
2023-07-24T02:47:31,984888+00:00 AES CTR mode by8 optimization enabled
2023-07-24T02:47:32,008004+00:00 usbcore: registered new interface driver usbhid
2023-07-24T02:47:32,010209+00:00 FDC 0 is a S82078B
2023-07-24T02:47:32,012663+00:00 usbhid: USB HID core driver
2023-07-24T02:47:32,016755+00:00 input: VirtualPS/2 VMware VMMouse as /devices/platform/i8042/serio1/input/input4
2023-07-24T02:47:32,030162+00:00 input: VirtualPS/2 VMware VMMouse as /devices/platform/i8042/serio1/input/input3
2023-07-24T02:47:32,040105+00:00 GPT:Primary header thinks Alt. header is not at the end of the disk.
2023-07-24T02:47:32,045784+00:00 GPT:4612095 != 629145599
2023-07-24T02:47:32,048687+00:00 GPT:Alternate GPT header not at the end of the disk.
2023-07-24T02:47:32,053228+00:00 GPT:4612095 != 629145599
2023-07-24T02:47:32,056094+00:00 GPT: Use GNU Parted to correct GPT errors.
2023-07-24T02:47:32,060040+00:00  vda: vda1 vda14 vda15
2023-07-24T02:47:32,061580+00:00 virtio_net virtio0 ens3: renamed from eth0
2023-07-24T02:47:32,066689+00:00 input: QEMU QEMU USB Tablet as /devices/pci0000:00/0000:00:01.2/usb1/1-1/1-1:1.0/0003:0627:0001.0001/input/input5
2023-07-24T02:47:32,076543+00:00 hid-generic 0003:0627:0001.0001: input,hidraw0: USB HID v0.01 Mouse [QEMU QEMU USB Tablet] on usb-0000:00:01.2-1/input0
2023-07-24T02:47:33,647989+00:00 raid6: sse2x4   gen()  7306 MB/s
2023-07-24T02:47:33,719958+00:00 raid6: sse2x4   xor()  4105 MB/s
2023-07-24T02:47:33,787956+00:00 raid6: sse2x2   gen()  5051 MB/s
2023-07-24T02:47:33,859953+00:00 raid6: sse2x2   xor()  5539 MB/s
2023-07-24T02:47:33,927964+00:00 raid6: sse2x1   gen()  5040 MB/s
2023-07-24T02:47:33,999955+00:00 raid6: sse2x1   xor()  4977 MB/s
2023-07-24T02:47:34,003990+00:00 raid6: using algorithm sse2x4 gen() 7306 MB/s
2023-07-24T02:47:34,008777+00:00 raid6: .... xor() 4105 MB/s, rmw enabled
2023-07-24T02:47:34,013287+00:00 raid6: using ssse3x2 recovery algorithm
2023-07-24T02:47:34,019750+00:00 xor: automatically using best checksumming function   avx       
2023-07-24T02:47:34,026018+00:00 async_tx: api initialized (async)
2023-07-24T02:47:34,165853+00:00 Btrfs loaded, crc32c=crc32c-intel, zoned=yes, fsverity=yes
2023-07-24T02:47:34,276202+00:00 EXT4-fs (vda1): mounted filesystem with ordered data mode. Opts: (null). Quota mode: none.
2023-07-24T02:47:35,287316+00:00 systemd[1]: Inserted module 'autofs4'
2023-07-24T02:47:35,378138+00:00 systemd[1]: systemd 249.11-0ubuntu3.7 running in system mode (+PAM +AUDIT +SELINUX +APPARMOR +IMA +SMACK +SECCOMP +GCRYPT +GNUTLS +OPENSSL +ACL +BLKID +CURL +ELFUTILS +FIDO2 +IDN2 -IDN +IPTC +KMOD +LIBCRYPTSETUP +LIBFDISK +PCRE2 -PWQUALITY -P11KIT -QRENCODE +BZIP2 +LZ4 +XZ +ZLIB +ZSTD -XKBCOMMON +UTMP +SYSVINIT default-hierarchy=unified)
2023-07-24T02:47:35,404056+00:00 systemd[1]: Detected virtualization kvm.
2023-07-24T02:47:35,407610+00:00 systemd[1]: Detected architecture x86-64.
2023-07-24T02:47:35,430654+00:00 systemd[1]: Hostname set to <ubuntu>.
2023-07-24T02:47:35,459728+00:00 systemd[1]: Initializing machine ID from VM UUID.
2023-07-24T02:47:35,465882+00:00 systemd[1]: Installed transient /etc/machine-id file.
2023-07-24T02:47:36,895655+00:00 systemd[1]: Queued start job for default target Graphical Interface.
2023-07-24T02:47:36,905373+00:00 systemd[1]: Created slice Slice /system/modprobe.
2023-07-24T02:47:36,913582+00:00 systemd[1]: Created slice Slice /system/serial-getty.
2023-07-24T02:47:36,924762+00:00 systemd[1]: Created slice Slice /system/systemd-fsck.
2023-07-24T02:47:36,932958+00:00 systemd[1]: Created slice User and Session Slice.
2023-07-24T02:47:36,940034+00:00 systemd[1]: Started Forward Password Requests to Wall Directory Watch.
2023-07-24T02:47:36,949020+00:00 systemd[1]: Set up automount Arbitrary Executable File Formats File System Automount Point.
2023-07-24T02:47:36,958334+00:00 systemd[1]: Reached target Slice Units.
2023-07-24T02:47:36,964111+00:00 systemd[1]: Reached target Mounting snaps.
2023-07-24T02:47:36,970046+00:00 systemd[1]: Reached target Swaps.
2023-07-24T02:47:36,975239+00:00 systemd[1]: Reached target Local Verity Protected Volumes.
2023-07-24T02:47:36,983312+00:00 systemd[1]: Listening on Device-mapper event daemon FIFOs.
2023-07-24T02:47:36,991425+00:00 systemd[1]: Listening on LVM2 poll daemon socket.
2023-07-24T02:47:36,998272+00:00 systemd[1]: Listening on multipathd control socket.
2023-07-24T02:47:37,005851+00:00 systemd[1]: Listening on Syslog Socket.
2023-07-24T02:47:37,012244+00:00 systemd[1]: Listening on fsck to fsckd communication Socket.
2023-07-24T02:47:37,020749+00:00 systemd[1]: Listening on initctl Compatibility Named Pipe.
2023-07-24T02:47:37,028753+00:00 systemd[1]: Listening on Journal Audit Socket.
2023-07-24T02:47:37,035098+00:00 systemd[1]: Listening on Journal Socket (/dev/log).
2023-07-24T02:47:37,042154+00:00 systemd[1]: Listening on Journal Socket.
2023-07-24T02:47:37,048555+00:00 systemd[1]: Listening on Network Service Netlink Socket.
2023-07-24T02:47:37,057021+00:00 systemd[1]: Listening on udev Control Socket.
2023-07-24T02:47:37,063875+00:00 systemd[1]: Listening on udev Kernel Socket.
2023-07-24T02:47:37,072023+00:00 systemd[1]: Mounting Huge Pages File System...
2023-07-24T02:47:37,080044+00:00 systemd[1]: Mounting POSIX Message Queue File System...
2023-07-24T02:47:37,089256+00:00 systemd[1]: Mounting Kernel Debug File System...
2023-07-24T02:47:37,097414+00:00 systemd[1]: Mounting Kernel Trace File System...
2023-07-24T02:47:37,108034+00:00 systemd[1]: Starting Journal Service...
2023-07-24T02:47:37,116363+00:00 systemd[1]: Starting Set the console keyboard layout...
2023-07-24T02:47:37,125659+00:00 systemd[1]: Starting Create List of Static Device Nodes...
2023-07-24T02:47:37,134429+00:00 systemd[1]: Starting Monitoring of LVM2 mirrors, snapshots etc. using dmeventd or progress polling...
2023-07-24T02:47:37,144685+00:00 systemd[1]: Condition check resulted in LXD - agent being skipped.
2023-07-24T02:47:37,151101+00:00 systemd[1]: Starting Load Kernel Module chromeos_pstore...
2023-07-24T02:47:37,160281+00:00 systemd[1]: Starting Load Kernel Module configfs...
2023-07-24T02:47:37,169466+00:00 systemd[1]: Starting Load Kernel Module drm...
2023-07-24T02:47:37,177846+00:00 systemd[1]: Starting Load Kernel Module efi_pstore...
2023-07-24T02:47:37,186773+00:00 systemd[1]: Starting Load Kernel Module fuse...
2023-07-24T02:47:37,194526+00:00 systemd[1]: Starting Load Kernel Module pstore_blk...
2023-07-24T02:47:37,203568+00:00 systemd[1]: Starting Load Kernel Module pstore_zone...
2023-07-24T02:47:37,212773+00:00 systemd[1]: Starting Load Kernel Module ramoops...
2023-07-24T02:47:37,219513+00:00 systemd[1]: Condition check resulted in OpenVSwitch configuration for cleanup being skipped.
2023-07-24T02:47:37,233529+00:00 systemd[1]: Starting File System Check on Root Device...
2023-07-24T02:47:37,244312+00:00 systemd[1]: Starting Load Kernel Modules...
2023-07-24T02:47:37,253329+00:00 systemd[1]: Starting Coldplug All udev Devices...
2023-07-24T02:47:37,265420+00:00 systemd[1]: Started Journal Service.
2023-07-24T02:47:37,495186+00:00 EXT4-fs (vda1): re-mounted. Opts: discard,errors=remount-ro. Quota mode: none.
2023-07-24T02:47:37,533130+00:00 systemd-journald[415]: Received client request to flush runtime journal.
2023-07-24T02:47:37,540034+00:00 alua: device handler registered
2023-07-24T02:47:37,546906+00:00 emc: device handler registered
2023-07-24T02:47:37,558362+00:00 rdac: device handler registered
2023-07-24T02:47:38,312436+00:00 loop0: detected capacity change from 0 to 102072
2023-07-24T02:47:38,312647+00:00 loop1: detected capacity change from 0 to 229272
2023-07-24T02:47:38,317937+00:00 loop2: detected capacity change from 0 to 129608
2023-07-24T02:47:40,164260+00:00 audit: type=1400 audit(1690166860.412:2): apparmor="STATUS" operation="profile_load" profile="unconfined" name="nvidia_modprobe" pid=569 comm="apparmor_parser"
2023-07-24T02:47:40,166139+00:00 audit: type=1400 audit(1690166860.412:3): apparmor="STATUS" operation="profile_load" profile="unconfined" name="nvidia_modprobe//kmod" pid=569 comm="apparmor_parser"
2023-07-24T02:47:40,188699+00:00 audit: type=1400 audit(1690166860.436:4): apparmor="STATUS" operation="profile_load" profile="unconfined" name="lsb_release" pid=568 comm="apparmor_parser"
2023-07-24T02:47:40,217185+00:00 audit: type=1400 audit(1690166860.464:5): apparmor="STATUS" operation="profile_load" profile="unconfined" name="/usr/bin/man" pid=571 comm="apparmor_parser"
2023-07-24T02:47:40,218773+00:00 audit: type=1400 audit(1690166860.464:6): apparmor="STATUS" operation="profile_load" profile="unconfined" name="man_filter" pid=571 comm="apparmor_parser"
2023-07-24T02:47:40,221073+00:00 audit: type=1400 audit(1690166860.468:7): apparmor="STATUS" operation="profile_load" profile="unconfined" name="man_groff" pid=571 comm="apparmor_parser"
2023-07-24T02:47:40,506863+00:00 audit: type=1400 audit(1690166860.752:8): apparmor="STATUS" operation="profile_load" profile="unconfined" name="tcpdump" pid=572 comm="apparmor_parser"
2023-07-24T02:47:40,600300+00:00 audit: type=1400 audit(1690166860.848:9): apparmor="STATUS" operation="profile_load" profile="unconfined" name="/usr/lib/snapd/snap-confine" pid=573 comm="apparmor_parser"
2023-07-24T02:47:40,601998+00:00 audit: type=1400 audit(1690166860.848:10): apparmor="STATUS" operation="profile_load" profile="unconfined" name="/usr/lib/snapd/snap-confine//mount-namespace-capture-helper" pid=573 comm="apparmor_parser"
2023-07-24T02:47:40,659643+00:00 audit: type=1400 audit(1690166860.904:11): apparmor="STATUS" operation="profile_load" profile="unconfined" name="/usr/lib/NetworkManager/nm-dhcp-client.action" pid=570 comm="apparmor_parser"
2023-07-24T02:47:53,357772+00:00 EXT4-fs (vda1): resizing filesystem from 548091 to 78614779 blocks
2023-07-24T02:47:54,799343+00:00 EXT4-fs (vda1): resized filesystem to 78614779
2023-07-24T02:48:15,302781+00:00 loop3: detected capacity change from 0 to 8
2023-07-24T02:48:19,157961+00:00 kauditd_printk_skb: 21 callbacks suppressed
2023-07-24T02:48:19,157976+00:00 audit: type=1400 audit(1690166899.404:33): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap-update-ns.lxd" pid=920 comm="apparmor_parser"
2023-07-24T02:48:19,409964+00:00 audit: type=1400 audit(1690166899.656:34): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap.lxd.benchmark" pid=922 comm="apparmor_parser"
2023-07-24T02:48:19,411148+00:00 audit: type=1400 audit(1690166899.656:35): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap.lxd.activate" pid=921 comm="apparmor_parser"
2023-07-24T02:48:19,452254+00:00 audit: type=1400 audit(1690166899.700:36): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap.lxd.buginfo" pid=923 comm="apparmor_parser"
2023-07-24T02:48:19,588918+00:00 audit: type=1400 audit(1690166899.836:37): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap.lxd.hook.install" pid=927 comm="apparmor_parser"
2023-07-24T02:48:19,591072+00:00 audit: type=1400 audit(1690166899.836:38): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap.lxd.check-kernel" pid=924 comm="apparmor_parser"
2023-07-24T02:48:19,642195+00:00 audit: type=1400 audit(1690166899.888:39): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap.lxd.hook.configure" pid=926 comm="apparmor_parser"
2023-07-24T02:48:19,665565+00:00 audit: type=1400 audit(1690166899.912:40): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap.lxd.daemon" pid=925 comm="apparmor_parser"
2023-07-24T02:48:19,705568+00:00 audit: type=1400 audit(1690166899.952:41): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap.lxd.lxc" pid=930 comm="apparmor_parser"
2023-07-24T02:48:19,735639+00:00 audit: type=1400 audit(1690166899.980:42): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap.lxd.lxc-to-lxd" pid=931 comm="apparmor_parser"
2023-07-24T07:03:10,970397+00:00 kauditd_printk_skb: 8 callbacks suppressed
2023-07-24T07:03:10,970415+00:00 audit: type=1400 audit(1690182191.216:51): apparmor="STATUS" operation="profile_load" profile="unconfined" name="docker-default" pid=10942 comm="apparmor_parser"
2023-07-24T07:03:12,064316+00:00 bridge: filtering via arp/ip/ip6tables is no longer available by default. Update your scripts to load br_netfilter if you need this.
2023-07-24T07:03:12,078157+00:00 Bridge firewalling registered
2023-07-24T07:03:12,720283+00:00 Initializing XFRM netlink socket
2023-07-24T08:08:42,600342+00:00 audit: type=1400 audit(1690186122.848:52): apparmor="STATUS" operation="profile_load" profile="unconfined" name="/usr/sbin/chronyd" pid=14001 comm="apparmor_parser"
2023-07-24T22:18:45,933856+00:00 audit: type=1400 audit(1690237126.178:53): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="/usr/lib/snapd/snap-confine" pid=81758 comm="apparmor_parser"
2023-07-24T22:18:45,935401+00:00 audit: type=1400 audit(1690237126.178:54): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="/usr/lib/snapd/snap-confine//mount-namespace-capture-helper" pid=81758 comm="apparmor_parser"
2023-07-24T22:18:50,419503+00:00 loop3: detected capacity change from 0 to 8
2023-07-24T22:19:55,083093+00:00 loop3: detected capacity change from 0 to 8
2023-07-24T22:19:56,134611+00:00 audit: type=1400 audit(1690237196.378:55): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap-update-ns.lxd" pid=82219 comm="apparmor_parser"
2023-07-24T22:19:56,153933+00:00 audit: type=1400 audit(1690237196.390:56): apparmor="STATUS" operation="profile_replace" profile="unconfined" name="/snap/snapd/18357/usr/lib/snapd/snap-confine" pid=82218 comm="apparmor_parser"
2023-07-24T22:19:56,184143+00:00 audit: type=1400 audit(1690237196.430:57): apparmor="STATUS" operation="profile_replace" profile="unconfined" name="/snap/snapd/18357/usr/lib/snapd/snap-confine//mount-namespace-capture-helper" pid=82218 comm="apparmor_parser"
2023-07-24T22:19:56,184498+00:00 audit: type=1400 audit(1690237196.430:58): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap.lxd.buginfo" pid=82222 comm="apparmor_parser"
2023-07-24T22:19:56,184823+00:00 audit: type=1400 audit(1690237196.430:59): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap.lxd.check-kernel" pid=82223 comm="apparmor_parser"
2023-07-24T22:19:56,185572+00:00 audit: type=1400 audit(1690237196.430:60): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap.lxd.benchmark" pid=82221 comm="apparmor_parser"
2023-07-24T22:19:56,187831+00:00 audit: type=1400 audit(1690237196.430:61): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap.lxd.daemon" pid=82224 comm="apparmor_parser"
2023-07-24T22:19:56,188391+00:00 audit: type=1400 audit(1690237196.434:62): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap.lxd.hook.configure" pid=82225 comm="apparmor_parser"
2023-07-24T22:19:56,188972+00:00 audit: type=1400 audit(1690237196.434:63): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap.lxd.activate" pid=82220 comm="apparmor_parser"
2023-07-24T22:19:56,189227+00:00 audit: type=1400 audit(1690237196.434:64): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap.lxd.hook.install" pid=82226 comm="apparmor_parser"
2023-07-25T10:47:37,046596+00:00 IPVS: Registered protocols (TCP, UDP, SCTP, AH, ESP)
2023-07-25T10:47:37,046671+00:00 IPVS: Connection hash table configured (size=4096, memory=32Kbytes)
2023-07-25T10:47:37,046900+00:00 IPVS: ipvs loaded.
2023-07-25T10:47:37,184481+00:00 IPVS: [rr] scheduler registered.
2023-07-25T10:47:37,225201+00:00 IPVS: [wrr] scheduler registered.
2023-07-25T10:47:37,244144+00:00 IPVS: [sh] scheduler registered.
2023-07-25T12:45:38,221199+00:00 wireguard: WireGuard 1.0.0 loaded. See www.wireguard.com for information.
2023-07-25T12:45:38,221353+00:00 wireguard: Copyright (C) 2015-2019 Jason A. Donenfeld <Jason@zx2c4.com>. All Rights Reserved.
