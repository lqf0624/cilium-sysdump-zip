Total: 495
TCP:   262 (estab 236, closed 11, orphaned 0, timewait 11)

Transport Total     IP        IPv6
RAW	  2         1         1        
UDP	  8         6         2        
TCP	  251       246       5        
INET	  261       253       8        
FRAG	  0         0         0        

State  Recv-Q Send-Q     Local Address:Port   Peer Address:Port  Process                              
UNCONN 0      0                0.0.0.0:4789        0.0.0.0:*                                          
ESTAB  0      0           10.26.65.226:47802     223.5.5.5:domain                                     
UNCONN 0      0          127.0.0.53%lo:domain      0.0.0.0:*                                          
UNCONN 0      0      10.26.65.226%ens3:bootpc      0.0.0.0:*                                          
UNCONN 0      0              127.0.0.1:323         0.0.0.0:*                                          
ESTAB  0      0           10.26.65.226:34347     223.5.5.5:domain                                     
UNCONN 0      0                      *:36637             *:*      users:(("cilium-agent",pid=1,fd=19))
UNCONN 0      0                  [::1]:323            [::]:*                                          
