CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    11687    device          multi                          
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    11686    ingress         multi                          
    11685    egress          multi                          
    11684    device          multi                          
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    11676    ingress         multi                          
    11675    egress          multi                          
    11674    device          multi                          
/run/cilium/cgroupv2/system.slice/chrony.service
    11688    device          multi                          
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    11683    device          multi                          
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    11680    ingress         multi                          
    11679    egress          multi                          
    11678    device          multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfcd8eb2a_25de_48bc_9998_e9fe689e11d9.slice/docker-738c733da5248bddaf4794f20d5563eb00ed133ee1938cc75c32180bfe80347e.scope
    11825    device          multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podfcd8eb2a_25de_48bc_9998_e9fe689e11d9.slice/docker-ada955d766dc9207c476097c97536bc2fc1a7468cc7784eb63595d0cfa8f5f6d.scope
    11808    device          multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf30c9760_0150_443c_b4cf_ac4d974798d9.slice/docker-27896b605c75de819a9b82ce046e253d3f552d2ad767132201de9cdf2618f7e4.scope
    507      device          multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf30c9760_0150_443c_b4cf_ac4d974798d9.slice/docker-fd8790d7144f68e9924a8c598fed6252f7d71773662bc73692e62af03ebdefa2.scope
    504      device          multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3ab9f489_c1c0_4391_a12b_220c8ac72f0c.slice/docker-d784087cc8b3e21353889bfc082567c801101a2ecef3269f1bcf15675f6b2fa8.scope
    12582    device          multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3ab9f489_c1c0_4391_a12b_220c8ac72f0c.slice/docker-c99e4f944eef5e1e95b0f1818d3057610e1a1bb73624f47b48b3f74c71918f5f.scope
    11812    device          multi                          
