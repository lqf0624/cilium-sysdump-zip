CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    11575    device          multi                          
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    11574    ingress         multi                          
    11573    egress          multi                          
    11572    device          multi                          
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    11571    ingress         multi                          
    11570    egress          multi                          
    11569    device          multi                          
/run/cilium/cgroupv2/system.slice/chrony.service
    11576    device          multi                          
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    11582    device          multi                          
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    11566    ingress         multi                          
    11565    egress          multi                          
    11564    device          multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod73c20fd4_5f85_46fd_a6b8_c72ebc04fcd0.slice/docker-8a3ae46ba64a2d3d69770c8ce8b9f4886387e918d035f86e2e9b14a01753ec3c.scope
    11697    device          multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod73c20fd4_5f85_46fd_a6b8_c72ebc04fcd0.slice/docker-d7ea0fd7404581e1356b214a07f21d8dbce7ad1f68f19e62def43aab782ba222.scope
    11706    device          multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd6c9a00a_e569_4677_8ea0_302f6d478c30.slice/docker-032ba83d2540dad3080b0fefe799c7395762e234039605599d4c088ded7a44f6.scope
    493      device          multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd6c9a00a_e569_4677_8ea0_302f6d478c30.slice/docker-eafa98d7d4cbbd6d27ec9fcbebef0812953aeedaa959d661a488f587b2063263.scope
    496      device          multi                          
