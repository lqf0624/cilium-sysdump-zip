2023-07-24T02:55:00,000000+00:00 Linux version 5.15.0-67-generic (buildd@lcy02-amd64-116) (gcc (Ubuntu 11.3.0-1ubuntu1~22.04) 11.3.0, GNU ld (GNU Binutils for Ubuntu) 2.38) #74-Ubuntu SMP Wed Feb 22 14:14:39 UTC 2023 (Ubuntu 5.15.0-67.74-generic 5.15.85)
2023-07-24T02:55:00,000000+00:00 Command line: BOOT_IMAGE=/boot/vmlinuz-5.15.0-67-generic root=LABEL=cloudimg-rootfs ro console=tty1 console=ttyS0
2023-07-24T02:55:00,000000+00:00 KERNEL supported cpus:
2023-07-24T02:55:00,000000+00:00   Intel GenuineIntel
2023-07-24T02:55:00,000000+00:00   AMD AuthenticAMD
2023-07-24T02:55:00,000000+00:00   Hygon HygonGenuine
2023-07-24T02:55:00,000000+00:00   Centaur CentaurHauls
2023-07-24T02:55:00,000000+00:00   zhaoxin   Shanghai  
2023-07-24T02:55:00,000000+00:00 x86/fpu: Supporting XSAVE feature 0x001: 'x87 floating point registers'
2023-07-24T02:55:00,000000+00:00 x86/fpu: Supporting XSAVE feature 0x002: 'SSE registers'
2023-07-24T02:55:00,000000+00:00 x86/fpu: Supporting XSAVE feature 0x004: 'AVX registers'
2023-07-24T02:55:00,000000+00:00 x86/fpu: xstate_offset[2]:  576, xstate_sizes[2]:  256
2023-07-24T02:55:00,000000+00:00 x86/fpu: Enabled xstate features 0x7, context size is 832 bytes, using 'standard' format.
2023-07-24T02:55:00,000000+00:00 signal: max sigframe size: 1776
2023-07-24T02:55:00,000000+00:00 BIOS-provided physical RAM map:
2023-07-24T02:55:00,000000+00:00 BIOS-e820: [mem 0x0000000000000000-0x000000000009fbff] usable
2023-07-24T02:55:00,000000+00:00 BIOS-e820: [mem 0x000000000009fc00-0x000000000009ffff] reserved
2023-07-24T02:55:00,000000+00:00 BIOS-e820: [mem 0x00000000000f0000-0x00000000000fffff] reserved
2023-07-24T02:55:00,000000+00:00 BIOS-e820: [mem 0x0000000000100000-0x00000000bffdbfff] usable
2023-07-24T02:55:00,000000+00:00 BIOS-e820: [mem 0x00000000bffdc000-0x00000000bfffffff] reserved
2023-07-24T02:55:00,000000+00:00 BIOS-e820: [mem 0x00000000feffc000-0x00000000feffffff] reserved
2023-07-24T02:55:00,000000+00:00 BIOS-e820: [mem 0x00000000fffc0000-0x00000000ffffffff] reserved
2023-07-24T02:55:00,000000+00:00 BIOS-e820: [mem 0x0000000100000000-0x0000000427ffffff] usable
2023-07-24T02:55:00,000000+00:00 NX (Execute Disable) protection: active
2023-07-24T02:55:00,000000+00:00 SMBIOS 2.8 present.
2023-07-24T02:55:00,000000+00:00 DMI: OpenStack Foundation OpenStack Nova, BIOS 1.10.2-1ubuntu1 04/01/2014
2023-07-24T02:55:00,000000+00:00 Hypervisor detected: KVM
2023-07-24T02:55:00,000000+00:00 kvm-clock: Using msrs 4b564d01 and 4b564d00
2023-07-24T02:55:00,000000+00:00 kvm-clock: cpu 0, msr 9d601001, primary cpu clock
2023-07-24T02:55:00,000024+00:00 kvm-clock: using sched offset of 3032561527 cycles
2023-07-24T02:55:00,000050+00:00 clocksource: kvm-clock: mask: 0xffffffffffffffff max_cycles: 0x1cd42e4dffb, max_idle_ns: 881590591483 ns
2023-07-24T02:55:00,000065+00:00 tsc: Detected 1999.993 MHz processor
2023-07-24T02:55:00,001399+00:00 e820: update [mem 0x00000000-0x00000fff] usable ==> reserved
2023-07-24T02:55:00,001407+00:00 e820: remove [mem 0x000a0000-0x000fffff] usable
2023-07-24T02:55:00,001421+00:00 last_pfn = 0x428000 max_arch_pfn = 0x400000000
2023-07-24T02:55:00,001512+00:00 x86/PAT: Configuration [0-7]: WB  WC  UC- UC  WB  WP  UC- WT  
2023-07-24T02:55:00,001547+00:00 last_pfn = 0xbffdc max_arch_pfn = 0x400000000
2023-07-24T02:55:00,021058+00:00 found SMP MP-table at [mem 0x000f69f0-0x000f69ff]
2023-07-24T02:55:00,021112+00:00 Using GB pages for direct mapping
2023-07-24T02:55:00,022378+00:00 RAMDISK: [mem 0x34257000-0x36122fff]
2023-07-24T02:55:00,022403+00:00 ACPI: Early table checksum verification disabled
2023-07-24T02:55:00,022436+00:00 ACPI: RSDP 0x00000000000F69A0 000014 (v00 BOCHS )
2023-07-24T02:55:00,022447+00:00 ACPI: RSDT 0x00000000BFFE1460 00002C (v01 BOCHS  BXPCRSDT 00000001 BXPC 00000001)
2023-07-24T02:55:00,022503+00:00 ACPI: FACP 0x00000000BFFE12BC 000074 (v01 BOCHS  BXPCFACP 00000001 BXPC 00000001)
2023-07-24T02:55:00,022522+00:00 ACPI: DSDT 0x00000000BFFDFC80 00163C (v01 BOCHS  BXPCDSDT 00000001 BXPC 00000001)
2023-07-24T02:55:00,022535+00:00 ACPI: FACS 0x00000000BFFDFC40 000040
2023-07-24T02:55:00,022544+00:00 ACPI: APIC 0x00000000BFFE13B0 0000B0 (v01 BOCHS  BXPCAPIC 00000001 BXPC 00000001)
2023-07-24T02:55:00,022551+00:00 ACPI: Reserving FACP table memory at [mem 0xbffe12bc-0xbffe132f]
2023-07-24T02:55:00,022554+00:00 ACPI: Reserving DSDT table memory at [mem 0xbffdfc80-0xbffe12bb]
2023-07-24T02:55:00,022556+00:00 ACPI: Reserving FACS table memory at [mem 0xbffdfc40-0xbffdfc7f]
2023-07-24T02:55:00,022558+00:00 ACPI: Reserving APIC table memory at [mem 0xbffe13b0-0xbffe145f]
2023-07-24T02:55:00,023548+00:00 No NUMA configuration found
2023-07-24T02:55:00,023553+00:00 Faking a node at [mem 0x0000000000000000-0x0000000427ffffff]
2023-07-24T02:55:00,023573+00:00 NODE_DATA(0) allocated [mem 0x427fd4000-0x427ffdfff]
2023-07-24T02:55:00,024311+00:00 Zone ranges:
2023-07-24T02:55:00,024315+00:00   DMA      [mem 0x0000000000001000-0x0000000000ffffff]
2023-07-24T02:55:00,024319+00:00   DMA32    [mem 0x0000000001000000-0x00000000ffffffff]
2023-07-24T02:55:00,024322+00:00   Normal   [mem 0x0000000100000000-0x0000000427ffffff]
2023-07-24T02:55:00,024326+00:00   Device   empty
2023-07-24T02:55:00,024338+00:00 Movable zone start for each node
2023-07-24T02:55:00,024343+00:00 Early memory node ranges
2023-07-24T02:55:00,024345+00:00   node   0: [mem 0x0000000000001000-0x000000000009efff]
2023-07-24T02:55:00,024347+00:00   node   0: [mem 0x0000000000100000-0x00000000bffdbfff]
2023-07-24T02:55:00,024350+00:00   node   0: [mem 0x0000000100000000-0x0000000427ffffff]
2023-07-24T02:55:00,024355+00:00 Initmem setup node 0 [mem 0x0000000000001000-0x0000000427ffffff]
2023-07-24T02:55:00,025115+00:00 On node 0, zone DMA: 1 pages in unavailable ranges
2023-07-24T02:55:00,025175+00:00 On node 0, zone DMA: 97 pages in unavailable ranges
2023-07-24T02:55:00,174225+00:00 On node 0, zone Normal: 36 pages in unavailable ranges
2023-07-24T02:55:00,175371+00:00 ACPI: PM-Timer IO Port: 0x608
2023-07-24T02:55:00,175422+00:00 ACPI: LAPIC_NMI (acpi_id[0xff] dfl dfl lint[0x1])
2023-07-24T02:55:00,175517+00:00 IOAPIC[0]: apic_id 0, version 17, address 0xfec00000, GSI 0-23
2023-07-24T02:55:00,175526+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 0 global_irq 2 dfl dfl)
2023-07-24T02:55:00,175535+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 5 global_irq 5 high level)
2023-07-24T02:55:00,175537+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 9 global_irq 9 high level)
2023-07-24T02:55:00,175544+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 10 global_irq 10 high level)
2023-07-24T02:55:00,175546+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 11 global_irq 11 high level)
2023-07-24T02:55:00,175555+00:00 ACPI: Using ACPI (MADT) for SMP configuration information
2023-07-24T02:55:00,175564+00:00 TSC deadline timer available
2023-07-24T02:55:00,175568+00:00 smpboot: Allowing 8 CPUs, 0 hotplug CPUs
2023-07-24T02:55:00,175643+00:00 PM: hibernation: Registered nosave memory: [mem 0x00000000-0x00000fff]
2023-07-24T02:55:00,175647+00:00 PM: hibernation: Registered nosave memory: [mem 0x0009f000-0x0009ffff]
2023-07-24T02:55:00,175650+00:00 PM: hibernation: Registered nosave memory: [mem 0x000a0000-0x000effff]
2023-07-24T02:55:00,175652+00:00 PM: hibernation: Registered nosave memory: [mem 0x000f0000-0x000fffff]
2023-07-24T02:55:00,175655+00:00 PM: hibernation: Registered nosave memory: [mem 0xbffdc000-0xbfffffff]
2023-07-24T02:55:00,175658+00:00 PM: hibernation: Registered nosave memory: [mem 0xc0000000-0xfeffbfff]
2023-07-24T02:55:00,175660+00:00 PM: hibernation: Registered nosave memory: [mem 0xfeffc000-0xfeffffff]
2023-07-24T02:55:00,175662+00:00 PM: hibernation: Registered nosave memory: [mem 0xff000000-0xfffbffff]
2023-07-24T02:55:00,175664+00:00 PM: hibernation: Registered nosave memory: [mem 0xfffc0000-0xffffffff]
2023-07-24T02:55:00,175667+00:00 [mem 0xc0000000-0xfeffbfff] available for PCI devices
2023-07-24T02:55:00,175670+00:00 Booting paravirtualized kernel on KVM
2023-07-24T02:55:00,175681+00:00 clocksource: refined-jiffies: mask: 0xffffffff max_cycles: 0xffffffff, max_idle_ns: 7645519600211568 ns
2023-07-24T02:55:00,175695+00:00 setup_percpu: NR_CPUS:8192 nr_cpumask_bits:8 nr_cpu_ids:8 nr_node_ids:1
2023-07-24T02:55:00,176858+00:00 percpu: Embedded 60 pages/cpu s208896 r8192 d28672 u262144
2023-07-24T02:55:00,176895+00:00 pcpu-alloc: s208896 r8192 d28672 u262144 alloc=1*2097152
2023-07-24T02:55:00,176900+00:00 pcpu-alloc: [0] 0 1 2 3 4 5 6 7 
2023-07-24T02:55:00,176953+00:00 kvm-guest: stealtime: cpu 0, msr 418232080
2023-07-24T02:55:00,176959+00:00 kvm-guest: PV spinlocks disabled, no host support
2023-07-24T02:55:00,176990+00:00 Built 1 zonelists, mobility grouping on.  Total pages: 4031708
2023-07-24T02:55:00,176993+00:00 Policy zone: Normal
2023-07-24T02:55:00,176996+00:00 Kernel command line: BOOT_IMAGE=/boot/vmlinuz-5.15.0-67-generic root=LABEL=cloudimg-rootfs ro console=tty1 console=ttyS0
2023-07-24T02:55:00,177095+00:00 Unknown kernel command line parameters "BOOT_IMAGE=/boot/vmlinuz-5.15.0-67-generic", will be passed to user space.
2023-07-24T02:55:00,183953+00:00 Dentry cache hash table entries: 2097152 (order: 12, 16777216 bytes, linear)
2023-07-24T02:55:00,187305+00:00 Inode-cache hash table entries: 1048576 (order: 11, 8388608 bytes, linear)
2023-07-24T02:55:00,187654+00:00 mem auto-init: stack:off, heap alloc:on, heap free:off
2023-07-24T02:55:00,300216+00:00 Memory: 15956880K/16383464K available (16393K kernel code, 4379K rwdata, 10820K rodata, 3240K init, 6556K bss, 426324K reserved, 0K cma-reserved)
2023-07-24T02:55:00,300832+00:00 SLUB: HWalign=64, Order=0-3, MinObjects=0, CPUs=8, Nodes=1
2023-07-24T02:55:00,300881+00:00 Kernel/User page tables isolation: enabled
2023-07-24T02:55:00,300962+00:00 ftrace: allocating 50555 entries in 198 pages
2023-07-24T02:55:00,345949+00:00 ftrace: allocated 198 pages with 4 groups
2023-07-24T02:55:00,347162+00:00 rcu: Hierarchical RCU implementation.
2023-07-24T02:55:00,347168+00:00 rcu: 	RCU restricting CPUs from NR_CPUS=8192 to nr_cpu_ids=8.
2023-07-24T02:55:00,347173+00:00 	Rude variant of Tasks RCU enabled.
2023-07-24T02:55:00,347176+00:00 	Tracing variant of Tasks RCU enabled.
2023-07-24T02:55:00,347203+00:00 rcu: RCU calculated value of scheduler-enlistment delay is 25 jiffies.
2023-07-24T02:55:00,347212+00:00 rcu: Adjusting geometry for rcu_fanout_leaf=16, nr_cpu_ids=8
2023-07-24T02:55:00,354659+00:00 NR_IRQS: 524544, nr_irqs: 488, preallocated irqs: 16
2023-07-24T02:55:00,354941+00:00 random: crng init done
2023-07-24T02:55:00,380370+00:00 Console: colour VGA+ 80x25
2023-07-24T02:55:00,459512+00:00 printk: console [tty1] enabled
2023-07-24T02:55:00,884306+00:00 printk: console [ttyS0] enabled
2023-07-24T02:55:00,887493+00:00 ACPI: Core revision 20210730
2023-07-24T02:55:00,891544+00:00 APIC: Switch to symmetric I/O mode setup
2023-07-24T02:55:00,895883+00:00 x2apic enabled
2023-07-24T02:55:00,898701+00:00 Switched APIC routing to physical x2apic.
2023-07-24T02:55:00,905523+00:00 clocksource: tsc-early: mask: 0xffffffffffffffff max_cycles: 0x39a84ecfd44, max_idle_ns: 881590442549 ns
2023-07-24T02:55:00,914486+00:00 Calibrating delay loop (skipped) preset value.. 3999.98 BogoMIPS (lpj=7999972)
2023-07-24T02:55:00,918450+00:00 pid_max: default: 32768 minimum: 301
2023-07-24T02:55:00,918450+00:00 LSM: Security Framework initializing
2023-07-24T02:55:00,918450+00:00 landlock: Up and running.
2023-07-24T02:55:00,918450+00:00 Yama: becoming mindful.
2023-07-24T02:55:00,918450+00:00 AppArmor: AppArmor initialized
2023-07-24T02:55:00,918450+00:00 Mount-cache hash table entries: 32768 (order: 6, 262144 bytes, linear)
2023-07-24T02:55:00,918450+00:00 Mountpoint-cache hash table entries: 32768 (order: 6, 262144 bytes, linear)
2023-07-24T02:55:00,918450+00:00 Last level iTLB entries: 4KB 0, 2MB 0, 4MB 0
2023-07-24T02:55:00,918450+00:00 Last level dTLB entries: 4KB 0, 2MB 0, 4MB 0, 1GB 0
2023-07-24T02:55:00,918450+00:00 Spectre V1 : Mitigation: usercopy/swapgs barriers and __user pointer sanitization
2023-07-24T02:55:00,918450+00:00 Spectre V2 : Mitigation: Retpolines
2023-07-24T02:55:00,918450+00:00 Spectre V2 : Spectre v2 / SpectreRSB mitigation: Filling RSB on context switch
2023-07-24T02:55:00,918450+00:00 Spectre V2 : Spectre v2 / SpectreRSB : Filling RSB on VMEXIT
2023-07-24T02:55:00,918450+00:00 Spectre V2 : Enabling Restricted Speculation for firmware calls
2023-07-24T02:55:00,918450+00:00 Spectre V2 : mitigation: Enabling conditional Indirect Branch Prediction Barrier
2023-07-24T02:55:00,918450+00:00 Speculative Store Bypass: Mitigation: Speculative Store Bypass disabled via prctl and seccomp
2023-07-24T02:55:00,918450+00:00 MDS: Mitigation: Clear CPU buffers
2023-07-24T02:55:00,918450+00:00 MMIO Stale Data: Unknown: No mitigations
2023-07-24T02:55:00,918450+00:00 SRBDS: Unknown: Dependent on hypervisor status
2023-07-24T02:55:00,918450+00:00 Freeing SMP alternatives memory: 44K
2023-07-24T02:55:00,918450+00:00 smpboot: CPU0: Intel Xeon E3-12xx v2 (Ivy Bridge, IBRS) (family: 0x6, model: 0x3a, stepping: 0x9)
2023-07-24T02:55:00,918844+00:00 Performance Events: unsupported p6 CPU model 58 no PMU driver, software events only.
2023-07-24T02:55:00,922559+00:00 rcu: Hierarchical SRCU implementation.
2023-07-24T02:55:00,927146+00:00 NMI watchdog: Perf NMI watchdog permanently disabled
2023-07-24T02:55:00,930754+00:00 smp: Bringing up secondary CPUs ...
2023-07-24T02:55:00,935516+00:00 x86: Booting SMP configuration:
2023-07-24T02:55:00,938462+00:00 .... node  #0, CPUs:      #1
2023-07-24T02:55:00,563529+00:00 kvm-clock: cpu 1, msr 9d601041, secondary cpu clock
2023-07-24T02:55:00,563529+00:00 smpboot: CPU 1 Converting physical 0 to logical die 1
2023-07-24T02:55:00,950545+00:00 kvm-guest: stealtime: cpu 1, msr 418272080
2023-07-24T02:55:00,953924+00:00  #2
2023-07-24T02:55:00,563529+00:00 kvm-clock: cpu 2, msr 9d601081, secondary cpu clock
2023-07-24T02:55:00,563529+00:00 smpboot: CPU 2 Converting physical 0 to logical die 2
2023-07-24T02:55:00,962506+00:00 kvm-guest: stealtime: cpu 2, msr 4182b2080
2023-07-24T02:55:00,965860+00:00  #3
2023-07-24T02:55:00,563529+00:00 kvm-clock: cpu 3, msr 9d6010c1, secondary cpu clock
2023-07-24T02:55:00,563529+00:00 smpboot: CPU 3 Converting physical 0 to logical die 3
2023-07-24T02:55:00,974492+00:00 kvm-guest: stealtime: cpu 3, msr 4182f2080
2023-07-24T02:55:00,977701+00:00  #4
2023-07-24T02:55:00,563529+00:00 kvm-clock: cpu 4, msr 9d601101, secondary cpu clock
2023-07-24T02:55:00,563529+00:00 smpboot: CPU 4 Converting physical 0 to logical die 4
2023-07-24T02:55:00,986491+00:00 kvm-guest: stealtime: cpu 4, msr 418332080
2023-07-24T02:55:00,989585+00:00  #5
2023-07-24T02:55:00,563529+00:00 kvm-clock: cpu 5, msr 9d601141, secondary cpu clock
2023-07-24T02:55:00,563529+00:00 smpboot: CPU 5 Converting physical 0 to logical die 5
2023-07-24T02:55:00,998511+00:00 kvm-guest: stealtime: cpu 5, msr 418372080
2023-07-24T02:55:01,001537+00:00  #6
2023-07-24T02:55:00,563529+00:00 kvm-clock: cpu 6, msr 9d601181, secondary cpu clock
2023-07-24T02:55:00,563529+00:00 smpboot: CPU 6 Converting physical 0 to logical die 6
2023-07-24T02:55:01,014496+00:00 kvm-guest: stealtime: cpu 6, msr 4183b2080
2023-07-24T02:55:01,018792+00:00  #7
2023-07-24T02:55:00,563529+00:00 kvm-clock: cpu 7, msr 9d6011c1, secondary cpu clock
2023-07-24T02:55:00,563529+00:00 smpboot: CPU 7 Converting physical 0 to logical die 7
2023-07-24T02:55:01,026489+00:00 kvm-guest: stealtime: cpu 7, msr 4183f2080
2023-07-24T02:55:01,029480+00:00 smp: Brought up 1 node, 8 CPUs
2023-07-24T02:55:01,030468+00:00 smpboot: Max logical packages: 8
2023-07-24T02:55:01,034478+00:00 smpboot: Total of 8 processors activated (31999.88 BogoMIPS)
2023-07-24T02:55:01,041221+00:00 devtmpfs: initialized
2023-07-24T02:55:01,042574+00:00 x86/mm: Memory block size: 128MB
2023-07-24T02:55:01,049142+00:00 clocksource: jiffies: mask: 0xffffffff max_cycles: 0xffffffff, max_idle_ns: 7645041785100000 ns
2023-07-24T02:55:01,050482+00:00 futex hash table entries: 2048 (order: 5, 131072 bytes, linear)
2023-07-24T02:55:01,054604+00:00 pinctrl core: initialized pinctrl subsystem
2023-07-24T02:55:01,058996+00:00 PM: RTC time: 02:55:00, date: 2023-07-24
2023-07-24T02:55:01,062992+00:00 NET: Registered PF_NETLINK/PF_ROUTE protocol family
2023-07-24T02:55:01,067653+00:00 DMA: preallocated 2048 KiB GFP_KERNEL pool for atomic allocations
2023-07-24T02:55:01,071255+00:00 DMA: preallocated 2048 KiB GFP_KERNEL|GFP_DMA pool for atomic allocations
2023-07-24T02:55:01,075379+00:00 DMA: preallocated 2048 KiB GFP_KERNEL|GFP_DMA32 pool for atomic allocations
2023-07-24T02:55:01,078478+00:00 audit: initializing netlink subsys (disabled)
2023-07-24T02:55:01,082206+00:00 audit: type=2000 audit(1690167300.651:1): state=initialized audit_enabled=0 res=1
2023-07-24T02:55:01,082666+00:00 thermal_sys: Registered thermal governor 'fair_share'
2023-07-24T02:55:01,086457+00:00 thermal_sys: Registered thermal governor 'bang_bang'
2023-07-24T02:55:01,090251+00:00 thermal_sys: Registered thermal governor 'step_wise'
2023-07-24T02:55:01,090458+00:00 thermal_sys: Registered thermal governor 'user_space'
2023-07-24T02:55:01,094320+00:00 thermal_sys: Registered thermal governor 'power_allocator'
2023-07-24T02:55:01,094472+00:00 EISA bus registered
2023-07-24T02:55:01,100940+00:00 cpuidle: using governor ladder
2023-07-24T02:55:01,102470+00:00 cpuidle: using governor menu
2023-07-24T02:55:01,105786+00:00 ACPI: bus type PCI registered
2023-07-24T02:55:01,106460+00:00 acpiphp: ACPI Hot Plug PCI Controller Driver version: 0.5
2023-07-24T02:55:01,110758+00:00 PCI: Using configuration type 1 for base access
2023-07-24T02:55:01,117031+00:00 Kprobes globally optimized
2023-07-24T02:55:01,119391+00:00 HugeTLB registered 1.00 GiB page size, pre-allocated 0 pages
2023-07-24T02:55:01,122463+00:00 HugeTLB registered 2.00 MiB page size, pre-allocated 0 pages
2023-07-24T02:55:01,131352+00:00 ACPI: Added _OSI(Module Device)
2023-07-24T02:55:01,134477+00:00 ACPI: Added _OSI(Processor Device)
2023-07-24T02:55:01,138156+00:00 ACPI: Added _OSI(3.0 _SCP Extensions)
2023-07-24T02:55:01,138459+00:00 ACPI: Added _OSI(Processor Aggregator Device)
2023-07-24T02:55:01,142459+00:00 ACPI: Added _OSI(Linux-Dell-Video)
2023-07-24T02:55:01,145541+00:00 ACPI: Added _OSI(Linux-Lenovo-NV-HDMI-Audio)
2023-07-24T02:55:01,146466+00:00 ACPI: Added _OSI(Linux-HPI-Hybrid-Graphics)
2023-07-24T02:55:01,151992+00:00 ACPI: 1 ACPI AML tables successfully acquired and loaded
2023-07-24T02:55:01,157429+00:00 ACPI: Interpreter enabled
2023-07-24T02:55:01,158508+00:00 ACPI: PM: (supports S0 S3 S4 S5)
2023-07-24T02:55:01,161992+00:00 ACPI: Using IOAPIC for interrupt routing
2023-07-24T02:55:01,162514+00:00 PCI: Using host bridge windows from ACPI; if necessary, use "pci=nocrs" and report a bug
2023-07-24T02:55:01,166458+00:00 PCI: Using E820 reservations for host bridge windows
2023-07-24T02:55:01,170627+00:00 ACPI: Enabled 2 GPEs in block 00 to 0F
2023-07-24T02:55:01,179955+00:00 ACPI: PCI Root Bridge [PCI0] (domain 0000 [bus 00-ff])
2023-07-24T02:55:01,182471+00:00 acpi PNP0A03:00: _OSC: OS supports [ASPM ClockPM Segments MSI EDR HPX-Type3]
2023-07-24T02:55:01,186482+00:00 acpi PNP0A03:00: fail to add MMCONFIG information, can't access extended PCI configuration space under this bridge.
2023-07-24T02:55:01,191037+00:00 acpiphp: Slot [3] registered
2023-07-24T02:55:01,194515+00:00 acpiphp: Slot [4] registered
2023-07-24T02:55:01,197960+00:00 acpiphp: Slot [5] registered
2023-07-24T02:55:01,198504+00:00 acpiphp: Slot [6] registered
2023-07-24T02:55:01,201778+00:00 acpiphp: Slot [7] registered
2023-07-24T02:55:01,202503+00:00 acpiphp: Slot [8] registered
2023-07-24T02:55:01,205869+00:00 acpiphp: Slot [9] registered
2023-07-24T02:55:01,206510+00:00 acpiphp: Slot [10] registered
2023-07-24T02:55:01,209387+00:00 acpiphp: Slot [11] registered
2023-07-24T02:55:01,210503+00:00 acpiphp: Slot [12] registered
2023-07-24T02:55:01,213600+00:00 acpiphp: Slot [13] registered
2023-07-24T02:55:01,214503+00:00 acpiphp: Slot [14] registered
2023-07-24T02:55:01,217627+00:00 acpiphp: Slot [15] registered
2023-07-24T02:55:01,218503+00:00 acpiphp: Slot [16] registered
2023-07-24T02:55:01,221354+00:00 acpiphp: Slot [17] registered
2023-07-24T02:55:01,222507+00:00 acpiphp: Slot [18] registered
2023-07-24T02:55:01,225376+00:00 acpiphp: Slot [19] registered
2023-07-24T02:55:01,226503+00:00 acpiphp: Slot [20] registered
2023-07-24T02:55:01,229513+00:00 acpiphp: Slot [21] registered
2023-07-24T02:55:01,230504+00:00 acpiphp: Slot [22] registered
2023-07-24T02:55:01,233507+00:00 acpiphp: Slot [23] registered
2023-07-24T02:55:01,234508+00:00 acpiphp: Slot [24] registered
2023-07-24T02:55:01,237202+00:00 acpiphp: Slot [25] registered
2023-07-24T02:55:01,238504+00:00 acpiphp: Slot [26] registered
2023-07-24T02:55:01,241995+00:00 acpiphp: Slot [27] registered
2023-07-24T02:55:01,242505+00:00 acpiphp: Slot [28] registered
2023-07-24T02:55:01,245464+00:00 acpiphp: Slot [29] registered
2023-07-24T02:55:01,246509+00:00 acpiphp: Slot [30] registered
2023-07-24T02:55:01,250284+00:00 acpiphp: Slot [31] registered
2023-07-24T02:55:01,250495+00:00 PCI host bridge to bus 0000:00
2023-07-24T02:55:01,253512+00:00 pci_bus 0000:00: root bus resource [bus 00-ff]
2023-07-24T02:55:01,254460+00:00 pci_bus 0000:00: root bus resource [io  0x0000-0x0cf7 window]
2023-07-24T02:55:01,258460+00:00 pci_bus 0000:00: root bus resource [io  0x0d00-0xffff window]
2023-07-24T02:55:01,262459+00:00 pci_bus 0000:00: root bus resource [mem 0x000a0000-0x000bffff window]
2023-07-24T02:55:01,266460+00:00 pci_bus 0000:00: root bus resource [mem 0xc0000000-0xfebfffff window]
2023-07-24T02:55:01,270462+00:00 pci_bus 0000:00: root bus resource [mem 0x440000000-0x4bfffffff window]
2023-07-24T02:55:01,274755+00:00 pci 0000:00:00.0: [8086:1237] type 00 class 0x060000
2023-07-24T02:55:01,280133+00:00 pci 0000:00:01.0: [8086:7000] type 00 class 0x060100
2023-07-24T02:55:01,283878+00:00 pci 0000:00:01.1: [8086:7010] type 00 class 0x010180
2023-07-24T02:55:01,290459+00:00 pci 0000:00:01.1: reg 0x20: [io  0xc0c0-0xc0cf]
2023-07-24T02:55:01,296000+00:00 pci 0000:00:01.1: legacy IDE quirk: reg 0x10: [io  0x01f0-0x01f7]
2023-07-24T02:55:01,298459+00:00 pci 0000:00:01.1: legacy IDE quirk: reg 0x14: [io  0x03f6]
2023-07-24T02:55:01,302460+00:00 pci 0000:00:01.1: legacy IDE quirk: reg 0x18: [io  0x0170-0x0177]
2023-07-24T02:55:01,306459+00:00 pci 0000:00:01.1: legacy IDE quirk: reg 0x1c: [io  0x0376]
2023-07-24T02:55:01,310929+00:00 pci 0000:00:01.2: [8086:7020] type 00 class 0x0c0300
2023-07-24T02:55:01,317930+00:00 pci 0000:00:01.2: reg 0x20: [io  0xc080-0xc09f]
2023-07-24T02:55:01,320398+00:00 pci 0000:00:01.3: [8086:7113] type 00 class 0x068000
2023-07-24T02:55:01,323484+00:00 pci 0000:00:01.3: quirk: [io  0x0600-0x063f] claimed by PIIX4 ACPI
2023-07-24T02:55:01,326480+00:00 pci 0000:00:01.3: quirk: [io  0x0700-0x070f] claimed by PIIX4 SMB
2023-07-24T02:55:01,331475+00:00 pci 0000:00:02.0: [1013:00b8] type 00 class 0x030000
2023-07-24T02:55:01,337704+00:00 pci 0000:00:02.0: reg 0x10: [mem 0xfc000000-0xfdffffff pref]
2023-07-24T02:55:01,340709+00:00 pci 0000:00:02.0: reg 0x14: [mem 0xfeb90000-0xfeb90fff]
2023-07-24T02:55:01,351894+00:00 pci 0000:00:02.0: reg 0x30: [mem 0xfeb80000-0xfeb8ffff pref]
2023-07-24T02:55:01,354692+00:00 pci 0000:00:02.0: Video device with shadowed ROM at [mem 0x000c0000-0x000dffff]
2023-07-24T02:55:01,360045+00:00 pci 0000:00:03.0: [1af4:1000] type 00 class 0x020000
2023-07-24T02:55:01,364273+00:00 pci 0000:00:03.0: reg 0x10: [io  0xc000-0xc03f]
2023-07-24T02:55:01,368135+00:00 pci 0000:00:03.0: reg 0x14: [mem 0xfeb91000-0xfeb91fff]
2023-07-24T02:55:01,375229+00:00 pci 0000:00:03.0: reg 0x20: [mem 0xfe000000-0xfe003fff 64bit pref]
2023-07-24T02:55:01,380292+00:00 pci 0000:00:03.0: reg 0x30: [mem 0xfeb00000-0xfeb7ffff pref]
2023-07-24T02:55:01,384579+00:00 pci 0000:00:04.0: [1af4:1001] type 00 class 0x010000
2023-07-24T02:55:01,388574+00:00 pci 0000:00:04.0: reg 0x10: [io  0xc040-0xc07f]
2023-07-24T02:55:01,392081+00:00 pci 0000:00:04.0: reg 0x14: [mem 0xfeb92000-0xfeb92fff]
2023-07-24T02:55:01,399357+00:00 pci 0000:00:04.0: reg 0x20: [mem 0xfe004000-0xfe007fff 64bit pref]
2023-07-24T02:55:01,406353+00:00 pci 0000:00:05.0: [1af4:1002] type 00 class 0x00ff00
2023-07-24T02:55:01,407730+00:00 pci 0000:00:05.0: reg 0x10: [io  0xc0a0-0xc0bf]
2023-07-24T02:55:01,415954+00:00 pci 0000:00:05.0: reg 0x20: [mem 0xfe008000-0xfe00bfff 64bit pref]
2023-07-24T02:55:01,432034+00:00 ACPI: PCI: Interrupt link LNKA configured for IRQ 10
2023-07-24T02:55:01,434751+00:00 ACPI: PCI: Interrupt link LNKB configured for IRQ 10
2023-07-24T02:55:01,438712+00:00 ACPI: PCI: Interrupt link LNKC configured for IRQ 11
2023-07-24T02:55:01,442709+00:00 ACPI: PCI: Interrupt link LNKD configured for IRQ 11
2023-07-24T02:55:01,446593+00:00 ACPI: PCI: Interrupt link LNKS configured for IRQ 9
2023-07-24T02:55:01,452351+00:00 iommu: Default domain type: Translated 
2023-07-24T02:55:01,454476+00:00 iommu: DMA domain TLB invalidation policy: lazy mode 
2023-07-24T02:55:01,458977+00:00 SCSI subsystem initialized
2023-07-24T02:55:01,461665+00:00 libata version 3.00 loaded.
2023-07-24T02:55:01,461665+00:00 pci 0000:00:02.0: vgaarb: setting as boot VGA device
2023-07-24T02:55:01,462450+00:00 pci 0000:00:02.0: vgaarb: VGA device added: decodes=io+mem,owns=io+mem,locks=none
2023-07-24T02:55:01,462464+00:00 pci 0000:00:02.0: vgaarb: bridge control possible
2023-07-24T02:55:01,466232+00:00 vgaarb: loaded
2023-07-24T02:55:01,466574+00:00 ACPI: bus type USB registered
2023-07-24T02:55:01,469741+00:00 usbcore: registered new interface driver usbfs
2023-07-24T02:55:01,470489+00:00 usbcore: registered new interface driver hub
2023-07-24T02:55:01,474478+00:00 usbcore: registered new device driver usb
2023-07-24T02:55:01,478512+00:00 pps_core: LinuxPPS API ver. 1 registered
2023-07-24T02:55:01,482458+00:00 pps_core: Software ver. 5.3.6 - Copyright 2005-2007 Rodolfo Giometti <giometti@linux.it>
2023-07-24T02:55:01,486467+00:00 PTP clock support registered
2023-07-24T02:55:01,489531+00:00 EDAC MC: Ver: 3.0.0
2023-07-24T02:55:01,490994+00:00 NetLabel: Initializing
2023-07-24T02:55:01,494459+00:00 NetLabel:  domain hash size = 128
2023-07-24T02:55:01,498388+00:00 NetLabel:  protocols = UNLABELED CIPSOv4 CALIPSO
2023-07-24T02:55:01,498575+00:00 NetLabel:  unlabeled traffic allowed by default
2023-07-24T02:55:01,502517+00:00 PCI: Using ACPI for IRQ routing
2023-07-24T02:55:01,505730+00:00 PCI: pci_cache_line_size set to 64 bytes
2023-07-24T02:55:01,506143+00:00 e820: reserve RAM buffer [mem 0x0009fc00-0x0009ffff]
2023-07-24T02:55:01,506151+00:00 e820: reserve RAM buffer [mem 0xbffdc000-0xbfffffff]
2023-07-24T02:55:01,506806+00:00 clocksource: Switched to clocksource kvm-clock
2023-07-24T02:55:01,535274+00:00 VFS: Disk quotas dquot_6.6.0
2023-07-24T02:55:01,540119+00:00 VFS: Dquot-cache hash table entries: 512 (order 0, 4096 bytes)
2023-07-24T02:55:01,547638+00:00 AppArmor: AppArmor Filesystem Enabled
2023-07-24T02:55:01,551930+00:00 pnp: PnP ACPI init
2023-07-24T02:55:01,554759+00:00 pnp 00:03: [dma 2]
2023-07-24T02:55:01,555490+00:00 pnp: PnP ACPI: found 5 devices
2023-07-24T02:55:01,568359+00:00 clocksource: acpi_pm: mask: 0xffffff max_cycles: 0xffffff, max_idle_ns: 2085701024 ns
2023-07-24T02:55:01,574846+00:00 NET: Registered PF_INET protocol family
2023-07-24T02:55:01,579410+00:00 IP idents hash table entries: 262144 (order: 9, 2097152 bytes, linear)
2023-07-24T02:55:01,588292+00:00 tcp_listen_portaddr_hash hash table entries: 8192 (order: 5, 131072 bytes, linear)
2023-07-24T02:55:01,594143+00:00 Table-perturb hash table entries: 65536 (order: 6, 262144 bytes, linear)
2023-07-24T02:55:01,599686+00:00 TCP established hash table entries: 131072 (order: 8, 1048576 bytes, linear)
2023-07-24T02:55:01,604806+00:00 TCP bind hash table entries: 65536 (order: 8, 1048576 bytes, linear)
2023-07-24T02:55:01,609035+00:00 TCP: Hash tables configured (established 131072 bind 65536)
2023-07-24T02:55:01,613830+00:00 MPTCP token hash table entries: 16384 (order: 6, 393216 bytes, linear)
2023-07-24T02:55:01,618327+00:00 UDP hash table entries: 8192 (order: 6, 262144 bytes, linear)
2023-07-24T02:55:01,622027+00:00 UDP-Lite hash table entries: 8192 (order: 6, 262144 bytes, linear)
2023-07-24T02:55:01,626216+00:00 NET: Registered PF_UNIX/PF_LOCAL protocol family
2023-07-24T02:55:01,629903+00:00 NET: Registered PF_XDP protocol family
2023-07-24T02:55:01,632728+00:00 pci_bus 0000:00: resource 4 [io  0x0000-0x0cf7 window]
2023-07-24T02:55:01,655300+00:00 pci_bus 0000:00: resource 5 [io  0x0d00-0xffff window]
2023-07-24T02:55:01,659021+00:00 pci_bus 0000:00: resource 6 [mem 0x000a0000-0x000bffff window]
2023-07-24T02:55:01,662740+00:00 pci_bus 0000:00: resource 7 [mem 0xc0000000-0xfebfffff window]
2023-07-24T02:55:01,666445+00:00 pci_bus 0000:00: resource 8 [mem 0x440000000-0x4bfffffff window]
2023-07-24T02:55:01,670415+00:00 pci 0000:00:01.0: PIIX3: Enabling Passive Release
2023-07-24T02:55:01,673546+00:00 pci 0000:00:00.0: Limiting direct PCI/PCI transfers
2023-07-24T02:55:01,676759+00:00 pci 0000:00:01.0: Activating ISA DMA hang workarounds
2023-07-24T02:55:01,719443+00:00 ACPI: \_SB_.LNKD: Enabled at IRQ 11
2023-07-24T02:55:01,761365+00:00 pci 0000:00:01.2: quirk_usb_early_handoff+0x0/0x160 took 79339 usecs
2023-07-24T02:55:01,765671+00:00 PCI: CLS 0 bytes, default 64
2023-07-24T02:55:01,768032+00:00 PCI-DMA: Using software bounce buffering for IO (SWIOTLB)
2023-07-24T02:55:01,768314+00:00 Trying to unpack rootfs image as initramfs...
2023-07-24T02:55:01,771557+00:00 software IO TLB: mapped [mem 0x00000000bbfdc000-0x00000000bffdc000] (64MB)
2023-07-24T02:55:01,771699+00:00 clocksource: tsc: mask: 0xffffffffffffffff max_cycles: 0x39a84ecfd44, max_idle_ns: 881590442549 ns
2023-07-24T02:55:01,787560+00:00 Initialise system trusted keyrings
2023-07-24T02:55:01,790100+00:00 Key type blacklist registered
2023-07-24T02:55:01,792655+00:00 workingset: timestamp_bits=36 max_order=22 bucket_order=0
2023-07-24T02:55:01,799189+00:00 zbud: loaded
2023-07-24T02:55:01,801362+00:00 squashfs: version 4.0 (2009/01/31) Phillip Lougher
2023-07-24T02:55:01,805249+00:00 fuse: init (API version 7.34)
2023-07-24T02:55:01,808388+00:00 integrity: Platform Keyring initialized
2023-07-24T02:55:01,825954+00:00 Key type asymmetric registered
2023-07-24T02:55:01,828281+00:00 Asymmetric key parser 'x509' registered
2023-07-24T02:55:01,831054+00:00 Block layer SCSI generic (bsg) driver version 0.4 loaded (major 243)
2023-07-24T02:55:01,835347+00:00 io scheduler mq-deadline registered
2023-07-24T02:55:01,839166+00:00 shpchp: Standard Hot Plug PCI Controller Driver version: 0.4
2023-07-24T02:55:01,843674+00:00 input: Power Button as /devices/LNXSYSTM:00/LNXPWRBN:00/input/input0
2023-07-24T02:55:01,848250+00:00 ACPI: button: Power Button [PWRF]
2023-07-24T02:55:01,890978+00:00 ACPI: \_SB_.LNKC: Enabled at IRQ 10
2023-07-24T02:55:01,975272+00:00 ACPI: \_SB_.LNKA: Enabled at IRQ 10
2023-07-24T02:55:01,981656+00:00 Serial: 8250/16550 driver, 32 ports, IRQ sharing enabled
2023-07-24T02:55:02,022905+00:00 00:04: ttyS0 at I/O 0x3f8 (irq = 4, base_baud = 115200) is a 16550A
2023-07-24T02:55:02,032560+00:00 Linux agpgart interface v0.103
2023-07-24T02:55:02,043562+00:00 loop: module loaded
2023-07-24T02:55:02,046364+00:00 ata_piix 0000:00:01.1: version 2.13
2023-07-24T02:55:02,048343+00:00 scsi host0: ata_piix
2023-07-24T02:55:02,051234+00:00 scsi host1: ata_piix
2023-07-24T02:55:02,053632+00:00 ata1: PATA max MWDMA2 cmd 0x1f0 ctl 0x3f6 bmdma 0xc0c0 irq 14
2023-07-24T02:55:02,058315+00:00 ata2: PATA max MWDMA2 cmd 0x170 ctl 0x376 bmdma 0xc0c8 irq 15
2023-07-24T02:55:02,063262+00:00 tun: Universal TUN/TAP device driver, 1.6
2023-07-24T02:55:02,066788+00:00 PPP generic driver version 2.4.2
2023-07-24T02:55:02,069829+00:00 VFIO - User Level meta-driver version: 0.3
2023-07-24T02:55:02,074243+00:00 ehci_hcd: USB 2.0 'Enhanced' Host Controller (EHCI) Driver
2023-07-24T02:55:02,080036+00:00 ehci-pci: EHCI PCI platform driver
2023-07-24T02:55:02,083921+00:00 ehci-platform: EHCI generic platform driver
2023-07-24T02:55:02,088104+00:00 ohci_hcd: USB 1.1 'Open' Host Controller (OHCI) Driver
2023-07-24T02:55:02,092979+00:00 ohci-pci: OHCI PCI platform driver
2023-07-24T02:55:02,096214+00:00 ohci-platform: OHCI generic platform driver
2023-07-24T02:55:02,099920+00:00 uhci_hcd: USB Universal Host Controller Interface driver
2023-07-24T02:55:02,143522+00:00 uhci_hcd 0000:00:01.2: UHCI Host Controller
2023-07-24T02:55:02,147218+00:00 uhci_hcd 0000:00:01.2: new USB bus registered, assigned bus number 1
2023-07-24T02:55:02,151593+00:00 uhci_hcd 0000:00:01.2: detected 2 ports
2023-07-24T02:55:02,155069+00:00 uhci_hcd 0000:00:01.2: irq 11, io base 0x0000c080
2023-07-24T02:55:02,158887+00:00 usb usb1: New USB device found, idVendor=1d6b, idProduct=0001, bcdDevice= 5.15
2023-07-24T02:55:02,163849+00:00 usb usb1: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2023-07-24T02:55:02,168161+00:00 usb usb1: Product: UHCI Host Controller
2023-07-24T02:55:02,171146+00:00 usb usb1: Manufacturer: Linux 5.15.0-67-generic uhci_hcd
2023-07-24T02:55:02,172156+00:00 Freeing initrd memory: 31536K
2023-07-24T02:55:02,174861+00:00 usb usb1: SerialNumber: 0000:00:01.2
2023-07-24T02:55:02,175197+00:00 hub 1-0:1.0: USB hub found
2023-07-24T02:55:02,183075+00:00 hub 1-0:1.0: 2 ports detected
2023-07-24T02:55:02,186083+00:00 i8042: PNP: PS/2 Controller [PNP0303:KBD,PNP0f13:MOU] at 0x60,0x64 irq 1,12
2023-07-24T02:55:02,192232+00:00 serio: i8042 KBD port at 0x60,0x64 irq 1
2023-07-24T02:55:02,195535+00:00 serio: i8042 AUX port at 0x60,0x64 irq 12
2023-07-24T02:55:02,199185+00:00 mousedev: PS/2 mouse device common for all mice
2023-07-24T02:55:02,203374+00:00 rtc_cmos 00:00: RTC can wake from S4
2023-07-24T02:55:02,207863+00:00 input: AT Translated Set 2 keyboard as /devices/platform/i8042/serio0/input/input1
2023-07-24T02:55:02,214220+00:00 rtc_cmos 00:00: registered as rtc0
2023-07-24T02:55:02,217423+00:00 rtc_cmos 00:00: setting system clock to 2023-07-24T02:55:02 UTC (1690167302)
2023-07-24T02:55:02,222604+00:00 rtc_cmos 00:00: alarms up to one day, y3k, 114 bytes nvram
2023-07-24T02:55:02,226763+00:00 i2c_dev: i2c /dev entries driver
2023-07-24T02:55:02,229500+00:00 device-mapper: core: CONFIG_IMA_DISABLE_HTABLE is disabled. Duplicate IMA measurements will not be recorded in the IMA log.
2023-07-24T02:55:02,236796+00:00 device-mapper: uevent: version 1.0.3
2023-07-24T02:55:02,240201+00:00 device-mapper: ioctl: 4.45.0-ioctl (2021-03-22) initialised: dm-devel@redhat.com
2023-07-24T02:55:02,245442+00:00 platform eisa.0: Probing EISA bus 0
2023-07-24T02:55:02,248310+00:00 platform eisa.0: EISA: Cannot allocate resource for mainboard
2023-07-24T02:55:02,252452+00:00 platform eisa.0: Cannot allocate resource for EISA slot 1
2023-07-24T02:55:02,256450+00:00 platform eisa.0: Cannot allocate resource for EISA slot 2
2023-07-24T02:55:02,260614+00:00 platform eisa.0: Cannot allocate resource for EISA slot 3
2023-07-24T02:55:02,264438+00:00 platform eisa.0: Cannot allocate resource for EISA slot 4
2023-07-24T02:55:02,268308+00:00 platform eisa.0: Cannot allocate resource for EISA slot 5
2023-07-24T02:55:02,272575+00:00 platform eisa.0: Cannot allocate resource for EISA slot 6
2023-07-24T02:55:02,276824+00:00 platform eisa.0: Cannot allocate resource for EISA slot 7
2023-07-24T02:55:02,281440+00:00 platform eisa.0: Cannot allocate resource for EISA slot 8
2023-07-24T02:55:02,285796+00:00 platform eisa.0: EISA: Detected 0 cards
2023-07-24T02:55:02,289321+00:00 intel_pstate: CPU model not supported
2023-07-24T02:55:02,293505+00:00 ledtrig-cpu: registered to indicate activity on CPUs
2023-07-24T02:55:02,298226+00:00 drop_monitor: Initializing network drop monitor service
2023-07-24T02:55:02,303067+00:00 NET: Registered PF_INET6 protocol family
2023-07-24T02:55:02,326751+00:00 Segment Routing with IPv6
2023-07-24T02:55:02,329726+00:00 In-situ OAM (IOAM) with IPv6
2023-07-24T02:55:02,333215+00:00 NET: Registered PF_PACKET protocol family
2023-07-24T02:55:02,337561+00:00 Key type dns_resolver registered
2023-07-24T02:55:02,342795+00:00 IPI shorthand broadcast: enabled
2023-07-24T02:55:02,345826+00:00 sched_clock: Marking stable (1783102194, 559529496)->(2852116067, -509484377)
2023-07-24T02:55:02,352428+00:00 registered taskstats version 1
2023-07-24T02:55:02,355836+00:00 Loading compiled-in X.509 certificates
2023-07-24T02:55:02,361440+00:00 Loaded X.509 cert 'Build time autogenerated kernel key: 4919d01b97f8f8ece5362917619ef42f1d265e85'
2023-07-24T02:55:02,369065+00:00 Loaded X.509 cert 'Canonical Ltd. Live Patch Signing: 14df34d1a87cf37625abec039ef2bf521249b969'
2023-07-24T02:55:02,376721+00:00 Loaded X.509 cert 'Canonical Ltd. Kernel Module Signing: 88f752e560a1e0737e31163a466ad7b70a850c19'
2023-07-24T02:55:02,383171+00:00 blacklist: Loading compiled-in revocation X.509 certificates
2023-07-24T02:55:02,387547+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing: 61482aa2830d0ab2ad5af10b7250da9033ddcef0'
2023-07-24T02:55:02,393561+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (2017): 242ade75ac4a15e50d50c84b0d45ff3eae707a03'
2023-07-24T02:55:02,401042+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (ESM 2018): 365188c1d374d6b07c3c8f240f8ef722433d6a8b'
2023-07-24T02:55:02,407279+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (2019): c0746fd6c5da3ae827864651ad66ae47fe24b3e8'
2023-07-24T02:55:02,413574+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (2021 v1): a8d54bbb3825cfb94fa13c9f8a594a195c107b8d'
2023-07-24T02:55:02,419792+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (2021 v2): 4cf046892d6fd3c9a5b03f98d845f90851dc6a8c'
2023-07-24T02:55:02,427521+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (2021 v3): 100437bb6de6e469b581e61cd66bce3ef4ed53af'
2023-07-24T02:55:02,435054+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (Ubuntu Core 2019): c1d57b8f6b743f23ee41f4f7ee292f06eecadfb9'
2023-07-24T02:55:02,443670+00:00 zswap: loaded using pool lzo/zbud
2023-07-24T02:55:02,448472+00:00 Key type .fscrypt registered
2023-07-24T02:55:02,451327+00:00 Key type fscrypt-provisioning registered
2023-07-24T02:55:02,462344+00:00 Key type encrypted registered
2023-07-24T02:55:02,465385+00:00 AppArmor: AppArmor sha1 policy hashing enabled
2023-07-24T02:55:02,469786+00:00 ima: No TPM chip found, activating TPM-bypass!
2023-07-24T02:55:02,474251+00:00 Loading compiled-in module X.509 certificates
2023-07-24T02:55:02,479525+00:00 Loaded X.509 cert 'Build time autogenerated kernel key: 4919d01b97f8f8ece5362917619ef42f1d265e85'
2023-07-24T02:55:02,487313+00:00 ima: Allocated hash algorithm: sha1
2023-07-24T02:55:02,490921+00:00 ima: No architecture policies found
2023-07-24T02:55:02,494636+00:00 evm: Initialising EVM extended attributes:
2023-07-24T02:55:02,498228+00:00 evm: security.selinux
2023-07-24T02:55:02,500701+00:00 evm: security.SMACK64
2023-07-24T02:55:02,503019+00:00 evm: security.SMACK64EXEC
2023-07-24T02:55:02,505560+00:00 evm: security.SMACK64TRANSMUTE
2023-07-24T02:55:02,508577+00:00 evm: security.SMACK64MMAP
2023-07-24T02:55:02,511422+00:00 evm: security.apparmor
2023-07-24T02:55:02,513877+00:00 evm: security.ima
2023-07-24T02:55:02,519987+00:00 usb 1-1: new full-speed USB device number 2 using uhci_hcd
2023-07-24T02:55:02,520804+00:00 evm: security.capability
2023-07-24T02:55:02,529319+00:00 evm: HMAC attrs: 0x1
2023-07-24T02:55:02,538150+00:00 PM:   Magic number: 15:908:915
2023-07-24T02:55:02,548219+00:00 RAS: Correctable Errors collector initialized.
2023-07-24T02:55:02,557841+00:00 Freeing unused decrypted memory: 2036K
2023-07-24T02:55:02,565753+00:00 Freeing unused kernel image (initmem) memory: 3240K
2023-07-24T02:55:02,578590+00:00 Write protecting the kernel read-only data: 30720k
2023-07-24T02:55:02,589303+00:00 Freeing unused kernel image (text/rodata gap) memory: 2036K
2023-07-24T02:55:02,596360+00:00 Freeing unused kernel image (rodata/data gap) memory: 1468K
2023-07-24T02:55:02,672717+00:00 x86/mm: Checked W+X mappings: passed, no W+X pages found.
2023-07-24T02:55:02,678974+00:00 x86/mm: Checking user space page tables
2023-07-24T02:55:02,711562+00:00 usb 1-1: New USB device found, idVendor=0627, idProduct=0001, bcdDevice= 0.00
2023-07-24T02:55:02,716828+00:00 usb 1-1: New USB device strings: Mfr=1, Product=3, SerialNumber=5
2023-07-24T02:55:02,721052+00:00 usb 1-1: Product: QEMU USB Tablet
2023-07-24T02:55:02,723867+00:00 usb 1-1: Manufacturer: QEMU
2023-07-24T02:55:02,726389+00:00 usb 1-1: SerialNumber: 42
2023-07-24T02:55:02,750507+00:00 x86/mm: Checked W+X mappings: passed, no W+X pages found.
2023-07-24T02:55:02,754731+00:00 Run /init as init process
2023-07-24T02:55:02,757159+00:00   with arguments:
2023-07-24T02:55:02,757163+00:00     /init
2023-07-24T02:55:02,757165+00:00   with environment:
2023-07-24T02:55:02,757167+00:00     HOME=/
2023-07-24T02:55:02,757168+00:00     TERM=linux
2023-07-24T02:55:02,757169+00:00     BOOT_IMAGE=/boot/vmlinuz-5.15.0-67-generic
2023-07-24T02:55:02,968852+00:00 hid: raw HID events driver (C) Jiri Kosina
2023-07-24T02:55:02,970355+00:00 cryptd: max_cpu_qlen set to 1000
2023-07-24T02:55:02,972635+00:00 virtio_blk virtio1: [vda] 629145600 512-byte logical blocks (322 GB/300 GiB)
2023-07-24T02:55:02,990820+00:00 input: VirtualPS/2 VMware VMMouse as /devices/platform/i8042/serio1/input/input4
2023-07-24T02:55:03,000776+00:00 usbcore: registered new interface driver usbhid
2023-07-24T02:55:03,022542+00:00 usbhid: USB HID core driver
2023-07-24T02:55:03,025504+00:00 GPT:Primary header thinks Alt. header is not at the end of the disk.
2023-07-24T02:55:03,028030+00:00 FDC 0 is a S82078B
2023-07-24T02:55:03,030373+00:00 GPT:4612095 != 629145599
2023-07-24T02:55:03,035237+00:00 GPT:Alternate GPT header not at the end of the disk.
2023-07-24T02:55:03,035525+00:00 input: VirtualPS/2 VMware VMMouse as /devices/platform/i8042/serio1/input/input3
2023-07-24T02:55:03,039824+00:00 GPT:4612095 != 629145599
2023-07-24T02:55:03,039845+00:00 GPT: Use GNU Parted to correct GPT errors.
2023-07-24T02:55:03,039864+00:00  vda: vda1 vda14 vda15
2023-07-24T02:55:03,045841+00:00 AVX version of gcm_enc/dec engaged.
2023-07-24T02:55:03,058441+00:00 AES CTR mode by8 optimization enabled
2023-07-24T02:55:03,083132+00:00 input: QEMU QEMU USB Tablet as /devices/pci0000:00/0000:00:01.2/usb1/1-1/1-1:1.0/0003:0627:0001.0001/input/input5
2023-07-24T02:55:03,087145+00:00 virtio_net virtio0 ens3: renamed from eth0
2023-07-24T02:55:03,094749+00:00 hid-generic 0003:0627:0001.0001: input,hidraw0: USB HID v0.01 Mouse [QEMU QEMU USB Tablet] on usb-0000:00:01.2-1/input0
2023-07-24T02:55:04,886495+00:00 raid6: sse2x4   gen()  3441 MB/s
2023-07-24T02:55:04,954528+00:00 raid6: sse2x4   xor()  2330 MB/s
2023-07-24T02:55:05,022524+00:00 raid6: sse2x2   gen()  2262 MB/s
2023-07-24T02:55:05,090491+00:00 raid6: sse2x2   xor()  5397 MB/s
2023-07-24T02:55:05,158489+00:00 raid6: sse2x1   gen()  2334 MB/s
2023-07-24T02:55:05,226506+00:00 raid6: sse2x1   xor()  5037 MB/s
2023-07-24T02:55:05,229327+00:00 raid6: using algorithm sse2x4 gen() 3441 MB/s
2023-07-24T02:55:05,232803+00:00 raid6: .... xor() 2330 MB/s, rmw enabled
2023-07-24T02:55:05,236473+00:00 raid6: using ssse3x2 recovery algorithm
2023-07-24T02:55:05,242643+00:00 xor: automatically using best checksumming function   avx       
2023-07-24T02:55:05,248963+00:00 async_tx: api initialized (async)
2023-07-24T02:55:05,397712+00:00 Btrfs loaded, crc32c=crc32c-intel, zoned=yes, fsverity=yes
2023-07-24T02:55:05,587950+00:00 EXT4-fs (vda1): mounted filesystem with ordered data mode. Opts: (null). Quota mode: none.
2023-07-24T02:55:06,758657+00:00 systemd[1]: Inserted module 'autofs4'
2023-07-24T02:55:06,999381+00:00 systemd[1]: systemd 249.11-0ubuntu3.7 running in system mode (+PAM +AUDIT +SELINUX +APPARMOR +IMA +SMACK +SECCOMP +GCRYPT +GNUTLS +OPENSSL +ACL +BLKID +CURL +ELFUTILS +FIDO2 +IDN2 -IDN +IPTC +KMOD +LIBCRYPTSETUP +LIBFDISK +PCRE2 -PWQUALITY -P11KIT -QRENCODE +BZIP2 +LZ4 +XZ +ZLIB +ZSTD -XKBCOMMON +UTMP +SYSVINIT default-hierarchy=unified)
2023-07-24T02:55:07,022569+00:00 systemd[1]: Detected virtualization kvm.
2023-07-24T02:55:07,026242+00:00 systemd[1]: Detected architecture x86-64.
2023-07-24T02:55:07,084371+00:00 systemd[1]: Hostname set to <ubuntu>.
2023-07-24T02:55:07,121547+00:00 systemd[1]: Initializing machine ID from VM UUID.
2023-07-24T02:55:07,125731+00:00 systemd[1]: Installed transient /etc/machine-id file.
2023-07-24T02:55:08,736383+00:00 systemd[1]: Queued start job for default target Graphical Interface.
2023-07-24T02:55:08,748146+00:00 systemd[1]: Created slice Slice /system/modprobe.
2023-07-24T02:55:08,759309+00:00 systemd[1]: Created slice Slice /system/serial-getty.
2023-07-24T02:55:08,769344+00:00 systemd[1]: Created slice Slice /system/systemd-fsck.
2023-07-24T02:55:08,778547+00:00 systemd[1]: Created slice User and Session Slice.
2023-07-24T02:55:08,787249+00:00 systemd[1]: Started Forward Password Requests to Wall Directory Watch.
2023-07-24T02:55:08,798772+00:00 systemd[1]: Set up automount Arbitrary Executable File Formats File System Automount Point.
2023-07-24T02:55:08,810183+00:00 systemd[1]: Reached target Slice Units.
2023-07-24T02:55:08,816553+00:00 systemd[1]: Reached target Mounting snaps.
2023-07-24T02:55:08,822866+00:00 systemd[1]: Reached target Swaps.
2023-07-24T02:55:08,829275+00:00 systemd[1]: Reached target Local Verity Protected Volumes.
2023-07-24T02:55:08,838203+00:00 systemd[1]: Listening on Device-mapper event daemon FIFOs.
2023-07-24T02:55:08,847232+00:00 systemd[1]: Listening on LVM2 poll daemon socket.
2023-07-24T02:55:08,855309+00:00 systemd[1]: Listening on multipathd control socket.
2023-07-24T02:55:08,863646+00:00 systemd[1]: Listening on Syslog Socket.
2023-07-24T02:55:08,871366+00:00 systemd[1]: Listening on fsck to fsckd communication Socket.
2023-07-24T02:55:08,880913+00:00 systemd[1]: Listening on initctl Compatibility Named Pipe.
2023-07-24T02:55:08,890652+00:00 systemd[1]: Listening on Journal Audit Socket.
2023-07-24T02:55:08,898801+00:00 systemd[1]: Listening on Journal Socket (/dev/log).
2023-07-24T02:55:08,907650+00:00 systemd[1]: Listening on Journal Socket.
2023-07-24T02:55:08,915488+00:00 systemd[1]: Listening on Network Service Netlink Socket.
2023-07-24T02:55:08,934616+00:00 systemd[1]: Listening on udev Control Socket.
2023-07-24T02:55:08,944287+00:00 systemd[1]: Listening on udev Kernel Socket.
2023-07-24T02:55:08,955420+00:00 systemd[1]: Mounting Huge Pages File System...
2023-07-24T02:55:08,965251+00:00 systemd[1]: Mounting POSIX Message Queue File System...
2023-07-24T02:55:08,976905+00:00 systemd[1]: Mounting Kernel Debug File System...
2023-07-24T02:55:08,987535+00:00 systemd[1]: Mounting Kernel Trace File System...
2023-07-24T02:55:09,000242+00:00 systemd[1]: Starting Journal Service...
2023-07-24T02:55:09,012890+00:00 systemd[1]: Starting Set the console keyboard layout...
2023-07-24T02:55:09,023378+00:00 systemd[1]: Starting Create List of Static Device Nodes...
2023-07-24T02:55:09,035294+00:00 systemd[1]: Starting Monitoring of LVM2 mirrors, snapshots etc. using dmeventd or progress polling...
2023-07-24T02:55:09,048724+00:00 systemd[1]: Condition check resulted in LXD - agent being skipped.
2023-07-24T02:55:09,056563+00:00 systemd[1]: Starting Load Kernel Module chromeos_pstore...
2023-07-24T02:55:09,068889+00:00 systemd[1]: Starting Load Kernel Module configfs...
2023-07-24T02:55:09,078784+00:00 systemd[1]: Starting Load Kernel Module drm...
2023-07-24T02:55:09,088098+00:00 systemd[1]: Starting Load Kernel Module efi_pstore...
2023-07-24T02:55:09,098606+00:00 systemd[1]: Starting Load Kernel Module fuse...
2023-07-24T02:55:09,108411+00:00 systemd[1]: Starting Load Kernel Module pstore_blk...
2023-07-24T02:55:09,119096+00:00 systemd[1]: Starting Load Kernel Module pstore_zone...
2023-07-24T02:55:09,129974+00:00 systemd[1]: Starting Load Kernel Module ramoops...
2023-07-24T02:55:09,138713+00:00 systemd[1]: Condition check resulted in OpenVSwitch configuration for cleanup being skipped.
2023-07-24T02:55:09,149575+00:00 systemd[1]: Starting File System Check on Root Device...
2023-07-24T02:55:09,179180+00:00 systemd[1]: Starting Load Kernel Modules...
2023-07-24T02:55:09,186352+00:00 systemd[1]: Starting Coldplug All udev Devices...
2023-07-24T02:55:09,196685+00:00 systemd[1]: Started Journal Service.
2023-07-24T02:55:09,410172+00:00 EXT4-fs (vda1): re-mounted. Opts: discard,errors=remount-ro. Quota mode: none.
2023-07-24T02:55:09,455672+00:00 systemd-journald[410]: Received client request to flush runtime journal.
2023-07-24T02:55:09,459661+00:00 alua: device handler registered
2023-07-24T02:55:09,466627+00:00 emc: device handler registered
2023-07-24T02:55:09,486990+00:00 rdac: device handler registered
2023-07-24T02:55:10,165626+00:00 loop0: detected capacity change from 0 to 229272
2023-07-24T02:55:10,165825+00:00 loop1: detected capacity change from 0 to 129608
2023-07-24T02:55:10,169029+00:00 loop2: detected capacity change from 0 to 102072
2023-07-24T02:55:13,507972+00:00 audit: type=1400 audit(1690167313.788:2): apparmor="STATUS" operation="profile_load" profile="unconfined" name="lsb_release" pid=569 comm="apparmor_parser"
2023-07-24T02:55:13,510621+00:00 audit: type=1400 audit(1690167313.792:3): apparmor="STATUS" operation="profile_load" profile="unconfined" name="nvidia_modprobe" pid=570 comm="apparmor_parser"
2023-07-24T02:55:13,512679+00:00 audit: type=1400 audit(1690167313.792:4): apparmor="STATUS" operation="profile_load" profile="unconfined" name="nvidia_modprobe//kmod" pid=570 comm="apparmor_parser"
2023-07-24T02:55:13,549711+00:00 audit: type=1400 audit(1690167313.828:5): apparmor="STATUS" operation="profile_load" profile="unconfined" name="/usr/bin/man" pid=572 comm="apparmor_parser"
2023-07-24T02:55:13,551489+00:00 audit: type=1400 audit(1690167313.832:6): apparmor="STATUS" operation="profile_load" profile="unconfined" name="man_filter" pid=572 comm="apparmor_parser"
2023-07-24T02:55:13,553836+00:00 audit: type=1400 audit(1690167313.832:7): apparmor="STATUS" operation="profile_load" profile="unconfined" name="man_groff" pid=572 comm="apparmor_parser"
2023-07-24T02:55:13,615174+00:00 audit: type=1400 audit(1690167313.896:8): apparmor="STATUS" operation="profile_load" profile="unconfined" name="tcpdump" pid=573 comm="apparmor_parser"
2023-07-24T02:55:13,738274+00:00 audit: type=1400 audit(1690167314.016:9): apparmor="STATUS" operation="profile_load" profile="unconfined" name="/usr/lib/NetworkManager/nm-dhcp-client.action" pid=571 comm="apparmor_parser"
2023-07-24T02:55:13,741120+00:00 audit: type=1400 audit(1690167314.020:10): apparmor="STATUS" operation="profile_load" profile="unconfined" name="/usr/lib/NetworkManager/nm-dhcp-helper" pid=571 comm="apparmor_parser"
2023-07-24T02:55:13,743663+00:00 audit: type=1400 audit(1690167314.024:11): apparmor="STATUS" operation="profile_load" profile="unconfined" name="/usr/lib/connman/scripts/dhclient-script" pid=571 comm="apparmor_parser"
2023-07-24T02:55:27,046419+00:00 EXT4-fs (vda1): resizing filesystem from 548091 to 78614779 blocks
2023-07-24T02:55:28,659384+00:00 EXT4-fs (vda1): resized filesystem to 78614779
2023-07-24T02:55:51,836139+00:00 loop3: detected capacity change from 0 to 8
2023-07-24T02:55:55,639899+00:00 kauditd_printk_skb: 21 callbacks suppressed
2023-07-24T02:55:55,639909+00:00 audit: type=1400 audit(1690167355.920:33): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap-update-ns.lxd" pid=925 comm="apparmor_parser"
2023-07-24T02:55:55,894890+00:00 audit: type=1400 audit(1690167356.176:34): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap.lxd.buginfo" pid=928 comm="apparmor_parser"
2023-07-24T02:55:55,895480+00:00 audit: type=1400 audit(1690167356.176:35): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap.lxd.benchmark" pid=927 comm="apparmor_parser"
2023-07-24T02:55:55,896922+00:00 audit: type=1400 audit(1690167356.176:36): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap.lxd.check-kernel" pid=929 comm="apparmor_parser"
2023-07-24T02:55:55,900047+00:00 audit: type=1400 audit(1690167356.180:37): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap.lxd.hook.install" pid=932 comm="apparmor_parser"
2023-07-24T02:55:55,905495+00:00 audit: type=1400 audit(1690167356.184:38): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap.lxd.activate" pid=926 comm="apparmor_parser"
2023-07-24T02:55:56,105018+00:00 audit: type=1400 audit(1690167356.384:39): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap.lxd.hook.configure" pid=931 comm="apparmor_parser"
2023-07-24T02:55:56,125281+00:00 audit: type=1400 audit(1690167356.404:40): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap.lxd.daemon" pid=930 comm="apparmor_parser"
2023-07-24T02:55:56,163556+00:00 audit: type=1400 audit(1690167356.444:41): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap.lxd.lxc-to-lxd" pid=935 comm="apparmor_parser"
2023-07-24T02:55:56,200379+00:00 audit: type=1400 audit(1690167356.480:42): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap.lxd.migrate" pid=937 comm="apparmor_parser"
2023-07-24T07:04:00,232931+00:00 kauditd_printk_skb: 8 callbacks suppressed
2023-07-24T07:04:00,232947+00:00 audit: type=1400 audit(1690182240.512:51): apparmor="STATUS" operation="profile_load" profile="unconfined" name="docker-default" pid=10873 comm="apparmor_parser"
2023-07-24T07:04:01,856836+00:00 bridge: filtering via arp/ip/ip6tables is no longer available by default. Update your scripts to load br_netfilter if you need this.
2023-07-24T07:04:01,864147+00:00 Bridge firewalling registered
2023-07-24T07:04:02,322931+00:00 Initializing XFRM netlink socket
2023-07-24T08:08:24,662635+00:00 audit: type=1400 audit(1690186104.940:52): apparmor="STATUS" operation="profile_load" profile="unconfined" name="/usr/sbin/chronyd" pid=13847 comm="apparmor_parser"
2023-07-24T22:38:28,711672+00:00 audit: type=1400 audit(1690238308.990:53): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="/usr/lib/snapd/snap-confine" pid=88310 comm="apparmor_parser"
2023-07-24T22:38:28,713384+00:00 audit: type=1400 audit(1690238308.990:54): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="/usr/lib/snapd/snap-confine//mount-namespace-capture-helper" pid=88310 comm="apparmor_parser"
2023-07-24T22:38:38,336514+00:00 loop3: detected capacity change from 0 to 8
2023-07-24T22:39:43,276507+00:00 loop3: detected capacity change from 0 to 8
2023-07-24T22:39:44,195467+00:00 audit: type=1400 audit(1690238384.474:55): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap-update-ns.lxd" pid=88730 comm="apparmor_parser"
2023-07-24T22:39:44,204152+00:00 audit: type=1400 audit(1690238384.482:56): apparmor="STATUS" operation="profile_replace" profile="unconfined" name="/snap/snapd/18357/usr/lib/snapd/snap-confine" pid=88729 comm="apparmor_parser"
2023-07-24T22:39:44,238611+00:00 audit: type=1400 audit(1690238384.518:57): apparmor="STATUS" operation="profile_replace" profile="unconfined" name="/snap/snapd/18357/usr/lib/snapd/snap-confine//mount-namespace-capture-helper" pid=88729 comm="apparmor_parser"
2023-07-24T22:39:44,239289+00:00 audit: type=1400 audit(1690238384.518:58): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap.lxd.check-kernel" pid=88734 comm="apparmor_parser"
2023-07-24T22:39:44,239658+00:00 audit: type=1400 audit(1690238384.518:59): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap.lxd.daemon" pid=88735 comm="apparmor_parser"
2023-07-24T22:39:44,240145+00:00 audit: type=1400 audit(1690238384.518:60): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap.lxd.activate" pid=88731 comm="apparmor_parser"
2023-07-24T22:39:44,240602+00:00 audit: type=1400 audit(1690238384.518:61): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap.lxd.buginfo" pid=88733 comm="apparmor_parser"
2023-07-24T22:39:44,241060+00:00 audit: type=1400 audit(1690238384.518:62): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap.lxd.benchmark" pid=88732 comm="apparmor_parser"
2023-07-24T22:39:44,241591+00:00 audit: type=1400 audit(1690238384.518:63): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap.lxd.hook.configure" pid=88736 comm="apparmor_parser"
2023-07-24T22:39:44,241832+00:00 audit: type=1400 audit(1690238384.518:64): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap.lxd.hook.install" pid=88742 comm="apparmor_parser"
2023-07-25T10:47:37,069956+00:00 IPVS: Registered protocols (TCP, UDP, SCTP, AH, ESP)
2023-07-25T10:47:37,070066+00:00 IPVS: Connection hash table configured (size=4096, memory=32Kbytes)
2023-07-25T10:47:37,070356+00:00 IPVS: ipvs loaded.
2023-07-25T10:47:37,142769+00:00 IPVS: [rr] scheduler registered.
2023-07-25T10:47:37,158699+00:00 IPVS: [wrr] scheduler registered.
2023-07-25T10:47:37,177041+00:00 IPVS: [sh] scheduler registered.
2023-07-25T12:39:21,523606+00:00 wireguard: WireGuard 1.0.0 loaded. See www.wireguard.com for information.
2023-07-25T12:39:21,523645+00:00 wireguard: Copyright (C) 2015-2019 Jason A. Donenfeld <Jason@zx2c4.com>. All Rights Reserved.
2023-07-26T02:12:40,264469+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): cali81b4ccf56a8: link becomes ready
