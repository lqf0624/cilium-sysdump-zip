Module                  Size  Used by
vxlan                  86016  0
xt_set                 20480  4
xt_multiport           20480  5
ipt_rpfilter           16384  1
ip_set_hash_ip         53248  1
ip_set_hash_net        53248  3
veth                   32768  0
wireguard              94208  0
curve25519_x86_64      36864  1 wireguard
libchacha20poly1305    16384  1 wireguard
chacha_x86_64          28672  1 libchacha20poly1305
poly1305_x86_64        28672  1 libchacha20poly1305
ip6_udp_tunnel         16384  2 wireguard,vxlan
udp_tunnel             20480  2 wireguard,vxlan
libcurve25519_generic    49152  2 curve25519_x86_64,wireguard
libchacha              16384  1 chacha_x86_64
udp_diag               16384  0
tcp_diag               16384  0
inet_diag              24576  2 tcp_diag,udp_diag
xt_socket              16384  0
nf_socket_ipv4         16384  1 xt_socket
nf_socket_ipv6         20480  1 xt_socket
ip6table_filter        16384  0
ip6table_raw           16384  0
ip6table_mangle        16384  0
ip6_tables             32768  3 ip6table_filter,ip6table_raw,ip6table_mangle
iptable_filter         16384  0
iptable_raw            16384  0
iptable_mangle         16384  0
iptable_nat            16384  0
xt_statistic           16384  2
xt_nat                 16384  3
ipt_REJECT             16384  3
nf_reject_ipv4         16384  1 ipt_REJECT
xt_tcpudp              20480  7
ip_set                 53248  4 ip_set_hash_ip,xt_set,ip_set_hash_net
ip_vs_sh               16384  0
ip_vs_wrr              16384  0
ip_vs_rr               16384  0
ip_vs                 176128  6 ip_vs_rr,ip_vs_sh,ip_vs_wrr
xt_comment             16384  187
xt_mark                16384  55
xt_conntrack           16384  25
nft_chain_nat          16384  7
xt_MASQUERADE          20480  5
nf_nat                 49152  4 xt_nat,nft_chain_nat,iptable_nat,xt_MASQUERADE
nf_conntrack_netlink    49152  0
nf_conntrack          172032  6 xt_conntrack,nf_nat,xt_nat,nf_conntrack_netlink,xt_MASQUERADE,ip_vs
nf_defrag_ipv6         24576  3 nf_conntrack,xt_socket,ip_vs
nf_defrag_ipv4         16384  2 nf_conntrack,xt_socket
xfrm_user              40960  1
xfrm_algo              16384  1 xfrm_user
nft_counter            16384  181
xt_addrtype            16384  9
nft_compat             20480  306
br_netfilter           32768  0
bridge                307200  1 br_netfilter
stp                    16384  1 bridge
llc                    16384  2 bridge,stp
overlay               151552  4
tls                   114688  0
nf_tables             249856  239 nft_compat,nft_counter,nft_chain_nat
nfnetlink              20480  5 nft_compat,nf_conntrack_netlink,nf_tables,ip_set
binfmt_misc            24576  1
nls_iso8859_1          16384  1
kvm_intel             368640  0
kvm                  1028096  1 kvm_intel
joydev                 32768  0
input_leds             16384  0
serio_raw              20480  0
dm_multipath           40960  0
scsi_dh_rdac           20480  0
scsi_dh_emc            16384  0
scsi_dh_alua           20480  0
sch_fq_codel           20480  2
drm                   622592  0
efi_pstore             16384  0
ip_tables              32768  4 iptable_filter,iptable_raw,iptable_nat,iptable_mangle
x_tables               53248  23 ip6table_filter,xt_conntrack,xt_statistic,ip6table_raw,iptable_filter,nft_compat,xt_multiport,xt_socket,xt_tcpudp,xt_addrtype,xt_nat,xt_comment,xt_set,ip6_tables,ipt_REJECT,ipt_rpfilter,iptable_raw,ip_tables,iptable_nat,ip6table_mangle,xt_MASQUERADE,iptable_mangle,xt_mark
autofs4                49152  2
btrfs                1560576  0
blake2b_generic        20480  0
zstd_compress         229376  1 btrfs
raid10                 69632  0
raid456               163840  0
async_raid6_recov      24576  1 raid456
async_memcpy           20480  2 raid456,async_raid6_recov
async_pq               24576  2 raid456,async_raid6_recov
async_xor              20480  3 async_pq,raid456,async_raid6_recov
async_tx               20480  5 async_pq,async_memcpy,async_xor,raid456,async_raid6_recov
xor                    24576  2 async_xor,btrfs
raid6_pq              122880  4 async_pq,btrfs,raid456,async_raid6_recov
libcrc32c              16384  6 nf_conntrack,nf_nat,btrfs,nf_tables,raid456,ip_vs
raid1                  49152  0
raid0                  24576  0
multipath              20480  0
linear                 20480  0
hid_generic            16384  0
crct10dif_pclmul       16384  1
crc32_pclmul           16384  0
ghash_clmulni_intel    16384  0
aesni_intel           376832  0
virtio_net             61440  0
net_failover           20480  1 virtio_net
usbhid                 65536  0
crypto_simd            16384  1 aesni_intel
cryptd                 24576  2 crypto_simd,ghash_clmulni_intel
psmouse               176128  0
hid                   151552  2 usbhid,hid_generic
failover               16384  1 net_failover
virtio_blk             20480  2
floppy                118784  0
