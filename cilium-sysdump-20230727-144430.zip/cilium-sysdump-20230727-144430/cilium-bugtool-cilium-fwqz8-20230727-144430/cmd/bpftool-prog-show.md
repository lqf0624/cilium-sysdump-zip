493: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2023-07-25T10:47:32+0000  uid 0
	xlated 64B  jited 41B  memlock 4096B
496: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2023-07-25T10:47:36+0000  uid 0
	xlated 64B  jited 41B  memlock 4096B
11499: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2023-07-25T12:40:04+0000  uid 0
	xlated 64B  jited 41B  memlock 4096B
11564: cgroup_device  tag 8b9c33f36f812014  gpl
	loaded_at 2023-07-25T22:46:30+0000  uid 0
	xlated 744B  jited 448B  memlock 4096B
11565: cgroup_skb  tag 6deef7357e7b4530  gpl
	loaded_at 2023-07-25T22:46:30+0000  uid 0
	xlated 64B  jited 55B  memlock 4096B
11566: cgroup_skb  tag 6deef7357e7b4530  gpl
	loaded_at 2023-07-25T22:46:30+0000  uid 0
	xlated 64B  jited 55B  memlock 4096B
11569: cgroup_device  tag e3dbd137be8d6168  gpl
	loaded_at 2023-07-25T22:46:30+0000  uid 0
	xlated 504B  jited 310B  memlock 4096B
11570: cgroup_skb  tag 6deef7357e7b4530  gpl
	loaded_at 2023-07-25T22:46:30+0000  uid 0
	xlated 64B  jited 55B  memlock 4096B
11571: cgroup_skb  tag 6deef7357e7b4530  gpl
	loaded_at 2023-07-25T22:46:30+0000  uid 0
	xlated 64B  jited 55B  memlock 4096B
11572: cgroup_device  tag 0ecd07b7b633809f  gpl
	loaded_at 2023-07-25T22:46:30+0000  uid 0
	xlated 496B  jited 308B  memlock 4096B
11573: cgroup_skb  tag 6deef7357e7b4530  gpl
	loaded_at 2023-07-25T22:46:30+0000  uid 0
	xlated 64B  jited 55B  memlock 4096B
11574: cgroup_skb  tag 6deef7357e7b4530  gpl
	loaded_at 2023-07-25T22:46:30+0000  uid 0
	xlated 64B  jited 55B  memlock 4096B
11575: cgroup_device  tag e3dbd137be8d6168  gpl
	loaded_at 2023-07-25T22:46:30+0000  uid 0
	xlated 504B  jited 310B  memlock 4096B
11576: cgroup_device  tag 28a890580b33b0dc  gpl
	loaded_at 2023-07-25T22:46:30+0000  uid 0
	xlated 560B  jited 352B  memlock 4096B
11582: cgroup_device  tag c8b47a902f1cc68b  gpl
	loaded_at 2023-07-25T22:46:30+0000  uid 0
	xlated 464B  jited 289B  memlock 4096B
11697: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2023-07-27T06:40:55+0000  uid 0
	xlated 64B  jited 41B  memlock 4096B
11706: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2023-07-27T06:41:18+0000  uid 0
	xlated 64B  jited 41B  memlock 4096B
