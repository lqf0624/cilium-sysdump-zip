alloc: 6.72MB (7041800 bytes)
total-alloc: 13.97MB (14651112 bytes)
sys: 24.66MB (25862311 bytes)
lookups: 0
mallocs: 87234
frees: 58472
heap-alloc: 6.72MB (7041800 bytes)
heap-sys: 14.94MB (15663104 bytes)
heap-idle: 5.62MB (5890048 bytes)
heap-in-use: 9.32MB (9773056 bytes)
heap-released: 3.98MB (4169728 bytes)
heap-objects: 28762
stack-in-use: 1.06MB (1114112 bytes)
stack-sys: 1.06MB (1114112 bytes)
stack-mspan-inuse: 164.02KB (167960 bytes)
stack-mspan-sys: 176.00KB (180224 bytes)
stack-mcache-inuse: 9.38KB (9600 bytes)
stack-mcache-sys: 16.00KB (16384 bytes)
other-sys: 1.62MB (1700873 bytes)
gc-sys: 5.39MB (5647360 bytes)
next-gc: when heap-alloc >= 10.99MB (11525424 bytes)
last-gc: 2023-07-27 06:43:27.363071895 +0000 UTC
gc-pause-total: 2.524974ms
gc-pause: 295379
gc-pause-end: 1690440207363071895
num-gc: 6
num-forced-gc: 0
gc-cpu-fraction: 5.602904088494779e-05
enable-gc: true
debug-gc: false
