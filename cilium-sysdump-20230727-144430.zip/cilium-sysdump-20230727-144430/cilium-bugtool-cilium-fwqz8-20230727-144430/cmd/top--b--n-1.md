top - 06:44:37 up 3 days,  3:49,  0 users,  load average: 0.64, 0.79, 0.79
Tasks:  10 total,   8 running,   2 sleeping,   0 stopped,   0 zombie
%Cpu(s): 15.7 us, 33.9 sy,  0.0 ni, 50.4 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :  15622.6 total,  10522.5 free,    439.1 used,   4660.9 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.  14849.6 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
     95 root      20   0  709128   7660   5608 S  33.3   0.0   0:00.10 cilium-+
    156 root      20   0    3204    856    756 R  26.7   0.0   0:00.04 bpftool
      1 root      20   0  782916  68864  49380 S   6.7   0.4   0:00.90 cilium-+
    184 root      20   0    3204    856    756 R   6.7   0.0   0:00.01 bpftool
    128 root      20   0    5972   3212   2784 R   0.0   0.0   0:00.00 top
    197 root      20   0    3984   3056   2824 R   0.0   0.0   0:00.00 bash
    198 root      20   0    3080    312    256 R   0.0   0.0   0:00.00 bpftool
    199 root      20   0    1076    292    248 R   0.0   0.0   0:00.00 bpftool
    200 root      20   0    3984   2916   2688 R   0.0   0.0   0:00.00 bash
    201 root      20   0    3984   2980   2752 R   0.0   0.0   0:00.00 bash
