USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root          95  0.0  0.0 709128  7216 ?        Ssl  06:44   0:00 cilium-bugtool --archiveType=gz
root         113  0.0  0.0   5900  3012 ?        R    06:44   0:00  \_ ps auxfw
root         128  0.0  0.0   5972  3212 ?        R    06:44   0:00  \_ top -b -n 1
root         130  0.0  0.0   2764   876 ?        R    06:44   0:00  \_ dmesg --time-format=iso
root         131  0.0  0.0   2508   516 ?        R    06:44   0:00  \_ sysctl -a
root         132  0.0  0.0   3204   792 ?        R    06:44   0:00  \_ [bpftool]
root         133  0.0  0.0   3072   856 ?        R    06:44   0:00  \_ bpftool prog show
root           1  0.4  0.4 782916 68864 ?        Ssl  06:41   0:00 cilium-agent --config-dir=/tmp/cilium/config-map
