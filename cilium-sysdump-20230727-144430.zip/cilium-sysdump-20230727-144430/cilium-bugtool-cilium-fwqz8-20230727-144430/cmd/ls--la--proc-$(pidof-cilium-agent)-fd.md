total 0
dr-x------ 2 root root  0 Jul 27 06:41 .
dr-xr-xr-x 9 root root  0 Jul 27 06:41 ..
lrwx------ 1 root root 64 Jul 27 06:41 0 -> /dev/null
l-wx------ 1 root root 64 Jul 27 06:41 1 -> pipe:[8273037]
lrwx------ 1 root root 64 Jul 27 06:41 10 -> anon_inode:bpf-map
lrwx------ 1 root root 64 Jul 27 06:44 11 -> anon_inode:bpf-map
lrwx------ 1 root root 64 Jul 27 06:44 12 -> anon_inode:bpf-map
lrwx------ 1 root root 64 Jul 27 06:44 13 -> anon_inode:bpf-map
lrwx------ 1 root root 64 Jul 27 06:44 14 -> anon_inode:bpf-map
lrwx------ 1 root root 64 Jul 27 06:44 15 -> anon_inode:bpf-map
lrwx------ 1 root root 64 Jul 27 06:44 16 -> socket:[8270308]
lrwx------ 1 root root 64 Jul 27 06:44 17 -> socket:[8270309]
lrwx------ 1 root root 64 Jul 27 06:44 18 -> socket:[8270315]
lrwx------ 1 root root 64 Jul 27 06:44 19 -> socket:[8270316]
l-wx------ 1 root root 64 Jul 27 06:41 2 -> pipe:[8273038]
lrwx------ 1 root root 64 Jul 27 06:44 20 -> socket:[8273218]
lrwx------ 1 root root 64 Jul 27 06:41 3 -> anon_inode:[eventpoll]
lr-x------ 1 root root 64 Jul 27 06:41 4 -> pipe:[8268258]
l-wx------ 1 root root 64 Jul 27 06:41 5 -> pipe:[8268258]
lrwx------ 1 root root 64 Jul 27 06:41 6 -> socket:[8268260]
lrwx------ 1 root root 64 Jul 27 06:41 7 -> socket:[8271254]
lrwx------ 1 root root 64 Jul 27 06:41 8 -> socket:[8270298]
lrwx------ 1 root root 64 Jul 27 06:41 9 -> anon_inode:bpf-map
