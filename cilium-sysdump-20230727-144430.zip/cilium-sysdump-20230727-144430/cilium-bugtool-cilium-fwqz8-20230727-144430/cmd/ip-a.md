1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host 
       valid_lft forever preferred_lft forever
2: ens3: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc fq_codel state UP group default qlen 1000
    link/ether fa:16:3e:d6:53:b6 brd ff:ff:ff:ff:ff:ff
    altname enp0s3
    inet 10.26.65.247/24 metric 100 brd 10.26.65.255 scope global dynamic ens3
       valid_lft 50397sec preferred_lft 50397sec
    inet6 fe80::f816:3eff:fed6:53b6/64 scope link 
       valid_lft forever preferred_lft forever
3: docker0: <NO-CARRIER,BROADCAST,MULTICAST,UP> mtu 1500 qdisc noqueue state DOWN group default 
    link/ether 02:42:70:5a:a4:6a brd ff:ff:ff:ff:ff:ff
    inet 172.17.0.1/16 brd 172.17.255.255 scope global docker0
       valid_lft forever preferred_lft forever
8: vxlan.calico: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1450 qdisc noqueue state UNKNOWN group default 
    link/ether 66:c0:ac:9f:ef:42 brd ff:ff:ff:ff:ff:ff
    inet 10.244.141.2/32 scope global vxlan.calico
       valid_lft forever preferred_lft forever
    inet6 fe80::64c0:acff:fe9f:ef42/64 scope link 
       valid_lft forever preferred_lft forever
