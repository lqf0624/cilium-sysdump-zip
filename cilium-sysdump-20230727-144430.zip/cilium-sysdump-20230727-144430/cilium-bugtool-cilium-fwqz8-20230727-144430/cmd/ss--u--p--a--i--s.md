Total: 246
TCP:   21 (estab 7, closed 3, orphaned 0, timewait 3)

Transport Total     IP        IPv6
RAW	  2         1         1        
UDP	  8         6         2        
TCP	  18        13        5        
INET	  28        20        8        
FRAG	  0         0         0        

State  Recv-Q Send-Q     Local Address:Port   Peer Address:Port  Process
UNCONN 0      0                0.0.0.0:4789        0.0.0.0:*            
UNCONN 0      0          127.0.0.53%lo:domain      0.0.0.0:*            
UNCONN 0      0      10.26.65.247%ens3:bootpc      0.0.0.0:*            
UNCONN 0      0              127.0.0.1:323         0.0.0.0:*            
ESTAB  0      0           10.26.65.247:42926     223.5.5.5:domain       
ESTAB  0      0           10.26.65.247:36193     223.5.5.5:domain       
UNCONN 0      0                  [::1]:323            [::]:*            
UNCONN 0      0                      *:44301             *:*      users:(("cilium-agent",pid=1,fd=19))
