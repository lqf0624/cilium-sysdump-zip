default via 10.26.65.254 dev ens3 proto dhcp src 10.26.65.247 metric 100 
10.26.65.0/24 dev ens3 proto kernel scope link src 10.26.65.247 metric 100 
10.26.65.220 dev ens3 proto dhcp scope link src 10.26.65.247 metric 100 
10.26.65.254 dev ens3 proto dhcp scope link src 10.26.65.247 metric 100 
blackhole 10.244.141.0/26 proto 80 
10.244.151.128/26 via 10.26.65.222 dev ens3 proto 80 onlink 
10.244.207.128/26 via 10.26.65.227 dev ens3 proto 80 onlink 
10.244.239.192/26 via 10.26.65.239 dev ens3 proto 80 onlink 
10.244.242.64/26 via 10.26.65.224 dev ens3 proto 80 onlink 
10.244.249.64/26 via 10.26.65.226 dev ens3 proto 80 onlink 
10.244.254.192/26 via 10.26.65.231 dev ens3 proto 80 onlink 
169.254.169.254 via 10.26.65.220 dev ens3 proto dhcp src 10.26.65.247 metric 100 
172.17.0.0/16 dev docker0 proto kernel scope link src 172.17.0.1 linkdown 
223.5.5.5 via 10.26.65.254 dev ens3 proto dhcp src 10.26.65.247 metric 100 
