98: hash  flags 0x1
	key 20B  value 48B  max_entries 65535  memlock 4718592B
101: percpu_hash  name cilium_metrics  flags 0x1
	key 8B  value 16B  max_entries 1024  memlock 139264B
103: hash  flags 0x1
	key 12B  value 12B  max_entries 65536  memlock 1572864B
104: hash  flags 0x1
	key 4B  value 8B  max_entries 65536  memlock 1048576B
105: hash  flags 0x1
	key 2B  value 6B  max_entries 65536  memlock 524288B
106: perf_event_array  flags 0x0
	key 4B  value 4B  max_entries 8  memlock 4096B
107: perf_event_array  flags 0x0
	key 4B  value 4B  max_entries 8  memlock 4096B
108: prog_array  flags 0x0
	key 4B  value 4B  max_entries 65535  memlock 524288B
109: lru_hash  flags 0x0
	key 14B  value 56B  max_entries 143696  memlock 10346496B
110: lru_hash  flags 0x0
	key 14B  value 56B  max_entries 71848  memlock 5173248B
111: lru_hash  flags 0x0
	key 12B  value 4B  max_entries 8192  memlock 131072B
1532: lpm_trie  flags 0x1
	key 24B  value 12B  max_entries 512000  memlock 20480000B
1533: hash  flags 0x1
	key 20B  value 20B  max_entries 65536  memlock 2621440B
