 06:44:37 up 3 days,  3:49,  0 users,  load average: 0.64, 0.79, 0.79
