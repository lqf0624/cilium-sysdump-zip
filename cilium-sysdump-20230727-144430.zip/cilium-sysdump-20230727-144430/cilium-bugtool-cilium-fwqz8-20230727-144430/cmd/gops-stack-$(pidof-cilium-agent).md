goroutine 57 [running]:
runtime/pprof.writeGoroutineStacks({0x2e7a900, 0xc00050c048})
	/usr/local/go/src/runtime/pprof/pprof.go:693 +0x70
runtime/pprof.writeGoroutine({0x2e7a900, 0xc00050c048}, 0xc000380000)
	/usr/local/go/src/runtime/pprof/pprof.go:682 +0x2b
runtime/pprof.(*Profile).WriteTo(0x2a36c50, {0x2e7a900, 0xc00050c048}, 0x0)
	/usr/local/go/src/runtime/pprof/pprof.go:331 +0x14b
github.com/google/gops/agent.handle({0x7f9cdd058098, 0xc00050c048}, {0xc00053a2e0, 0x1, 0x1})
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:201 +0x15d
github.com/google/gops/agent.listen()
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:145 +0x19a
created by github.com/google/gops/agent.Listen
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:123 +0x365

goroutine 1 [select, 3 minutes]:
github.com/cilium/cilium/pkg/backoff.(*Exponential).Wait(0xc000c9c3d8, {0x2ed2210, 0xc0009d6c40})
	/go/src/github.com/cilium/cilium/pkg/backoff/backoff.go:91 +0x294
github.com/cilium/cilium/pkg/k8s.waitForNodeInformation({0x2ed2210, 0xc0009d6c40}, {0x2e70de0, 0xc0004f9c00}, {0xc00007402e, 0x11})
	/go/src/github.com/cilium/cilium/pkg/k8s/init.go:53 +0x148
github.com/cilium/cilium/pkg/k8s.WaitForNodeInformation({0x2ed2210, 0xc0009d6c40}, {0x2e70de0, 0xc0004f9c00})
	/go/src/github.com/cilium/cilium/pkg/k8s/init.go:238 +0x17e
github.com/cilium/cilium/daemon/cmd.NewDaemon({0x2ed2210, 0xc0009d6c40}, 0xc0009915c0, 0xc0004ce000, {0x2f33028, 0xc0004ce0e0})
	/go/src/github.com/cilium/cilium/daemon/cmd/daemon.go:646 +0x210b
github.com/cilium/cilium/daemon/cmd.runDaemon()
	/go/src/github.com/cilium/cilium/daemon/cmd/daemon_main.go:1654 +0x7ce
github.com/cilium/cilium/daemon/cmd.glob..func1(0x4728280, {0x2a26314, 0x1, 0x1})
	/go/src/github.com/cilium/cilium/daemon/cmd/daemon_main.go:127 +0x3ca
github.com/spf13/cobra.(*Command).execute(0x4728280, {0xc00013c010, 0x1, 0x1})
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:860 +0x5f8
github.com/spf13/cobra.(*Command).ExecuteC(0x4728280)
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:974 +0x3bc
github.com/spf13/cobra.(*Command).Execute(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:902
github.com/cilium/cilium/daemon/cmd.Execute()
	/go/src/github.com/cilium/cilium/daemon/cmd/daemon_main.go:141 +0x45
main.main()
	/go/src/github.com/cilium/cilium/daemon/main.go:16 +0x17

goroutine 18 [chan receive]:
k8s.io/klog/v2.(*loggingT).flushDaemon(0x0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/klog/v2/klog.go:1181 +0x6a
created by k8s.io/klog/v2.init.0
	/go/src/github.com/cilium/cilium/vendor/k8s.io/klog/v2/klog.go:420 +0xfb

goroutine 19 [select, 3 minutes]:
io.(*pipe).Read(0xc000138840, {0xc000414000, 0x1000, 0x1})
	/usr/local/go/src/io/pipe.go:57 +0xb7
io.(*PipeReader).Read(0x0, {0xc000414000, 0x0, 0x0})
	/usr/local/go/src/io/pipe.go:134 +0x25
bufio.(*Scanner).Scan(0xc00038ef28)
	/usr/local/go/src/bufio/scan.go:215 +0x865
github.com/sirupsen/logrus.(*Entry).writerScanner(0x0, 0xc000136910, 0xc000343a60)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:59 +0xa5
created by github.com/sirupsen/logrus.(*Entry).WriterLevel
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:51 +0x3d6

goroutine 20 [select, 3 minutes]:
io.(*pipe).Read(0xc0001388a0, {0xc0000c6000, 0x1000, 0x1})
	/usr/local/go/src/io/pipe.go:57 +0xb7
io.(*PipeReader).Read(0x0, {0xc0000c6000, 0x0, 0x0})
	/usr/local/go/src/io/pipe.go:134 +0x25
bufio.(*Scanner).Scan(0xc000116f28)
	/usr/local/go/src/bufio/scan.go:215 +0x865
github.com/sirupsen/logrus.(*Entry).writerScanner(0x0, 0xc000136920, 0xc000343a80)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:59 +0xa5
created by github.com/sirupsen/logrus.(*Entry).WriterLevel
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:51 +0x3d6

goroutine 21 [select, 3 minutes]:
io.(*pipe).Read(0xc000138900, {0xc00038c000, 0x1000, 0x1})
	/usr/local/go/src/io/pipe.go:57 +0xb7
io.(*PipeReader).Read(0x0, {0xc00038c000, 0x0, 0x0})
	/usr/local/go/src/io/pipe.go:134 +0x25
bufio.(*Scanner).Scan(0xc000392f28)
	/usr/local/go/src/bufio/scan.go:215 +0x865
github.com/sirupsen/logrus.(*Entry).writerScanner(0x0, 0xc000136930, 0xc000343aa0)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:59 +0xa5
created by github.com/sirupsen/logrus.(*Entry).WriterLevel
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:51 +0x3d6

goroutine 22 [select, 3 minutes]:
io.(*pipe).Read(0xc000138960, {0xc0000c7000, 0x1000, 0x1})
	/usr/local/go/src/io/pipe.go:57 +0xb7
io.(*PipeReader).Read(0x0, {0xc0000c7000, 0x0, 0x0})
	/usr/local/go/src/io/pipe.go:134 +0x25
bufio.(*Scanner).Scan(0xc000117f28)
	/usr/local/go/src/bufio/scan.go:215 +0x865
github.com/sirupsen/logrus.(*Entry).writerScanner(0x0, 0xc000136940, 0xc000343ac0)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:59 +0xa5
created by github.com/sirupsen/logrus.(*Entry).WriterLevel
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:51 +0x3d6

goroutine 5 [sleep]:
time.Sleep(0x37e11d600)
	/usr/local/go/src/runtime/time.go:193 +0x12e
github.com/cilium/cilium/pkg/datapath/link.init.0.func1()
	/go/src/github.com/cilium/cilium/pkg/datapath/link/link.go:28 +0x65
created by github.com/cilium/cilium/pkg/datapath/link.init.0
	/go/src/github.com/cilium/cilium/pkg/datapath/link/link.go:21 +0x25

goroutine 56 [chan receive, 3 minutes]:
github.com/cilium/cilium/daemon/cmd.(*daemonCleanup).registerSigHandler.func1()
	/go/src/github.com/cilium/cilium/daemon/cmd/cleanup.go:64 +0x4f
created by github.com/cilium/cilium/daemon/cmd.(*daemonCleanup).registerSigHandler
	/go/src/github.com/cilium/cilium/daemon/cmd/cleanup.go:63 +0x145

goroutine 66 [syscall, 3 minutes]:
os/signal.signal_recv()
	/usr/local/go/src/runtime/sigqueue.go:169 +0x98
os/signal.loop()
	/usr/local/go/src/os/signal/signal_unix.go:24 +0x19
created by os/signal.Notify.func1.1
	/usr/local/go/src/os/signal/signal.go:151 +0x2c

goroutine 74 [select]:
github.com/cilium/cilium/pkg/controller.(*Controller).runController(0xc0003b50e0)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:262 +0xd6c
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0xb67

goroutine 78 [select, 3 minutes]:
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:374 +0x12d
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:368 +0x378

goroutine 67 [chan receive, 3 minutes]:
github.com/cilium/cilium/pkg/cleanup.DeferTerminationCleanupFunction.func1()
	/go/src/github.com/cilium/cilium/pkg/cleanup/cleanup.go:19 +0x67
created by github.com/cilium/cilium/pkg/cleanup.DeferTerminationCleanupFunction
	/go/src/github.com/cilium/cilium/pkg/cleanup/cleanup.go:17 +0xa5

goroutine 196 [select, 3 minutes]:
github.com/cilium/cilium/pkg/controller.(*Controller).runController(0xc0005d86c0)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:262 +0xd6c
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0xb67

goroutine 144 [select]:
github.com/cilium/cilium/pkg/controller.(*Controller).runController(0xc000993c20)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:262 +0xd6c
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0xb67

goroutine 142 [IO wait]:
internal/poll.runtime_pollWait(0x7f9cdd3aefc8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:303 +0x85
internal/poll.(*pollDesc).wait(0xc000330a00, 0xc000a58000, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc000330a00, {0xc000a58000, 0x2f8b, 0x2f8b})
	/usr/local/go/src/internal/poll/fd_unix.go:167 +0x25a
net.(*netFD).Read(0xc000330a00, {0xc000a58000, 0x2f86, 0xc0009aaa80})
	/usr/local/go/src/net/fd_posix.go:56 +0x29
net.(*conn).Read(0xc00000e068, {0xc000a58000, 0xc000a58000, 0x5})
	/usr/local/go/src/net/net.go:183 +0x45
crypto/tls.(*atLeastReader).Read(0xc000ac09f0, {0xc000a58000, 0x0, 0x409dcd})
	/usr/local/go/src/crypto/tls/conn.go:777 +0x3d
bytes.(*Buffer).ReadFrom(0xc0003ee278, {0x2e6b7e0, 0xc000ac09f0})
	/usr/local/go/src/bytes/buffer.go:204 +0x98
crypto/tls.(*Conn).readFromUntil(0xc0003ee000, {0x7f9cdd33a158, 0xc0003aa168}, 0x2f8b)
	/usr/local/go/src/crypto/tls/conn.go:799 +0xe5
crypto/tls.(*Conn).readRecordOrCCS(0xc0003ee000, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:606 +0x112
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:574
crypto/tls.(*Conn).Read(0xc0003ee000, {0xc0009bc000, 0x1000, 0xc000693cb0})
	/usr/local/go/src/crypto/tls/conn.go:1277 +0x16f
bufio.(*Reader).Read(0xc0009b5080, {0xc00018e740, 0x9, 0x6c})
	/usr/local/go/src/bufio/bufio.go:227 +0x1b4
io.ReadAtLeast({0x2e6b620, 0xc0009b5080}, {0xc00018e740, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:328 +0x9a
io.ReadFull(...)
	/usr/local/go/src/io/io.go:347
golang.org/x/net/http2.readFrameHeader({0xc00018e740, 0x9, 0xc001abef00}, {0x2e6b620, 0xc0009b5080})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x6e
golang.org/x/net/http2.(*Framer).ReadFrame(0xc00018e700)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:498 +0x95
golang.org/x/net/http2.(*clientConnReadLoop).run(0xc000693f98)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2101 +0x130
golang.org/x/net/http2.(*ClientConn).readLoop(0xc0002fea80)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1997 +0x6f
created by golang.org/x/net/http2.(*Transport).newClientConn
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:725 +0xac5

goroutine 162 [select, 3 minutes]:
github.com/cilium/cilium/pkg/controller.(*Controller).runController(0xc0009ee000)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:262 +0xd6c
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0xb67

goroutine 166 [select]:
github.com/cilium/cilium/pkg/node/manager.(*Manager).backgroundSync(0xc0009c2680)
	/go/src/github.com/cilium/cilium/pkg/node/manager/manager.go:342 +0x2a7
created by github.com/cilium/cilium/pkg/node/manager.NewManager
	/go/src/github.com/cilium/cilium/pkg/node/manager/manager.go:228 +0x747

goroutine 167 [chan receive, 3 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x0, 0x0)
	/usr/local/go/src/sync/once.go:68 +0xd2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:59
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x0)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x7b

goroutine 171 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0009df040)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:206 +0x387
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:119 +0x1bf

goroutine 172 [chan receive, 3 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x0, 0x0)
	/usr/local/go/src/sync/once.go:68 +0xd2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:59
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x0)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x7b

goroutine 173 [chan receive, 3 minutes]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x0, 0x0)
	/usr/local/go/src/sync/once.go:68 +0xd2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:59
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x0)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x7b

goroutine 174 [sync.Cond.Wait, 3 minutes]:
sync.runtime_notifyListWait(0xc000bbe210, 0x0)
	/usr/local/go/src/runtime/sema.go:513 +0x13d
sync.(*Cond).Wait(0x0)
	/usr/local/go/src/sync/cond.go:56 +0x8c
github.com/cilium/cilium/pkg/policy.(*SelectorCache).handleUserNotifications(0xc0004ceaf0)
	/go/src/github.com/cilium/cilium/pkg/policy/selectorcache.go:255 +0xec
created by github.com/cilium/cilium/pkg/policy.NewSelectorCache
	/go/src/github.com/cilium/cilium/pkg/policy/selectorcache.go:292 +0x130

goroutine 175 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc0009df0e0)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:206 +0x387
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:119 +0x1bf

goroutine 177 [select]:
github.com/cilium/cilium/pkg/controller.(*Controller).runController(0xc000c08360)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:262 +0xd6c
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0xb67

goroutine 178 [chan receive, 3 minutes]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).k8sServiceHandler(0xc0004f9c00)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/watcher.go:533 +0xe5
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).RunK8sServiceHandler
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/watcher.go:542 +0x5b

goroutine 179 [IO wait, 3 minutes]:
internal/poll.runtime_pollWait(0x7f9cdd3aede8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:303 +0x85
internal/poll.(*pollDesc).wait(0xc000b88900, 0x416a0f, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc000b88900)
	/usr/local/go/src/internal/poll/fd_unix.go:402 +0x22c
net.(*netFD).accept(0xc000b88900)
	/usr/local/go/src/net/fd_unix.go:173 +0x35
net.(*UnixListener).accept(0xc0005ee088)
	/usr/local/go/src/net/unixsock_posix.go:167 +0x1c
net.(*UnixListener).Accept(0xc000c04750)
	/usr/local/go/src/net/unixsock.go:260 +0x3d
google.golang.org/grpc.(*Server).Serve(0xc000bbb180, {0x2eb4f90, 0xc000c04750})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:779 +0x362
github.com/cilium/cilium/pkg/envoy.startXDSGRPCServer.func1()
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:51 +0xb1
created by github.com/cilium/cilium/pkg/envoy.startXDSGRPCServer
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:49 +0x2d5

goroutine 180 [IO wait, 3 minutes]:
internal/poll.runtime_pollWait(0x7f9cdd3af0b8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:303 +0x85
internal/poll.(*pollDesc).wait(0xc000b88b00, 0x0, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc000b88b00)
	/usr/local/go/src/internal/poll/fd_unix.go:402 +0x22c
net.(*netFD).accept(0xc000b88b00)
	/usr/local/go/src/net/fd_unix.go:173 +0x35
net.(*UnixListener).accept(0x0)
	/usr/local/go/src/net/unixsock_posix.go:167 +0x1c
net.(*UnixListener).AcceptUnix(0xc000c04cf0)
	/usr/local/go/src/net/unixsock.go:247 +0x3d
github.com/cilium/cilium/pkg/envoy.StartAccessLogServer.func1()
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:66 +0x47
created by github.com/cilium/cilium/pkg/envoy.StartAccessLogServer
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:62 +0x665

goroutine 181 [select]:
github.com/cilium/cilium/pkg/controller.(*Controller).runController(0xc000c08c60)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:262 +0xd6c
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0xb67

goroutine 184 [IO wait]:
internal/poll.runtime_pollWait(0x7f9cdd3aecf8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:303 +0x85
internal/poll.(*pollDesc).wait(0xc000b88d80, 0xc000048600, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).ReadMsg(0xc000b88d80, {0xc000048600, 0x200, 0x200}, {0xc000a18900, 0x2c, 0x2c}, 0xc00009c800)
	/usr/local/go/src/internal/poll/fd_unix.go:250 +0x31c
net.(*netFD).readMsg(0xc000b88d80, {0xc000048600, 0x63, 0x0}, {0xc000a18900, 0xffffffffffffffff, 0x0}, 0x0)
	/usr/local/go/src/net/fd_posix.go:68 +0x37
net.(*UDPConn).readMsg(0x4750640, {0xc000048600, 0x4d32d3, 0x7f9cdd3aecf8}, {0xc000a18900, 0x40d094, 0xc00011cb90})
	/usr/local/go/src/net/udpsock_posix.go:62 +0x45
net.(*UDPConn).ReadMsgUDP(0xc00054d360, {0xc000048600, 0xc000afe410, 0x0}, {0xc000a18900, 0xc00011cbf0, 0x40d3e7})
	/usr/local/go/src/net/udpsock.go:144 +0x3c
github.com/cilium/cilium/pkg/fqdn/dnsproxy.(*sessionUDPFactory).ReadRequest(0xc00054d360, 0xc00054d360)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/udp.go:163 +0x5f
github.com/miekg/dns.(*Server).readUDP(0xc00061aff0, 0xc00054d360, 0xc0005deb40)
	/go/src/github.com/cilium/cilium/vendor/github.com/miekg/dns/server.go:632 +0xed
github.com/miekg/dns.defaultReader.ReadUDP({0x26a24a0}, 0x2e7a8a0, 0xc0005deb40)
	/go/src/github.com/cilium/cilium/vendor/github.com/miekg/dns/server.go:154 +0x19
github.com/miekg/dns.(*Server).serveUDP(0xc00061aff0, 0xc00054d360)
	/go/src/github.com/cilium/cilium/vendor/github.com/miekg/dns/server.go:460 +0x18c
github.com/miekg/dns.(*Server).ActivateAndServe(0xc00061aff0)
	/go/src/github.com/cilium/cilium/vendor/github.com/miekg/dns/server.go:329 +0x13f
github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy.func1(0xc00061aff0)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:431 +0x8b
created by github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:426 +0xa25

goroutine 185 [IO wait, 3 minutes]:
internal/poll.runtime_pollWait(0x7f9cdd3aeed8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:303 +0x85
internal/poll.(*pollDesc).wait(0xc000b88d00, 0x0, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc000b88d00)
	/usr/local/go/src/internal/poll/fd_unix.go:402 +0x22c
net.(*netFD).accept(0xc000b88d00)
	/usr/local/go/src/net/fd_unix.go:173 +0x35
net.(*TCPListener).accept(0xc000bc2840)
	/usr/local/go/src/net/tcpsock_posix.go:140 +0x28
net.(*TCPListener).Accept(0xc000bc2840)
	/usr/local/go/src/net/tcpsock.go:262 +0x3d
github.com/miekg/dns.(*Server).serveTCP(0xc00061b0e0, {0x2eb4f60, 0xc000bc2840})
	/go/src/github.com/cilium/cilium/vendor/github.com/miekg/dns/server.go:417 +0x14e
github.com/miekg/dns.(*Server).ActivateAndServe(0xc00061b0e0)
	/go/src/github.com/cilium/cilium/vendor/github.com/miekg/dns/server.go:335 +0x1a5
github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy.func1(0xc00061b0e0)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:431 +0x8b
created by github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:426 +0xa25

goroutine 79 [select, 3 minutes]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc000468d80, 0xc0001dd300)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0xaa8
golang.org/x/net/http2.(*clientStream).doRequest(0x0, 0x0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1185 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1114 +0x30f

goroutine 197 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc000468dc8, 0x4)
	/usr/local/go/src/runtime/sema.go:513 +0x13d
sync.(*Cond).Wait(0xc000c8fd18)
	/usr/local/go/src/sync/cond.go:56 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc000468db0, {0xc000c1e488, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0x0}, {0xc000c1e488, 0x40ae2a, 0x2634ee0})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2384 +0x85
io.ReadAtLeast({0x7f9cdd0c2e98, 0xc000468d80}, {0xc000c1e488, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:328 +0x9a
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc000ac0228, {0xc0007e4000, 0x2000, 0x2600})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x7e
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc0003bc230, 0xc000a25260, {0x2ea1f20, 0xc000628840})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc0005e0180)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc000360e00)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0x11c
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x135

goroutine 213 [select]:
k8s.io/client-go/tools/cache.(*Reflector).watchHandler(0xc00018e2a0, {0x0, 0x0, 0x4750640}, {0x2ea20d8, 0xc000360e00}, 0xc0003d9d18, 0xc0002d49c0, 0xc0001144e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:469 +0x1b6
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc00018e2a0, 0xc0001144e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:429 +0x696
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:221 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x7f9cdd1a9fa0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:155 +0x67
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc0009b2080, {0x2e7a440, 0xc0005de140}, 0x1, 0xc0001144e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:156 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc00018e2a0, 0xc0001144e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:220 +0x1f8
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:56 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:73 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:71 +0x88

goroutine 76 [sync.Cond.Wait, 3 minutes]:
sync.runtime_notifyListWait(0xc000a22208, 0x2)
	/usr/local/go/src/runtime/sema.go:513 +0x13d
sync.(*Cond).Wait(0xc00050bbc0)
	/usr/local/go/src/sync/cond.go:56 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc000a221e0, 0xc00053d340)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:527 +0x233
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc000435440)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:183 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x7f9cdd1a9fa0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:155 +0x67
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xf8dbe8, {0x2e7a460, 0xc000abe030}, 0x1, 0xc0001144e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:156 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0004354a8, 0x3b9aca00, 0x0, 0x0, 0x7f9cdd0cb4c0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:133 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:90
k8s.io/client-go/tools/cache.(*controller).Run(0xc000435440, 0xc0001144e0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:154 +0x2fb
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).NodesInit.func1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/node.go:97 +0x426

goroutine 212 [chan receive, 3 minutes]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:130 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:129 +0x105
