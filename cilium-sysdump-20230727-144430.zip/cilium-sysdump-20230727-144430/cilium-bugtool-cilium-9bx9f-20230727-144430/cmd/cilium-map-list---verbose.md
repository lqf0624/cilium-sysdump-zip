Error: Get "http://%2Fvar%2Frun%2Fcilium%2Fcilium.sock/v1/map": dial unix /var/run/cilium/cilium.sock: connect: no such file or directory
> Error while running 'cilium map list --verbose':  exit status 1

