Error: Cannot get lrp list: Get "http:///var/run/cilium/cilium.sock/v1/lrp": dial unix /var/run/cilium/cilium.sock: connect: no such file or directory
Is the agent running?
> Error while running 'cilium lrp list':  exit status 1

