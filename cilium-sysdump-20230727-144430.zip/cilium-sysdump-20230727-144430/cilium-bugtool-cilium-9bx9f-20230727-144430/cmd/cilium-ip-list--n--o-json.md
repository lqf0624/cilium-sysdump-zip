Error: Cannot get ipcache entries. err: Get "http:///var/run/cilium/cilium.sock/v1/ip": dial unix /var/run/cilium/cilium.sock: connect: no such file or directory
Is the agent running?
> Error while running 'cilium ip list -n -o json':  exit status 1

