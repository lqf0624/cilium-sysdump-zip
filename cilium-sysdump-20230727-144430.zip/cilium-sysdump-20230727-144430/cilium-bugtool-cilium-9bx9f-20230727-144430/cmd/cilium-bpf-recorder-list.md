Unable to open /sys/fs/bpf/tc/globals/cilium_capture4_rules: Unable to get object /sys/fs/bpf/tc/globals/cilium_capture4_rules: no such file or directory. Skipping.
Unable to open /sys/fs/bpf/tc/globals/cilium_capture6_rules: Unable to get object /sys/fs/bpf/tc/globals/cilium_capture6_rules: no such file or directory. Skipping.
