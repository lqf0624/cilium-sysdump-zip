total 0
dr-x------ 2 root root  0 Jul 27 06:41 .
dr-xr-xr-x 9 root root  0 Jul 27 06:41 ..
lrwx------ 1 root root 64 Jul 27 06:41 0 -> /dev/null
l-wx------ 1 root root 64 Jul 27 06:41 1 -> pipe:[8244372]
lrwx------ 1 root root 64 Jul 27 06:41 10 -> anon_inode:bpf-map
lrwx------ 1 root root 64 Jul 27 06:44 11 -> anon_inode:bpf-map
lrwx------ 1 root root 64 Jul 27 06:44 12 -> anon_inode:bpf-map
lrwx------ 1 root root 64 Jul 27 06:44 13 -> anon_inode:bpf-map
lrwx------ 1 root root 64 Jul 27 06:44 14 -> anon_inode:bpf-map
lrwx------ 1 root root 64 Jul 27 06:44 15 -> anon_inode:bpf-map
lrwx------ 1 root root 64 Jul 27 06:44 16 -> socket:[8242857]
lrwx------ 1 root root 64 Jul 27 06:44 17 -> socket:[8242858]
lrwx------ 1 root root 64 Jul 27 06:44 18 -> socket:[8247312]
lrwx------ 1 root root 64 Jul 27 06:44 19 -> socket:[8247313]
l-wx------ 1 root root 64 Jul 27 06:41 2 -> pipe:[8244373]
lrwx------ 1 root root 64 Jul 27 06:44 20 -> socket:[8246304]
lrwx------ 1 root root 64 Jul 27 06:41 3 -> anon_inode:[eventpoll]
lr-x------ 1 root root 64 Jul 27 06:41 4 -> pipe:[8238993]
l-wx------ 1 root root 64 Jul 27 06:41 5 -> pipe:[8238993]
lrwx------ 1 root root 64 Jul 27 06:41 6 -> socket:[8243641]
lrwx------ 1 root root 64 Jul 27 06:41 7 -> socket:[8242812]
lrwx------ 1 root root 64 Jul 27 06:41 8 -> socket:[8242841]
lrwx------ 1 root root 64 Jul 27 06:41 9 -> anon_inode:bpf-map
