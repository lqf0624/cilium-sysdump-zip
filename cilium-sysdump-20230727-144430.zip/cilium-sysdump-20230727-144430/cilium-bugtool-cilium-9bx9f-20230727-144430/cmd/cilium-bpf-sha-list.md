Error: failed to list template directory: open /var/run/cilium/state/templates: no such file or directory

> Error while running 'cilium bpf sha list':  exit status 1

