Error: Cannot get services list: Get "http:///var/run/cilium/cilium.sock/v1/service": dial unix /var/run/cilium/cilium.sock: connect: no such file or directory
Is the agent running?
> Error while running 'cilium service list':  exit status 1

