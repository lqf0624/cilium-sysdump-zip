Error: Error: Get "http://%2Fvar%2Frun%2Fcilium%2Fcilium.sock/v1/fqdn/cache": dial unix /var/run/cilium/cilium.sock: connect: no such file or directory

> Error while running 'cilium fqdn cache list':  exit status 1

