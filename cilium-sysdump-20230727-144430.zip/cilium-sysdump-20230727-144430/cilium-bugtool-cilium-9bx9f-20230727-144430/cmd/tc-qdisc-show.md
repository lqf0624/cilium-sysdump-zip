qdisc noqueue 0: dev lo root refcnt 2 
qdisc fq_codel 0: dev ens3 root refcnt 2 limit 10240p flows 1024 quantum 1514 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc noqueue 0: dev docker0 root refcnt 2 
qdisc noqueue 0: dev vxlan.calico root refcnt 2 
