Error: Cannot get metrics list: Get "http://%2Fvar%2Frun%2Fcilium%2Fcilium.sock/v1/metrics/": dial unix /var/run/cilium/cilium.sock: connect: no such file or directory
> Error while running 'cilium metrics list':  exit status 1

