

Unable to open /sys/fs/bpf/tc/globals/cilium_ct6_global: Unable to get object /sys/fs/bpf/tc/globals/cilium_ct6_global: no such file or directory. Skipping.
Unable to open /sys/fs/bpf/tc/globals/cilium_ct_any6_global: Unable to get object /sys/fs/bpf/tc/globals/cilium_ct_any6_global: no such file or directory. Skipping.
