Get "http:///var/run/cilium/cilium.sock/v1/debuginfo": dial unix /var/run/cilium/cilium.sock: connect: no such file or directory
Is the agent running?
> Error while running 'cilium debuginfo --output=markdown,json -f --output-directory=/tmp/cilium-bugtool-20230727-064436.9+0000-UTC-1742781047/cmd':  exit status 1

