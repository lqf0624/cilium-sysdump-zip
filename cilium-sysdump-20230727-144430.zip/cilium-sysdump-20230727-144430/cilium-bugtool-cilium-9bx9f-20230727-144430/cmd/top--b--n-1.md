top - 06:44:37 up 3 days,  3:56,  0 users,  load average: 0.93, 1.86, 1.81
Tasks:  11 total,   3 running,   8 sleeping,   0 stopped,   0 zombie
%Cpu(s): 18.6 us, 25.4 sy,  0.0 ni, 51.7 id,  3.4 wa,  0.0 hi,  0.8 si,  0.0 st
MiB Mem :  15622.6 total,   9343.9 free,    657.4 used,   5621.2 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.  14630.3 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    197 root      20   0  709384   7104   5288 S  13.3   0.0   0:00.08 cilium-+
    257 root      20   0  704504   2704   2064 D   6.7   0.0   0:00.01 gops
    261 root      20   0    5888   1520   1236 R   6.7   0.0   0:00.01 lsmod
    263 root      20   0    3204    860    756 R   6.7   0.0   0:00.01 bpftool
      1 root      20   0  782660  68308  48300 S   0.0   0.4   0:00.98 cilium-+
    229 root      20   0    5972   3228   2800 R   0.0   0.0   0:00.01 top
    255 root      20   0  703992   1344   1068 D   0.0   0.0   0:00.00 gops
    256 root      20   0  704248   1348   1068 D   0.0   0.0   0:00.00 gops
    260 root      20   0    3620   2240   2084 D   0.0   0.0   0:00.00 ls
    266 root      20   0  730048   3148   1788 D   0.0   0.0   0:00.00 runc:[2+
    274 root      20   0    3204    792    692 D   0.0   0.0   0:00.00 bpftool
