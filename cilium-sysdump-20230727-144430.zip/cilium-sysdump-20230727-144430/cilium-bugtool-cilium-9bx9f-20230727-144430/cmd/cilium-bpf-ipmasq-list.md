error dumping contents of map: Unable to get object /sys/fs/bpf/tc/globals/cilium_ipmasq_v4: no such file or directory
> Error while running 'cilium bpf ipmasq list':  exit status 1

