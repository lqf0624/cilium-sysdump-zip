Unable to open /sys/fs/bpf/tc/globals/cilium_snat_v4_external: Unable to get object /sys/fs/bpf/tc/globals/cilium_snat_v4_external: no such file or directory. Skipping.
Unable to open /sys/fs/bpf/tc/globals/cilium_snat_v6_external: Unable to get object /sys/fs/bpf/tc/globals/cilium_snat_v6_external: no such file or directory. Skipping.
