Error: bpf obj get (/sys/fs/bpf/tc/globals/cilium_ct6_global): No such file or directory
> Error while running 'bpftool map dump pinned /sys/fs/bpf/tc/globals/cilium_ct6_global':  exit status 255

