0:	from all lookup local
32766:	from all lookup main
32767:	from all lookup default
