10.26.65.239 dev ens3 lladdr fa:16:3e:e5:90:43 REACHABLE 
10.244.242.64 dev vxlan.calico lladdr 66:e4:be:83:a3:0e PERMANENT 
10.26.65.219 dev ens3 lladdr fa:16:3e:fb:49:80 REACHABLE 
10.26.65.247 dev ens3 lladdr fa:16:3e:d6:53:b6 STALE 
10.26.65.253 dev ens3 FAILED 
10.26.65.224 dev ens3 lladdr fa:16:3e:fb:49:80 REACHABLE 
10.244.249.64 dev vxlan.calico lladdr 66:1c:82:36:23:65 PERMANENT 
10.26.65.227 dev ens3 lladdr fa:16:3e:95:ab:32 REACHABLE 
10.244.151.129 dev vxlan.calico lladdr 66:dc:36:3e:43:1f PERMANENT 
10.26.65.220 dev ens3 lladdr fa:16:3e:ad:b2:9d STALE 
10.26.65.226 dev ens3 lladdr fa:16:3e:78:1f:af REACHABLE 
10.26.65.254 dev ens3 lladdr bc:22:47:07:e8:01 REACHABLE 
10.244.141.2 dev vxlan.calico lladdr 66:c0:ac:9f:ef:42 PERMANENT 
10.26.65.222 dev ens3 lladdr fa:16:3e:f2:b6:35 REACHABLE 
10.244.207.129 dev vxlan.calico lladdr 66:ca:5b:b1:80:cc PERMANENT 
10.244.239.192 dev vxlan.calico lladdr 66:f9:19:2a:fd:c0 PERMANENT 
