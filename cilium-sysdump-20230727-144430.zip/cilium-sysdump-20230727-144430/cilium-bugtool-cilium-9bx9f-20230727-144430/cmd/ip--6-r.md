::1 dev lo proto kernel metric 256 pref medium
fe80::/64 dev ens3 proto kernel metric 256 pref medium
fe80::/64 dev vxlan.calico proto kernel metric 256 pref medium
