Error: Cannot get daemon encryption status: Get "http://%2Fvar%2Frun%2Fcilium%2Fcilium.sock/v1/healthz": dial unix /var/run/cilium/cilium.sock: connect: no such file or directory
> Error while running 'cilium encrypt status':  exit status 1

