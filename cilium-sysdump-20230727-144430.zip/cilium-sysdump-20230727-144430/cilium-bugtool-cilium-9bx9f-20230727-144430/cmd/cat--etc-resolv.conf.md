nameserver 223.5.5.5
search openstacklocal
