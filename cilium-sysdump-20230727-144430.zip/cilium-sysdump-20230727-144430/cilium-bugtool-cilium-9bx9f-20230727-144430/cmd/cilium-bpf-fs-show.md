MountID:          935
ParentID:         925
Mounted State:    true
MountPoint:       /sys/fs/bpf
MountOptions:     rw,relatime
OptionFields:     [shared:267]
FilesystemType:   bpf
MountSource:      bpffs
SuperOptions:     rw
