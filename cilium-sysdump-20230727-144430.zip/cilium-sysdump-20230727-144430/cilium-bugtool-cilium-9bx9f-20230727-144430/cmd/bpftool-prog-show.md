523: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2023-07-25T10:47:15+0000  uid 0
	xlated 64B  jited 41B  memlock 4096B
526: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2023-07-25T10:47:17+0000  uid 0
	xlated 64B  jited 41B  memlock 4096B
11497: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2023-07-25T12:36:05+0000  uid 0
	xlated 64B  jited 41B  memlock 4096B
11552: cgroup_device  tag c8b47a902f1cc68b  gpl
	loaded_at 2023-07-25T22:13:44+0000  uid 0
	xlated 464B  jited 289B  memlock 4096B
11556: cgroup_device  tag e3dbd137be8d6168  gpl
	loaded_at 2023-07-25T22:13:44+0000  uid 0
	xlated 504B  jited 310B  memlock 4096B
11557: cgroup_device  tag e3dbd137be8d6168  gpl
	loaded_at 2023-07-25T22:13:44+0000  uid 0
	xlated 504B  jited 310B  memlock 4096B
11558: cgroup_skb  tag 6deef7357e7b4530  gpl
	loaded_at 2023-07-25T22:13:44+0000  uid 0
	xlated 64B  jited 55B  memlock 4096B
11559: cgroup_skb  tag 6deef7357e7b4530  gpl
	loaded_at 2023-07-25T22:13:44+0000  uid 0
	xlated 64B  jited 55B  memlock 4096B
11560: cgroup_device  tag 8b9c33f36f812014  gpl
	loaded_at 2023-07-25T22:13:44+0000  uid 0
	xlated 744B  jited 448B  memlock 4096B
11561: cgroup_skb  tag 6deef7357e7b4530  gpl
	loaded_at 2023-07-25T22:13:44+0000  uid 0
	xlated 64B  jited 55B  memlock 4096B
11562: cgroup_skb  tag 6deef7357e7b4530  gpl
	loaded_at 2023-07-25T22:13:44+0000  uid 0
	xlated 64B  jited 55B  memlock 4096B
11563: cgroup_device  tag 0ecd07b7b633809f  gpl
	loaded_at 2023-07-25T22:13:44+0000  uid 0
	xlated 496B  jited 308B  memlock 4096B
11564: cgroup_skb  tag 6deef7357e7b4530  gpl
	loaded_at 2023-07-25T22:13:44+0000  uid 0
	xlated 64B  jited 55B  memlock 4096B
11565: cgroup_skb  tag 6deef7357e7b4530  gpl
	loaded_at 2023-07-25T22:13:44+0000  uid 0
	xlated 64B  jited 55B  memlock 4096B
11567: cgroup_device  tag 28a890580b33b0dc  gpl
	loaded_at 2023-07-25T22:13:44+0000  uid 0
	xlated 560B  jited 352B  memlock 4096B
11712: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2023-07-27T06:40:54+0000  uid 0
	xlated 64B  jited 41B  memlock 4096B
11716: cgroup_device  tag 81dfab3bd7eb416a  gpl
	loaded_at 2023-07-27T06:41:26+0000  uid 0
	xlated 472B  jited 295B  memlock 4096B
11719: cgroup_device  tag ab4bc4523b7fe6b4
	loaded_at 2023-07-27T06:41:26+0000  uid 0
	xlated 552B  jited 357B  memlock 4096B
11729: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2023-07-27T06:41:45+0000  uid 0
	xlated 64B  jited 41B  memlock 4096B
12483: cgroup_device  tag 81dfab3bd7eb416a  gpl
	loaded_at 2023-07-27T06:44:12+0000  uid 0
	xlated 472B  jited 295B  memlock 4096B
12486: cgroup_device  tag ab4bc4523b7fe6b4
	loaded_at 2023-07-27T06:44:12+0000  uid 0
	xlated 552B  jited 357B  memlock 4096B
