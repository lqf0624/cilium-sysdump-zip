USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         197  5.0  0.0 709128  6652 ?        Ssl  06:44   0:00 cilium-bugtool --archiveType=gz
root         213  0.0  0.0   5900  3008 ?        R    06:44   0:00  \_ ps auxfw
root         220  0.0  0.0      4     4 ?        R    06:44   0:00  \_ [bash]
root         221  0.0  0.0   3984  2976 ?        R    06:44   0:00  \_ bash -c ip -4 n
root         222  0.0  0.0      0     0 ?        R    06:44   0:00  \_ [ip]
root         223  0.0  0.0   5928   528 ?        R    06:44   0:00  \_ ip -d -s l
root         224  0.0  0.0   3984  3052 ?        R    06:44   0:00  \_ bash -c ss -t -p -a -i -s
root         225  0.0  0.0   3904  1088 ?        R    06:44   0:00  \_ bash -c ss -u -p -a -i -s
root         226  0.0  0.0   3984  2820 ?        R    06:44   0:00  \_ bash -c tc qdisc show
root           1  0.5  0.4 782660 68308 ?        Ssl  06:41   0:00 cilium-agent --config-dir=/tmp/cilium/config-map
