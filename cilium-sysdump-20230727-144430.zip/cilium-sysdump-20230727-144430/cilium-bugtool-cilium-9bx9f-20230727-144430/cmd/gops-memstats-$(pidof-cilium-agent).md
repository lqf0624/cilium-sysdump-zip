alloc: 8.89MB (9321664 bytes)
total-alloc: 16.36MB (17151240 bytes)
sys: 24.41MB (25600167 bytes)
lookups: 0
mallocs: 87351
frees: 59415
heap-alloc: 8.89MB (9321664 bytes)
heap-sys: 15.00MB (15728640 bytes)
heap-idle: 3.42MB (3588096 bytes)
heap-in-use: 11.58MB (12140544 bytes)
heap-released: 2.65MB (2777088 bytes)
heap-objects: 27936
stack-in-use: 1.00MB (1048576 bytes)
stack-sys: 1.00MB (1048576 bytes)
stack-mspan-inuse: 155.79KB (159528 bytes)
stack-mspan-sys: 160.00KB (163840 bytes)
stack-mcache-inuse: 9.38KB (9600 bytes)
stack-mcache-sys: 16.00KB (16384 bytes)
other-sys: 1.52MB (1598929 bytes)
gc-sys: 5.25MB (5503352 bytes)
next-gc: when heap-alloc >= 11.04MB (11573984 bytes)
last-gc: 2023-07-27 06:44:20.733769004 +0000 UTC
gc-pause-total: 2.265049ms
gc-pause: 487906
gc-pause-end: 1690440260733769004
num-gc: 6
num-forced-gc: 0
gc-cpu-fraction: 4.912115552062237e-05
enable-gc: true
debug-gc: false
