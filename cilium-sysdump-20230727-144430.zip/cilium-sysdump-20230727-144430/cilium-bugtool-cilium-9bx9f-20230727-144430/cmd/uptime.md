 06:44:36 up 3 days,  3:56,  0 users,  load average: 0.93, 1.86, 1.81
