CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    11556    device          multi                          
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    11565    ingress         multi                          
    11564    egress          multi                          
    11563    device          multi                          
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    11559    ingress         multi                          
    11558    egress          multi                          
    11557    device          multi                          
/run/cilium/cgroupv2/system.slice/chrony.service
    11567    device          multi                          
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    11552    device          multi                          
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    11562    ingress         multi                          
    11561    egress          multi                          
    11560    device          multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4f6be513_4c50_46e2_8eaa_c7ac24b6a0a9.slice/docker-3f4fdccb249c3c735291680c70c3111ee37219b4ab205a72cb614e5d88aab306.scope
    11712    device          multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod4f6be513_4c50_46e2_8eaa_c7ac24b6a0a9.slice/docker-a9309680ef7354b15785d5f5d8648d1248ac5e46a3e192e6f5012c1dd70c4bab.scope
    11729    device          multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1bb7a09a_64b5_4a02_bedb_7a3c87f6f5dd.slice/docker-1caaa453f7f0a883b4ef64d16202346b1b07c979bf099a167bac482a659fd184.scope
    526      device          multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1bb7a09a_64b5_4a02_bedb_7a3c87f6f5dd.slice/docker-c1529b3f0464beb577df3b861ffb4fb18e50947d71878beb86e87c223f4ab4de.scope
    523      device          multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36d472c9_553e_4f2e_ae33_9dc0bcb20f98.slice/docker-8873ea2ef7e0b75791c8f3d256b633f7dc3f3a054dc1da7b8525743714d34ed3.scope
    12486    device          multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36d472c9_553e_4f2e_ae33_9dc0bcb20f98.slice/docker-888285bba06b32d47a1a0ec6d2f0891cea2d6c53707d66974c717d10c839f06c.scope
    11719    device          multi                          
