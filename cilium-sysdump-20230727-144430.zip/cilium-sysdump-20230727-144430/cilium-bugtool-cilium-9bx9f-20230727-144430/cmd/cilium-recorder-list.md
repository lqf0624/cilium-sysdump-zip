Error: Cannot get recorder list: Get "http:///var/run/cilium/cilium.sock/v1/recorder": dial unix /var/run/cilium/cilium.sock: connect: no such file or directory
Is the agent running?
> Error while running 'cilium recorder list':  exit status 1

