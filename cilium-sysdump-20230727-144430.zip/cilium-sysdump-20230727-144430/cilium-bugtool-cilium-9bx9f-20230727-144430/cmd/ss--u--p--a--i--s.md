Total: 497
TCP:   277 (estab 240, closed 23, orphaned 0, timewait 23)

Transport Total     IP        IPv6
RAW	  2         1         1        
UDP	  10        8         2        
TCP	  254       248       6        
INET	  266       257       9        
FRAG	  0         0         0        

State  Recv-Q Send-Q     Local Address:Port   Peer Address:Port  Process
UNCONN 0      0          127.0.0.53%lo:domain      0.0.0.0:*            
UNCONN 0      0      10.26.65.231%ens3:bootpc      0.0.0.0:*            
UNCONN 0      0              127.0.0.1:323         0.0.0.0:*            
ESTAB  0      0           10.26.65.231:50055     223.5.5.5:domain       
ESTAB  0      0              127.0.0.1:50520    127.0.0.53:domain       
ESTAB  0      0           10.26.65.231:52597     223.5.5.5:domain       
ESTAB  0      0           10.26.65.231:52943     223.5.5.5:domain       
UNCONN 0      0                0.0.0.0:4789        0.0.0.0:*            
UNCONN 0      0                  [::1]:323            [::]:*            
UNCONN 0      0                      *:37489             *:*      users:(("cilium-agent",pid=1,fd=19))
