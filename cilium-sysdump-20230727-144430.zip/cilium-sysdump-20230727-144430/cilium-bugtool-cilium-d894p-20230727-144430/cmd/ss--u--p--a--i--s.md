Total: 497
TCP:   260 (estab 238, closed 10, orphaned 0, timewait 10)

Transport Total     IP        IPv6
RAW	  2         1         1        
UDP	  25        23        2        
TCP	  250       244       6        
INET	  277       268       9        
FRAG	  0         0         0        

State  Recv-Q Send-Q     Local Address:Port   Peer Address:Port  Process                              
ESTAB  0      0           10.26.65.222:35746     223.5.5.5:domain                                     
ESTAB  0      0           10.26.65.222:52611     223.5.5.5:domain                                     
ESTAB  0      0           10.26.65.222:53344     223.5.5.5:domain                                     
ESTAB  0      0           10.26.65.222:45335     223.5.5.5:domain                                     
UNCONN 0      0                0.0.0.0:4789        0.0.0.0:*                                          
ESTAB  0      0           10.26.65.222:46033     223.5.5.5:domain                                     
ESTAB  0      0              127.0.0.1:54576    127.0.0.53:domain                                     
ESTAB  0      0           10.26.65.222:54683     223.5.5.5:domain                                     
ESTAB  0      0           10.26.65.222:38370     223.5.5.5:domain                                     
ESTAB  0      0           10.26.65.222:38776     223.5.5.5:domain                                     
ESTAB  0      0           10.26.65.222:47049     223.5.5.5:domain                                     
ESTAB  0      0           10.26.65.222:56565     223.5.5.5:domain                                     
ESTAB  0      0           10.26.65.222:49200     223.5.5.5:domain                                     
UNCONN 0      0          127.0.0.53%lo:domain      0.0.0.0:*                                          
UNCONN 0      0      10.26.65.222%ens3:bootpc      0.0.0.0:*                                          
UNCONN 0      0              127.0.0.1:323         0.0.0.0:*                                          
ESTAB  0      0           10.26.65.222:49789     223.5.5.5:domain                                     
ESTAB  0      0           10.26.65.222:58159     223.5.5.5:domain                                     
ESTAB  0      0           10.26.65.222:58199     223.5.5.5:domain                                     
ESTAB  0      0           10.26.65.222:58308     223.5.5.5:domain                                     
ESTAB  0      0           10.26.65.222:34028     223.5.5.5:domain                                     
ESTAB  0      0           10.26.65.222:34723     223.5.5.5:domain                                     
ESTAB  0      0           10.26.65.222:43040     223.5.5.5:domain                                     
UNCONN 0      0                      *:37643             *:*      users:(("cilium-agent",pid=1,fd=19))
UNCONN 0      0                  [::1]:323            [::]:*                                          
