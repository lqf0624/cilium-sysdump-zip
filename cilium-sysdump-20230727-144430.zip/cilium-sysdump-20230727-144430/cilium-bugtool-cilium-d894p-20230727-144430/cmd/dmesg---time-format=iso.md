2023-07-24T02:46:08,000000+00:00 Linux version 5.15.0-67-generic (buildd@lcy02-amd64-116) (gcc (Ubuntu 11.3.0-1ubuntu1~22.04) 11.3.0, GNU ld (GNU Binutils for Ubuntu) 2.38) #74-Ubuntu SMP Wed Feb 22 14:14:39 UTC 2023 (Ubuntu 5.15.0-67.74-generic 5.15.85)
2023-07-24T02:46:08,000000+00:00 Command line: BOOT_IMAGE=/boot/vmlinuz-5.15.0-67-generic root=LABEL=cloudimg-rootfs ro console=tty1 console=ttyS0
2023-07-24T02:46:08,000000+00:00 KERNEL supported cpus:
2023-07-24T02:46:08,000000+00:00   Intel GenuineIntel
2023-07-24T02:46:08,000000+00:00   AMD AuthenticAMD
2023-07-24T02:46:08,000000+00:00   Hygon HygonGenuine
2023-07-24T02:46:08,000000+00:00   Centaur CentaurHauls
2023-07-24T02:46:08,000000+00:00   zhaoxin   Shanghai  
2023-07-24T02:46:08,000000+00:00 x86/fpu: Supporting XSAVE feature 0x001: 'x87 floating point registers'
2023-07-24T02:46:08,000000+00:00 x86/fpu: Supporting XSAVE feature 0x002: 'SSE registers'
2023-07-24T02:46:08,000000+00:00 x86/fpu: Supporting XSAVE feature 0x004: 'AVX registers'
2023-07-24T02:46:08,000000+00:00 x86/fpu: Supporting XSAVE feature 0x008: 'MPX bounds registers'
2023-07-24T02:46:08,000000+00:00 x86/fpu: Supporting XSAVE feature 0x010: 'MPX CSR'
2023-07-24T02:46:08,000000+00:00 x86/fpu: Supporting XSAVE feature 0x020: 'AVX-512 opmask'
2023-07-24T02:46:08,000000+00:00 x86/fpu: Supporting XSAVE feature 0x040: 'AVX-512 Hi256'
2023-07-24T02:46:08,000000+00:00 x86/fpu: Supporting XSAVE feature 0x080: 'AVX-512 ZMM_Hi256'
2023-07-24T02:46:08,000000+00:00 x86/fpu: Supporting XSAVE feature 0x200: 'Protection Keys User registers'
2023-07-24T02:46:08,000000+00:00 x86/fpu: xstate_offset[2]:  576, xstate_sizes[2]:  256
2023-07-24T02:46:08,000000+00:00 x86/fpu: xstate_offset[3]:  960, xstate_sizes[3]:   64
2023-07-24T02:46:08,000000+00:00 x86/fpu: xstate_offset[4]: 1024, xstate_sizes[4]:   64
2023-07-24T02:46:08,000000+00:00 x86/fpu: xstate_offset[5]: 1088, xstate_sizes[5]:   64
2023-07-24T02:46:08,000000+00:00 x86/fpu: xstate_offset[6]: 1152, xstate_sizes[6]:  512
2023-07-24T02:46:08,000000+00:00 x86/fpu: xstate_offset[7]: 1664, xstate_sizes[7]: 1024
2023-07-24T02:46:08,000000+00:00 x86/fpu: xstate_offset[9]: 2688, xstate_sizes[9]:    8
2023-07-24T02:46:08,000000+00:00 x86/fpu: Enabled xstate features 0x2ff, context size is 2696 bytes, using 'standard' format.
2023-07-24T02:46:08,000000+00:00 signal: max sigframe size: 3632
2023-07-24T02:46:08,000000+00:00 BIOS-provided physical RAM map:
2023-07-24T02:46:08,000000+00:00 BIOS-e820: [mem 0x0000000000000000-0x000000000009fbff] usable
2023-07-24T02:46:08,000000+00:00 BIOS-e820: [mem 0x000000000009fc00-0x000000000009ffff] reserved
2023-07-24T02:46:08,000000+00:00 BIOS-e820: [mem 0x00000000000f0000-0x00000000000fffff] reserved
2023-07-24T02:46:08,000000+00:00 BIOS-e820: [mem 0x0000000000100000-0x00000000bffdbfff] usable
2023-07-24T02:46:08,000000+00:00 BIOS-e820: [mem 0x00000000bffdc000-0x00000000bfffffff] reserved
2023-07-24T02:46:08,000000+00:00 BIOS-e820: [mem 0x00000000feffc000-0x00000000feffffff] reserved
2023-07-24T02:46:08,000000+00:00 BIOS-e820: [mem 0x00000000fffc0000-0x00000000ffffffff] reserved
2023-07-24T02:46:08,000000+00:00 BIOS-e820: [mem 0x0000000100000000-0x0000000427ffffff] usable
2023-07-24T02:46:08,000000+00:00 NX (Execute Disable) protection: active
2023-07-24T02:46:08,000000+00:00 SMBIOS 2.8 present.
2023-07-24T02:46:08,000000+00:00 DMI: OpenStack Foundation OpenStack Nova, BIOS 1.11.0-2.el7 04/01/2014
2023-07-24T02:46:08,000000+00:00 Hypervisor detected: KVM
2023-07-24T02:46:08,000000+00:00 kvm-clock: Using msrs 4b564d01 and 4b564d00
2023-07-24T02:46:08,000000+00:00 kvm-clock: cpu 0, msr 17b601001, primary cpu clock
2023-07-24T02:46:08,000002+00:00 kvm-clock: using sched offset of 1885997097 cycles
2023-07-24T02:46:08,000008+00:00 clocksource: kvm-clock: mask: 0xffffffffffffffff max_cycles: 0x1cd42e4dffb, max_idle_ns: 881590591483 ns
2023-07-24T02:46:08,000014+00:00 tsc: Detected 2394.374 MHz processor
2023-07-24T02:46:08,000753+00:00 e820: update [mem 0x00000000-0x00000fff] usable ==> reserved
2023-07-24T02:46:08,000757+00:00 e820: remove [mem 0x000a0000-0x000fffff] usable
2023-07-24T02:46:08,000763+00:00 last_pfn = 0x428000 max_arch_pfn = 0x400000000
2023-07-24T02:46:08,000815+00:00 x86/PAT: Configuration [0-7]: WB  WC  UC- UC  WB  WP  UC- WT  
2023-07-24T02:46:08,000836+00:00 last_pfn = 0xbffdc max_arch_pfn = 0x400000000
2023-07-24T02:46:08,009698+00:00 found SMP MP-table at [mem 0x000f6310-0x000f631f]
2023-07-24T02:46:08,009727+00:00 Using GB pages for direct mapping
2023-07-24T02:46:08,009894+00:00 RAMDISK: [mem 0x34257000-0x36122fff]
2023-07-24T02:46:08,009910+00:00 ACPI: Early table checksum verification disabled
2023-07-24T02:46:08,009940+00:00 ACPI: RSDP 0x00000000000F62C0 000014 (v00 BOCHS )
2023-07-24T02:46:08,009948+00:00 ACPI: RSDT 0x00000000BFFE12C6 00002C (v01 BOCHS  BXPCRSDT 00000001 BXPC 00000001)
2023-07-24T02:46:08,009956+00:00 ACPI: FACP 0x00000000BFFE11A2 000074 (v01 BOCHS  BXPCFACP 00000001 BXPC 00000001)
2023-07-24T02:46:08,009968+00:00 ACPI: DSDT 0x00000000BFFDFB80 001622 (v01 BOCHS  BXPCDSDT 00000001 BXPC 00000001)
2023-07-24T02:46:08,009973+00:00 ACPI: FACS 0x00000000BFFDFB40 000040
2023-07-24T02:46:08,009977+00:00 ACPI: APIC 0x00000000BFFE1216 0000B0 (v01 BOCHS  BXPCAPIC 00000001 BXPC 00000001)
2023-07-24T02:46:08,009980+00:00 ACPI: Reserving FACP table memory at [mem 0xbffe11a2-0xbffe1215]
2023-07-24T02:46:08,009982+00:00 ACPI: Reserving DSDT table memory at [mem 0xbffdfb80-0xbffe11a1]
2023-07-24T02:46:08,009984+00:00 ACPI: Reserving FACS table memory at [mem 0xbffdfb40-0xbffdfb7f]
2023-07-24T02:46:08,009985+00:00 ACPI: Reserving APIC table memory at [mem 0xbffe1216-0xbffe12c5]
2023-07-24T02:46:08,010559+00:00 No NUMA configuration found
2023-07-24T02:46:08,010561+00:00 Faking a node at [mem 0x0000000000000000-0x0000000427ffffff]
2023-07-24T02:46:08,010571+00:00 NODE_DATA(0) allocated [mem 0x427fd6000-0x427ffffff]
2023-07-24T02:46:08,011091+00:00 Zone ranges:
2023-07-24T02:46:08,011092+00:00   DMA      [mem 0x0000000000001000-0x0000000000ffffff]
2023-07-24T02:46:08,011097+00:00   DMA32    [mem 0x0000000001000000-0x00000000ffffffff]
2023-07-24T02:46:08,011098+00:00   Normal   [mem 0x0000000100000000-0x0000000427ffffff]
2023-07-24T02:46:08,011100+00:00   Device   empty
2023-07-24T02:46:08,011101+00:00 Movable zone start for each node
2023-07-24T02:46:08,011104+00:00 Early memory node ranges
2023-07-24T02:46:08,011105+00:00   node   0: [mem 0x0000000000001000-0x000000000009efff]
2023-07-24T02:46:08,011106+00:00   node   0: [mem 0x0000000000100000-0x00000000bffdbfff]
2023-07-24T02:46:08,011108+00:00   node   0: [mem 0x0000000100000000-0x0000000427ffffff]
2023-07-24T02:46:08,011113+00:00 Initmem setup node 0 [mem 0x0000000000001000-0x0000000427ffffff]
2023-07-24T02:46:08,011136+00:00 On node 0, zone DMA: 1 pages in unavailable ranges
2023-07-24T02:46:08,011398+00:00 On node 0, zone DMA: 97 pages in unavailable ranges
2023-07-24T02:46:08,263881+00:00 On node 0, zone Normal: 36 pages in unavailable ranges
2023-07-24T02:46:08,264549+00:00 ACPI: PM-Timer IO Port: 0x608
2023-07-24T02:46:08,264583+00:00 ACPI: LAPIC_NMI (acpi_id[0xff] dfl dfl lint[0x1])
2023-07-24T02:46:08,264634+00:00 IOAPIC[0]: apic_id 0, version 17, address 0xfec00000, GSI 0-23
2023-07-24T02:46:08,264638+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 0 global_irq 2 dfl dfl)
2023-07-24T02:46:08,264641+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 5 global_irq 5 high level)
2023-07-24T02:46:08,264642+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 9 global_irq 9 high level)
2023-07-24T02:46:08,264651+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 10 global_irq 10 high level)
2023-07-24T02:46:08,264652+00:00 ACPI: INT_SRC_OVR (bus 0 bus_irq 11 global_irq 11 high level)
2023-07-24T02:46:08,264656+00:00 ACPI: Using ACPI (MADT) for SMP configuration information
2023-07-24T02:46:08,264662+00:00 TSC deadline timer available
2023-07-24T02:46:08,264664+00:00 smpboot: Allowing 8 CPUs, 0 hotplug CPUs
2023-07-24T02:46:08,264699+00:00 PM: hibernation: Registered nosave memory: [mem 0x00000000-0x00000fff]
2023-07-24T02:46:08,264701+00:00 PM: hibernation: Registered nosave memory: [mem 0x0009f000-0x0009ffff]
2023-07-24T02:46:08,264702+00:00 PM: hibernation: Registered nosave memory: [mem 0x000a0000-0x000effff]
2023-07-24T02:46:08,264703+00:00 PM: hibernation: Registered nosave memory: [mem 0x000f0000-0x000fffff]
2023-07-24T02:46:08,264705+00:00 PM: hibernation: Registered nosave memory: [mem 0xbffdc000-0xbfffffff]
2023-07-24T02:46:08,264706+00:00 PM: hibernation: Registered nosave memory: [mem 0xc0000000-0xfeffbfff]
2023-07-24T02:46:08,264707+00:00 PM: hibernation: Registered nosave memory: [mem 0xfeffc000-0xfeffffff]
2023-07-24T02:46:08,264709+00:00 PM: hibernation: Registered nosave memory: [mem 0xff000000-0xfffbffff]
2023-07-24T02:46:08,264710+00:00 PM: hibernation: Registered nosave memory: [mem 0xfffc0000-0xffffffff]
2023-07-24T02:46:08,264712+00:00 [mem 0xc0000000-0xfeffbfff] available for PCI devices
2023-07-24T02:46:08,264713+00:00 Booting paravirtualized kernel on KVM
2023-07-24T02:46:08,264719+00:00 clocksource: refined-jiffies: mask: 0xffffffff max_cycles: 0xffffffff, max_idle_ns: 7645519600211568 ns
2023-07-24T02:46:08,264733+00:00 setup_percpu: NR_CPUS:8192 nr_cpumask_bits:8 nr_cpu_ids:8 nr_node_ids:1
2023-07-24T02:46:08,267002+00:00 percpu: Embedded 60 pages/cpu s208896 r8192 d28672 u262144
2023-07-24T02:46:08,267017+00:00 pcpu-alloc: s208896 r8192 d28672 u262144 alloc=1*2097152
2023-07-24T02:46:08,267020+00:00 pcpu-alloc: [0] 0 1 2 3 4 5 6 7 
2023-07-24T02:46:08,267052+00:00 kvm-guest: stealtime: cpu 0, msr 418232080
2023-07-24T02:46:08,267057+00:00 kvm-guest: PV spinlocks enabled
2023-07-24T02:46:08,267060+00:00 PV qspinlock hash table entries: 256 (order: 0, 4096 bytes, linear)
2023-07-24T02:46:08,267078+00:00 Built 1 zonelists, mobility grouping on.  Total pages: 4031708
2023-07-24T02:46:08,267080+00:00 Policy zone: Normal
2023-07-24T02:46:08,267081+00:00 Kernel command line: BOOT_IMAGE=/boot/vmlinuz-5.15.0-67-generic root=LABEL=cloudimg-rootfs ro console=tty1 console=ttyS0
2023-07-24T02:46:08,267132+00:00 Unknown kernel command line parameters "BOOT_IMAGE=/boot/vmlinuz-5.15.0-67-generic", will be passed to user space.
2023-07-24T02:46:08,283537+00:00 Dentry cache hash table entries: 2097152 (order: 12, 16777216 bytes, linear)
2023-07-24T02:46:08,291786+00:00 Inode-cache hash table entries: 1048576 (order: 11, 8388608 bytes, linear)
2023-07-24T02:46:08,291951+00:00 mem auto-init: stack:off, heap alloc:on, heap free:off
2023-07-24T02:46:08,410928+00:00 Memory: 15956884K/16383464K available (16393K kernel code, 4379K rwdata, 10820K rodata, 3240K init, 6556K bss, 426320K reserved, 0K cma-reserved)
2023-07-24T02:46:08,411349+00:00 SLUB: HWalign=64, Order=0-3, MinObjects=0, CPUs=8, Nodes=1
2023-07-24T02:46:08,411392+00:00 Kernel/User page tables isolation: enabled
2023-07-24T02:46:08,411442+00:00 ftrace: allocating 50555 entries in 198 pages
2023-07-24T02:46:08,439248+00:00 ftrace: allocated 198 pages with 4 groups
2023-07-24T02:46:08,439718+00:00 rcu: Hierarchical RCU implementation.
2023-07-24T02:46:08,439720+00:00 rcu: 	RCU restricting CPUs from NR_CPUS=8192 to nr_cpu_ids=8.
2023-07-24T02:46:08,439723+00:00 	Rude variant of Tasks RCU enabled.
2023-07-24T02:46:08,439724+00:00 	Tracing variant of Tasks RCU enabled.
2023-07-24T02:46:08,439725+00:00 rcu: RCU calculated value of scheduler-enlistment delay is 25 jiffies.
2023-07-24T02:46:08,439727+00:00 rcu: Adjusting geometry for rcu_fanout_leaf=16, nr_cpu_ids=8
2023-07-24T02:46:08,443790+00:00 NR_IRQS: 524544, nr_irqs: 488, preallocated irqs: 16
2023-07-24T02:46:08,443982+00:00 random: crng init done
2023-07-24T02:46:08,460165+00:00 Console: colour VGA+ 80x25
2023-07-24T02:46:08,507352+00:00 printk: console [tty1] enabled
2023-07-24T02:46:08,769913+00:00 printk: console [ttyS0] enabled
2023-07-24T02:46:08,771591+00:00 ACPI: Core revision 20210730
2023-07-24T02:46:08,773222+00:00 APIC: Switch to symmetric I/O mode setup
2023-07-24T02:46:08,775402+00:00 x2apic enabled
2023-07-24T02:46:08,776841+00:00 Switched APIC routing to physical x2apic.
2023-07-24T02:46:08,779884+00:00 clocksource: tsc-early: mask: 0xffffffffffffffff max_cycles: 0x228374dae5d, max_idle_ns: 440795268352 ns
2023-07-24T02:46:08,784070+00:00 Calibrating delay loop (skipped) preset value.. 4788.74 BogoMIPS (lpj=9577496)
2023-07-24T02:46:08,787394+00:00 pid_max: default: 32768 minimum: 301
2023-07-24T02:46:08,788064+00:00 LSM: Security Framework initializing
2023-07-24T02:46:08,788064+00:00 landlock: Up and running.
2023-07-24T02:46:08,788064+00:00 Yama: becoming mindful.
2023-07-24T02:46:08,788064+00:00 AppArmor: AppArmor initialized
2023-07-24T02:46:08,788064+00:00 Mount-cache hash table entries: 32768 (order: 6, 262144 bytes, linear)
2023-07-24T02:46:08,788064+00:00 Mountpoint-cache hash table entries: 32768 (order: 6, 262144 bytes, linear)
2023-07-24T02:46:08,788064+00:00 Last level iTLB entries: 4KB 0, 2MB 0, 4MB 0
2023-07-24T02:46:08,788064+00:00 Last level dTLB entries: 4KB 0, 2MB 0, 4MB 0, 1GB 0
2023-07-24T02:46:08,788064+00:00 Spectre V1 : Mitigation: usercopy/swapgs barriers and __user pointer sanitization
2023-07-24T02:46:08,788064+00:00 Spectre V2 : Mitigation: IBRS
2023-07-24T02:46:08,788064+00:00 Spectre V2 : Spectre v2 / SpectreRSB mitigation: Filling RSB on context switch
2023-07-24T02:46:08,788064+00:00 Spectre V2 : Spectre v2 / SpectreRSB : Filling RSB on VMEXIT
2023-07-24T02:46:08,788064+00:00 RETBleed: Mitigation: IBRS
2023-07-24T02:46:08,788064+00:00 Spectre V2 : mitigation: Enabling conditional Indirect Branch Prediction Barrier
2023-07-24T02:46:08,788064+00:00 Speculative Store Bypass: Mitigation: Speculative Store Bypass disabled via prctl and seccomp
2023-07-24T02:46:08,788064+00:00 MDS: Mitigation: Clear CPU buffers
2023-07-24T02:46:08,788064+00:00 TAA: Mitigation: Clear CPU buffers
2023-07-24T02:46:08,788064+00:00 MMIO Stale Data: Vulnerable: Clear CPU buffers attempted, no microcode
2023-07-24T02:46:08,788064+00:00 Freeing SMP alternatives memory: 44K
2023-07-24T02:46:08,788064+00:00 smpboot: CPU0: Intel Xeon Processor (Skylake, IBRS) (family: 0x6, model: 0x55, stepping: 0x4)
2023-07-24T02:46:08,788512+00:00 Performance Events: unsupported p6 CPU model 85 no PMU driver, software events only.
2023-07-24T02:46:08,792212+00:00 rcu: Hierarchical SRCU implementation.
2023-07-24T02:46:08,796170+00:00 NMI watchdog: Perf NMI watchdog permanently disabled
2023-07-24T02:46:08,800129+00:00 smp: Bringing up secondary CPUs ...
2023-07-24T02:46:08,803131+00:00 x86: Booting SMP configuration:
2023-07-24T02:46:08,804070+00:00 .... node  #0, CPUs:      #1
2023-07-24T02:46:08,344094+00:00 kvm-clock: cpu 1, msr 17b601041, secondary cpu clock
2023-07-24T02:46:08,344094+00:00 smpboot: CPU 1 Converting physical 0 to logical die 1
2023-07-24T02:46:08,820089+00:00 kvm-guest: stealtime: cpu 1, msr 418272080
2023-07-24T02:46:08,823520+00:00  #2
2023-07-24T02:46:08,344094+00:00 kvm-clock: cpu 2, msr 17b601081, secondary cpu clock
2023-07-24T02:46:08,344094+00:00 smpboot: CPU 2 Converting physical 0 to logical die 2
2023-07-24T02:46:08,840084+00:00 kvm-guest: stealtime: cpu 2, msr 4182b2080
2023-07-24T02:46:08,843509+00:00  #3
2023-07-24T02:46:08,344094+00:00 kvm-clock: cpu 3, msr 17b6010c1, secondary cpu clock
2023-07-24T02:46:08,344094+00:00 smpboot: CPU 3 Converting physical 0 to logical die 3
2023-07-24T02:46:08,860084+00:00 kvm-guest: stealtime: cpu 3, msr 4182f2080
2023-07-24T02:46:08,863478+00:00  #4
2023-07-24T02:46:08,344094+00:00 kvm-clock: cpu 4, msr 17b601101, secondary cpu clock
2023-07-24T02:46:08,344094+00:00 smpboot: CPU 4 Converting physical 0 to logical die 4
2023-07-24T02:46:08,880083+00:00 kvm-guest: stealtime: cpu 4, msr 418332080
2023-07-24T02:46:08,883383+00:00  #5
2023-07-24T02:46:08,344094+00:00 kvm-clock: cpu 5, msr 17b601141, secondary cpu clock
2023-07-24T02:46:08,344094+00:00 smpboot: CPU 5 Converting physical 0 to logical die 5
2023-07-24T02:46:08,900084+00:00 kvm-guest: stealtime: cpu 5, msr 418372080
2023-07-24T02:46:08,903507+00:00  #6
2023-07-24T02:46:08,344094+00:00 kvm-clock: cpu 6, msr 17b601181, secondary cpu clock
2023-07-24T02:46:08,344094+00:00 smpboot: CPU 6 Converting physical 0 to logical die 6
2023-07-24T02:46:08,920084+00:00 kvm-guest: stealtime: cpu 6, msr 4183b2080
2023-07-24T02:46:08,924440+00:00  #7
2023-07-24T02:46:08,344094+00:00 kvm-clock: cpu 7, msr 17b6011c1, secondary cpu clock
2023-07-24T02:46:08,344094+00:00 smpboot: CPU 7 Converting physical 0 to logical die 7
2023-07-24T02:46:08,940085+00:00 kvm-guest: stealtime: cpu 7, msr 4183f2080
2023-07-24T02:46:08,943228+00:00 smp: Brought up 1 node, 8 CPUs
2023-07-24T02:46:08,944071+00:00 smpboot: Max logical packages: 8
2023-07-24T02:46:08,946904+00:00 smpboot: Total of 8 processors activated (38309.98 BogoMIPS)
2023-07-24T02:46:08,949474+00:00 devtmpfs: initialized
2023-07-24T02:46:08,952140+00:00 x86/mm: Memory block size: 128MB
2023-07-24T02:46:08,956749+00:00 clocksource: jiffies: mask: 0xffffffff max_cycles: 0xffffffff, max_idle_ns: 7645041785100000 ns
2023-07-24T02:46:08,960211+00:00 futex hash table entries: 2048 (order: 5, 131072 bytes, linear)
2023-07-24T02:46:08,964150+00:00 pinctrl core: initialized pinctrl subsystem
2023-07-24T02:46:08,967086+00:00 PM: RTC time: 02:46:09, date: 2023-07-24
2023-07-24T02:46:08,968546+00:00 NET: Registered PF_NETLINK/PF_ROUTE protocol family
2023-07-24T02:46:08,973737+00:00 DMA: preallocated 2048 KiB GFP_KERNEL pool for atomic allocations
2023-07-24T02:46:08,977675+00:00 DMA: preallocated 2048 KiB GFP_KERNEL|GFP_DMA pool for atomic allocations
2023-07-24T02:46:08,981663+00:00 DMA: preallocated 2048 KiB GFP_KERNEL|GFP_DMA32 pool for atomic allocations
2023-07-24T02:46:08,984077+00:00 audit: initializing netlink subsys (disabled)
2023-07-24T02:46:08,986484+00:00 audit: type=2000 audit(1690167097.690:1): state=initialized audit_enabled=0 res=1
2023-07-24T02:46:08,986484+00:00 thermal_sys: Registered thermal governor 'fair_share'
2023-07-24T02:46:08,988068+00:00 thermal_sys: Registered thermal governor 'bang_bang'
2023-07-24T02:46:08,990629+00:00 thermal_sys: Registered thermal governor 'step_wise'
2023-07-24T02:46:08,992067+00:00 thermal_sys: Registered thermal governor 'user_space'
2023-07-24T02:46:08,994763+00:00 thermal_sys: Registered thermal governor 'power_allocator'
2023-07-24T02:46:08,996074+00:00 EISA bus registered
2023-07-24T02:46:09,000073+00:00 cpuidle: using governor ladder
2023-07-24T02:46:09,001681+00:00 cpuidle: using governor menu
2023-07-24T02:46:09,003510+00:00 ACPI: bus type PCI registered
2023-07-24T02:46:09,004068+00:00 acpiphp: ACPI Hot Plug PCI Controller Driver version: 0.5
2023-07-24T02:46:09,006750+00:00 PCI: Using configuration type 1 for base access
2023-07-24T02:46:09,010044+00:00 Kprobes globally optimized
2023-07-24T02:46:09,012173+00:00 HugeTLB registered 1.00 GiB page size, pre-allocated 0 pages
2023-07-24T02:46:09,014591+00:00 HugeTLB registered 2.00 MiB page size, pre-allocated 0 pages
2023-07-24T02:46:09,020190+00:00 ACPI: Added _OSI(Module Device)
2023-07-24T02:46:09,021867+00:00 ACPI: Added _OSI(Processor Device)
2023-07-24T02:46:09,024068+00:00 ACPI: Added _OSI(3.0 _SCP Extensions)
2023-07-24T02:46:09,026640+00:00 ACPI: Added _OSI(Processor Aggregator Device)
2023-07-24T02:46:09,028068+00:00 ACPI: Added _OSI(Linux-Dell-Video)
2023-07-24T02:46:09,030509+00:00 ACPI: Added _OSI(Linux-Lenovo-NV-HDMI-Audio)
2023-07-24T02:46:09,032067+00:00 ACPI: Added _OSI(Linux-HPI-Hybrid-Graphics)
2023-07-24T02:46:09,035506+00:00 ACPI: 1 ACPI AML tables successfully acquired and loaded
2023-07-24T02:46:09,037815+00:00 ACPI: Interpreter enabled
2023-07-24T02:46:09,039329+00:00 ACPI: PM: (supports S0 S5)
2023-07-24T02:46:09,040076+00:00 ACPI: Using IOAPIC for interrupt routing
2023-07-24T02:46:09,042024+00:00 PCI: Using host bridge windows from ACPI; if necessary, use "pci=nocrs" and report a bug
2023-07-24T02:46:09,044067+00:00 PCI: Using E820 reservations for host bridge windows
2023-07-24T02:46:09,046542+00:00 ACPI: Enabled 2 GPEs in block 00 to 0F
2023-07-24T02:46:09,052154+00:00 ACPI: PCI Root Bridge [PCI0] (domain 0000 [bus 00-ff])
2023-07-24T02:46:09,054506+00:00 acpi PNP0A03:00: _OSC: OS supports [ASPM ClockPM Segments MSI EDR HPX-Type3]
2023-07-24T02:46:09,056080+00:00 acpi PNP0A03:00: fail to add MMCONFIG information, can't access extended PCI configuration space under this bridge.
2023-07-24T02:46:09,060451+00:00 acpiphp: Slot [3] registered
2023-07-24T02:46:09,062204+00:00 acpiphp: Slot [4] registered
2023-07-24T02:46:09,063963+00:00 acpiphp: Slot [5] registered
2023-07-24T02:46:09,064093+00:00 acpiphp: Slot [6] registered
2023-07-24T02:46:09,065677+00:00 acpiphp: Slot [7] registered
2023-07-24T02:46:09,067278+00:00 acpiphp: Slot [8] registered
2023-07-24T02:46:09,068091+00:00 acpiphp: Slot [9] registered
2023-07-24T02:46:09,069663+00:00 acpiphp: Slot [10] registered
2023-07-24T02:46:09,071297+00:00 acpiphp: Slot [11] registered
2023-07-24T02:46:09,072090+00:00 acpiphp: Slot [12] registered
2023-07-24T02:46:09,073700+00:00 acpiphp: Slot [13] registered
2023-07-24T02:46:09,075300+00:00 acpiphp: Slot [14] registered
2023-07-24T02:46:09,076091+00:00 acpiphp: Slot [15] registered
2023-07-24T02:46:09,077699+00:00 acpiphp: Slot [16] registered
2023-07-24T02:46:09,079452+00:00 acpiphp: Slot [17] registered
2023-07-24T02:46:09,080098+00:00 acpiphp: Slot [18] registered
2023-07-24T02:46:09,081708+00:00 acpiphp: Slot [19] registered
2023-07-24T02:46:09,083331+00:00 acpiphp: Slot [20] registered
2023-07-24T02:46:09,084091+00:00 acpiphp: Slot [21] registered
2023-07-24T02:46:09,085691+00:00 acpiphp: Slot [22] registered
2023-07-24T02:46:09,087298+00:00 acpiphp: Slot [23] registered
2023-07-24T02:46:09,088098+00:00 acpiphp: Slot [24] registered
2023-07-24T02:46:09,089739+00:00 acpiphp: Slot [25] registered
2023-07-24T02:46:09,091351+00:00 acpiphp: Slot [26] registered
2023-07-24T02:46:09,092106+00:00 acpiphp: Slot [27] registered
2023-07-24T02:46:09,093702+00:00 acpiphp: Slot [28] registered
2023-07-24T02:46:09,095369+00:00 acpiphp: Slot [29] registered
2023-07-24T02:46:09,096098+00:00 acpiphp: Slot [30] registered
2023-07-24T02:46:09,097710+00:00 acpiphp: Slot [31] registered
2023-07-24T02:46:09,099309+00:00 PCI host bridge to bus 0000:00
2023-07-24T02:46:09,100069+00:00 pci_bus 0000:00: root bus resource [bus 00-ff]
2023-07-24T02:46:09,102145+00:00 pci_bus 0000:00: root bus resource [io  0x0000-0x0cf7 window]
2023-07-24T02:46:09,104067+00:00 pci_bus 0000:00: root bus resource [io  0x0d00-0xffff window]
2023-07-24T02:46:09,106615+00:00 pci_bus 0000:00: root bus resource [mem 0x000a0000-0x000bffff window]
2023-07-24T02:46:09,108067+00:00 pci_bus 0000:00: root bus resource [mem 0xc0000000-0xfebfffff window]
2023-07-24T02:46:09,110896+00:00 pci_bus 0000:00: root bus resource [mem 0x440000000-0x4bfffffff window]
2023-07-24T02:46:09,112242+00:00 pci 0000:00:00.0: [8086:1237] type 00 class 0x060000
2023-07-24T02:46:09,115610+00:00 pci 0000:00:01.0: [8086:7000] type 00 class 0x060100
2023-07-24T02:46:09,117009+00:00 pci 0000:00:01.1: [8086:7010] type 00 class 0x010180
2023-07-24T02:46:09,122233+00:00 pci 0000:00:01.1: reg 0x20: [io  0xc0c0-0xc0cf]
2023-07-24T02:46:09,125204+00:00 pci 0000:00:01.1: legacy IDE quirk: reg 0x10: [io  0x01f0-0x01f7]
2023-07-24T02:46:09,127926+00:00 pci 0000:00:01.1: legacy IDE quirk: reg 0x14: [io  0x03f6]
2023-07-24T02:46:09,128068+00:00 pci 0000:00:01.1: legacy IDE quirk: reg 0x18: [io  0x0170-0x0177]
2023-07-24T02:46:09,130942+00:00 pci 0000:00:01.1: legacy IDE quirk: reg 0x1c: [io  0x0376]
2023-07-24T02:46:09,132404+00:00 pci 0000:00:01.2: [8086:7020] type 00 class 0x0c0300
2023-07-24T02:46:09,137289+00:00 pci 0000:00:01.2: reg 0x20: [io  0xc080-0xc09f]
2023-07-24T02:46:09,140704+00:00 pci 0000:00:01.3: [8086:7113] type 00 class 0x068000
2023-07-24T02:46:09,143686+00:00 pci 0000:00:01.3: quirk: [io  0x0600-0x063f] claimed by PIIX4 ACPI
2023-07-24T02:46:09,144082+00:00 pci 0000:00:01.3: quirk: [io  0x0700-0x070f] claimed by PIIX4 SMB
2023-07-24T02:46:09,147656+00:00 pci 0000:00:02.0: [1013:00b8] type 00 class 0x030000
2023-07-24T02:46:09,152546+00:00 pci 0000:00:02.0: reg 0x10: [mem 0xfc000000-0xfdffffff pref]
2023-07-24T02:46:09,157151+00:00 pci 0000:00:02.0: reg 0x14: [mem 0xfebd0000-0xfebd0fff]
2023-07-24T02:46:09,165606+00:00 pci 0000:00:02.0: reg 0x30: [mem 0xfebc0000-0xfebcffff pref]
2023-07-24T02:46:09,168263+00:00 pci 0000:00:02.0: Video device with shadowed ROM at [mem 0x000c0000-0x000dffff]
2023-07-24T02:46:09,173210+00:00 pci 0000:00:03.0: [1af4:1000] type 00 class 0x020000
2023-07-24T02:46:09,176889+00:00 pci 0000:00:03.0: reg 0x10: [io  0xc000-0xc03f]
2023-07-24T02:46:09,180468+00:00 pci 0000:00:03.0: reg 0x14: [mem 0xfebd1000-0xfebd1fff]
2023-07-24T02:46:09,186709+00:00 pci 0000:00:03.0: reg 0x20: [mem 0xfe000000-0xfe003fff 64bit pref]
2023-07-24T02:46:09,188699+00:00 pci 0000:00:03.0: reg 0x30: [mem 0xfeb80000-0xfebbffff pref]
2023-07-24T02:46:09,193296+00:00 pci 0000:00:04.0: [1af4:1001] type 00 class 0x010000
2023-07-24T02:46:09,196941+00:00 pci 0000:00:04.0: reg 0x10: [io  0xc040-0xc07f]
2023-07-24T02:46:09,200069+00:00 pci 0000:00:04.0: reg 0x14: [mem 0xfebd2000-0xfebd2fff]
2023-07-24T02:46:09,205325+00:00 pci 0000:00:04.0: reg 0x20: [mem 0xfe004000-0xfe007fff 64bit pref]
2023-07-24T02:46:09,210276+00:00 pci 0000:00:05.0: [1af4:1002] type 00 class 0x00ff00
2023-07-24T02:46:09,212707+00:00 pci 0000:00:05.0: reg 0x10: [io  0xc0a0-0xc0bf]
2023-07-24T02:46:09,218004+00:00 pci 0000:00:05.0: reg 0x20: [mem 0xfe008000-0xfe00bfff 64bit pref]
2023-07-24T02:46:09,230504+00:00 ACPI: PCI: Interrupt link LNKA configured for IRQ 10
2023-07-24T02:46:09,232246+00:00 ACPI: PCI: Interrupt link LNKB configured for IRQ 10
2023-07-24T02:46:09,236026+00:00 ACPI: PCI: Interrupt link LNKC configured for IRQ 11
2023-07-24T02:46:09,236244+00:00 ACPI: PCI: Interrupt link LNKD configured for IRQ 11
2023-07-24T02:46:09,239539+00:00 ACPI: PCI: Interrupt link LNKS configured for IRQ 9
2023-07-24T02:46:09,241217+00:00 iommu: Default domain type: Translated 
2023-07-24T02:46:09,242002+00:00 iommu: DMA domain TLB invalidation policy: lazy mode 
2023-07-24T02:46:09,244607+00:00 SCSI subsystem initialized
2023-07-24T02:46:09,246246+00:00 libata version 3.00 loaded.
2023-07-24T02:46:09,246246+00:00 pci 0000:00:02.0: vgaarb: setting as boot VGA device
2023-07-24T02:46:09,246354+00:00 pci 0000:00:02.0: vgaarb: VGA device added: decodes=io+mem,owns=io+mem,locks=none
2023-07-24T02:46:09,248069+00:00 pci 0000:00:02.0: vgaarb: bridge control possible
2023-07-24T02:46:09,250207+00:00 vgaarb: loaded
2023-07-24T02:46:09,251406+00:00 ACPI: bus type USB registered
2023-07-24T02:46:09,252093+00:00 usbcore: registered new interface driver usbfs
2023-07-24T02:46:09,254218+00:00 usbcore: registered new interface driver hub
2023-07-24T02:46:09,256075+00:00 usbcore: registered new device driver usb
2023-07-24T02:46:09,258034+00:00 pps_core: LinuxPPS API ver. 1 registered
2023-07-24T02:46:09,260066+00:00 pps_core: Software ver. 5.3.6 - Copyright 2005-2007 Rodolfo Giometti <giometti@linux.it>
2023-07-24T02:46:09,263457+00:00 PTP clock support registered
2023-07-24T02:46:09,264166+00:00 EDAC MC: Ver: 3.0.0
2023-07-24T02:46:09,265701+00:00 NetLabel: Initializing
2023-07-24T02:46:09,268068+00:00 NetLabel:  domain hash size = 128
2023-07-24T02:46:09,269776+00:00 NetLabel:  protocols = UNLABELED CIPSOv4 CALIPSO
2023-07-24T02:46:09,271920+00:00 NetLabel:  unlabeled traffic allowed by default
2023-07-24T02:46:09,272118+00:00 PCI: Using ACPI for IRQ routing
2023-07-24T02:46:09,273783+00:00 PCI: pci_cache_line_size set to 64 bytes
2023-07-24T02:46:09,274019+00:00 e820: reserve RAM buffer [mem 0x0009fc00-0x0009ffff]
2023-07-24T02:46:09,274024+00:00 e820: reserve RAM buffer [mem 0xbffdc000-0xbfffffff]
2023-07-24T02:46:09,274078+00:00 clocksource: Switched to clocksource kvm-clock
2023-07-24T02:46:09,306667+00:00 VFS: Disk quotas dquot_6.6.0
2023-07-24T02:46:09,309345+00:00 VFS: Dquot-cache hash table entries: 512 (order 0, 4096 bytes)
2023-07-24T02:46:09,314126+00:00 AppArmor: AppArmor Filesystem Enabled
2023-07-24T02:46:09,317294+00:00 pnp: PnP ACPI init
2023-07-24T02:46:09,319555+00:00 pnp 00:03: [dma 2]
2023-07-24T02:46:09,319950+00:00 pnp: PnP ACPI: found 5 devices
2023-07-24T02:46:09,330856+00:00 clocksource: acpi_pm: mask: 0xffffff max_cycles: 0xffffff, max_idle_ns: 2085701024 ns
2023-07-24T02:46:09,336317+00:00 NET: Registered PF_INET protocol family
2023-07-24T02:46:09,341556+00:00 IP idents hash table entries: 262144 (order: 9, 2097152 bytes, linear)
2023-07-24T02:46:09,348192+00:00 tcp_listen_portaddr_hash hash table entries: 8192 (order: 5, 131072 bytes, linear)
2023-07-24T02:46:09,367162+00:00 Table-perturb hash table entries: 65536 (order: 6, 262144 bytes, linear)
2023-07-24T02:46:09,373069+00:00 TCP established hash table entries: 131072 (order: 8, 1048576 bytes, linear)
2023-07-24T02:46:09,379525+00:00 TCP bind hash table entries: 65536 (order: 8, 1048576 bytes, linear)
2023-07-24T02:46:09,384110+00:00 TCP: Hash tables configured (established 131072 bind 65536)
2023-07-24T02:46:09,388664+00:00 MPTCP token hash table entries: 16384 (order: 6, 393216 bytes, linear)
2023-07-24T02:46:09,392977+00:00 UDP hash table entries: 8192 (order: 6, 262144 bytes, linear)
2023-07-24T02:46:09,395830+00:00 UDP-Lite hash table entries: 8192 (order: 6, 262144 bytes, linear)
2023-07-24T02:46:09,398773+00:00 NET: Registered PF_UNIX/PF_LOCAL protocol family
2023-07-24T02:46:09,401027+00:00 NET: Registered PF_XDP protocol family
2023-07-24T02:46:09,402930+00:00 pci_bus 0000:00: resource 4 [io  0x0000-0x0cf7 window]
2023-07-24T02:46:09,405233+00:00 pci_bus 0000:00: resource 5 [io  0x0d00-0xffff window]
2023-07-24T02:46:09,407555+00:00 pci_bus 0000:00: resource 6 [mem 0x000a0000-0x000bffff window]
2023-07-24T02:46:09,410108+00:00 pci_bus 0000:00: resource 7 [mem 0xc0000000-0xfebfffff window]
2023-07-24T02:46:09,412679+00:00 pci_bus 0000:00: resource 8 [mem 0x440000000-0x4bfffffff window]
2023-07-24T02:46:09,415291+00:00 pci 0000:00:01.0: PIIX3: Enabling Passive Release
2023-07-24T02:46:09,417414+00:00 pci 0000:00:00.0: Limiting direct PCI/PCI transfers
2023-07-24T02:46:09,419611+00:00 pci 0000:00:01.0: Activating ISA DMA hang workarounds
2023-07-24T02:46:09,455815+00:00 ACPI: \_SB_.LNKD: Enabled at IRQ 11
2023-07-24T02:46:09,503806+00:00 pci 0000:00:01.2: quirk_usb_early_handoff+0x0/0x160 took 79972 usecs
2023-07-24T02:46:09,508777+00:00 PCI: CLS 0 bytes, default 64
2023-07-24T02:46:09,511710+00:00 Trying to unpack rootfs image as initramfs...
2023-07-24T02:46:09,515407+00:00 PCI-DMA: Using software bounce buffering for IO (SWIOTLB)
2023-07-24T02:46:09,523643+00:00 software IO TLB: mapped [mem 0x00000000bbfdc000-0x00000000bffdc000] (64MB)
2023-07-24T02:46:09,531281+00:00 clocksource: tsc: mask: 0xffffffffffffffff max_cycles: 0x228374dae5d, max_idle_ns: 440795268352 ns
2023-07-24T02:46:09,538407+00:00 Initialise system trusted keyrings
2023-07-24T02:46:09,540920+00:00 Key type blacklist registered
2023-07-24T02:46:09,543126+00:00 workingset: timestamp_bits=36 max_order=22 bucket_order=0
2023-07-24T02:46:09,547791+00:00 zbud: loaded
2023-07-24T02:46:09,549586+00:00 squashfs: version 4.0 (2009/01/31) Phillip Lougher
2023-07-24T02:46:09,552448+00:00 fuse: init (API version 7.34)
2023-07-24T02:46:09,555080+00:00 integrity: Platform Keyring initialized
2023-07-24T02:46:09,564210+00:00 Key type asymmetric registered
2023-07-24T02:46:09,566627+00:00 Asymmetric key parser 'x509' registered
2023-07-24T02:46:09,569535+00:00 Block layer SCSI generic (bsg) driver version 0.4 loaded (major 243)
2023-07-24T02:46:09,574208+00:00 io scheduler mq-deadline registered
2023-07-24T02:46:09,577528+00:00 shpchp: Standard Hot Plug PCI Controller Driver version: 0.4
2023-07-24T02:46:09,580818+00:00 input: Power Button as /devices/LNXSYSTM:00/LNXPWRBN:00/input/input0
2023-07-24T02:46:09,584566+00:00 ACPI: button: Power Button [PWRF]
2023-07-24T02:46:09,624247+00:00 ACPI: \_SB_.LNKC: Enabled at IRQ 10
2023-07-24T02:46:09,702786+00:00 ACPI: \_SB_.LNKA: Enabled at IRQ 10
2023-07-24T02:46:09,708428+00:00 Serial: 8250/16550 driver, 32 ports, IRQ sharing enabled
2023-07-24T02:46:09,742462+00:00 00:04: ttyS0 at I/O 0x3f8 (irq = 4, base_baud = 115200) is a 16550A
2023-07-24T02:46:09,749607+00:00 Linux agpgart interface v0.103
2023-07-24T02:46:09,761107+00:00 loop: module loaded
2023-07-24T02:46:09,763552+00:00 ata_piix 0000:00:01.1: version 2.13
2023-07-24T02:46:09,764977+00:00 scsi host0: ata_piix
2023-07-24T02:46:09,767838+00:00 scsi host1: ata_piix
2023-07-24T02:46:09,770185+00:00 ata1: PATA max MWDMA2 cmd 0x1f0 ctl 0x3f6 bmdma 0xc0c0 irq 14
2023-07-24T02:46:09,774708+00:00 ata2: PATA max MWDMA2 cmd 0x170 ctl 0x376 bmdma 0xc0c8 irq 15
2023-07-24T02:46:09,778895+00:00 tun: Universal TUN/TAP device driver, 1.6
2023-07-24T02:46:09,782102+00:00 PPP generic driver version 2.4.2
2023-07-24T02:46:09,784841+00:00 VFIO - User Level meta-driver version: 0.3
2023-07-24T02:46:09,787224+00:00 ehci_hcd: USB 2.0 'Enhanced' Host Controller (EHCI) Driver
2023-07-24T02:46:09,789891+00:00 ehci-pci: EHCI PCI platform driver
2023-07-24T02:46:09,791726+00:00 ehci-platform: EHCI generic platform driver
2023-07-24T02:46:09,794410+00:00 ohci_hcd: USB 1.1 'Open' Host Controller (OHCI) Driver
2023-07-24T02:46:09,797178+00:00 ohci-pci: OHCI PCI platform driver
2023-07-24T02:46:09,799216+00:00 ohci-platform: OHCI generic platform driver
2023-07-24T02:46:09,801553+00:00 uhci_hcd: USB Universal Host Controller Interface driver
2023-07-24T02:46:09,843325+00:00 uhci_hcd 0000:00:01.2: UHCI Host Controller
2023-07-24T02:46:09,846661+00:00 uhci_hcd 0000:00:01.2: new USB bus registered, assigned bus number 1
2023-07-24T02:46:09,851579+00:00 uhci_hcd 0000:00:01.2: detected 2 ports
2023-07-24T02:46:09,854949+00:00 uhci_hcd 0000:00:01.2: irq 11, io base 0x0000c080
2023-07-24T02:46:09,857759+00:00 usb usb1: New USB device found, idVendor=1d6b, idProduct=0001, bcdDevice= 5.15
2023-07-24T02:46:09,861580+00:00 usb usb1: New USB device strings: Mfr=3, Product=2, SerialNumber=1
2023-07-24T02:46:09,864956+00:00 usb usb1: Product: UHCI Host Controller
2023-07-24T02:46:09,867054+00:00 usb usb1: Manufacturer: Linux 5.15.0-67-generic uhci_hcd
2023-07-24T02:46:09,869611+00:00 usb usb1: SerialNumber: 0000:00:01.2
2023-07-24T02:46:09,871720+00:00 hub 1-0:1.0: USB hub found
2023-07-24T02:46:09,873349+00:00 hub 1-0:1.0: 2 ports detected
2023-07-24T02:46:09,875324+00:00 i8042: PNP: PS/2 Controller [PNP0303:KBD,PNP0f13:MOU] at 0x60,0x64 irq 1,12
2023-07-24T02:46:09,879762+00:00 serio: i8042 KBD port at 0x60,0x64 irq 1
2023-07-24T02:46:09,881814+00:00 serio: i8042 AUX port at 0x60,0x64 irq 12
2023-07-24T02:46:09,884111+00:00 mousedev: PS/2 mouse device common for all mice
2023-07-24T02:46:09,886706+00:00 rtc_cmos 00:00: RTC can wake from S4
2023-07-24T02:46:09,889981+00:00 input: AT Translated Set 2 keyboard as /devices/platform/i8042/serio0/input/input1
2023-07-24T02:46:09,893572+00:00 rtc_cmos 00:00: registered as rtc0
2023-07-24T02:46:09,895797+00:00 rtc_cmos 00:00: setting system clock to 2023-07-24T02:46:10 UTC (1690166770)
2023-07-24T02:46:09,899129+00:00 rtc_cmos 00:00: alarms up to one day, y3k, 114 bytes nvram
2023-07-24T02:46:09,901756+00:00 i2c_dev: i2c /dev entries driver
2023-07-24T02:46:09,903554+00:00 device-mapper: core: CONFIG_IMA_DISABLE_HTABLE is disabled. Duplicate IMA measurements will not be recorded in the IMA log.
2023-07-24T02:46:09,908308+00:00 device-mapper: uevent: version 1.0.3
2023-07-24T02:46:09,910837+00:00 Freeing initrd memory: 31536K
2023-07-24T02:46:09,911325+00:00 device-mapper: ioctl: 4.45.0-ioctl (2021-03-22) initialised: dm-devel@redhat.com
2023-07-24T02:46:09,923565+00:00 platform eisa.0: Probing EISA bus 0
2023-07-24T02:46:09,926565+00:00 platform eisa.0: EISA: Cannot allocate resource for mainboard
2023-07-24T02:46:09,930241+00:00 platform eisa.0: Cannot allocate resource for EISA slot 1
2023-07-24T02:46:09,933770+00:00 platform eisa.0: Cannot allocate resource for EISA slot 2
2023-07-24T02:46:09,937342+00:00 platform eisa.0: Cannot allocate resource for EISA slot 3
2023-07-24T02:46:09,940410+00:00 platform eisa.0: Cannot allocate resource for EISA slot 4
2023-07-24T02:46:09,943660+00:00 platform eisa.0: Cannot allocate resource for EISA slot 5
2023-07-24T02:46:09,946744+00:00 platform eisa.0: Cannot allocate resource for EISA slot 6
2023-07-24T02:46:09,949452+00:00 platform eisa.0: Cannot allocate resource for EISA slot 7
2023-07-24T02:46:09,952171+00:00 platform eisa.0: Cannot allocate resource for EISA slot 8
2023-07-24T02:46:09,954857+00:00 platform eisa.0: EISA: Detected 0 cards
2023-07-24T02:46:09,956968+00:00 intel_pstate: CPU model not supported
2023-07-24T02:46:09,959488+00:00 ledtrig-cpu: registered to indicate activity on CPUs
2023-07-24T02:46:09,962175+00:00 drop_monitor: Initializing network drop monitor service
2023-07-24T02:46:09,965028+00:00 NET: Registered PF_INET6 protocol family
2023-07-24T02:46:09,991046+00:00 Segment Routing with IPv6
2023-07-24T02:46:09,993520+00:00 In-situ OAM (IOAM) with IPv6
2023-07-24T02:46:09,996198+00:00 NET: Registered PF_PACKET protocol family
2023-07-24T02:46:10,000816+00:00 Key type dns_resolver registered
2023-07-24T02:46:10,006801+00:00 No MBM correction factor available
2023-07-24T02:46:10,009882+00:00 IPI shorthand broadcast: enabled
2023-07-24T02:46:10,012781+00:00 sched_clock: Marking stable (1672660410, 340094711)->(2357110190, -344355069)
2023-07-24T02:46:10,018483+00:00 registered taskstats version 1
2023-07-24T02:46:10,021088+00:00 Loading compiled-in X.509 certificates
2023-07-24T02:46:10,024608+00:00 Loaded X.509 cert 'Build time autogenerated kernel key: 4919d01b97f8f8ece5362917619ef42f1d265e85'
2023-07-24T02:46:10,029977+00:00 Loaded X.509 cert 'Canonical Ltd. Live Patch Signing: 14df34d1a87cf37625abec039ef2bf521249b969'
2023-07-24T02:46:10,034766+00:00 Loaded X.509 cert 'Canonical Ltd. Kernel Module Signing: 88f752e560a1e0737e31163a466ad7b70a850c19'
2023-07-24T02:46:10,039165+00:00 blacklist: Loading compiled-in revocation X.509 certificates
2023-07-24T02:46:10,041995+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing: 61482aa2830d0ab2ad5af10b7250da9033ddcef0'
2023-07-24T02:46:10,046105+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (2017): 242ade75ac4a15e50d50c84b0d45ff3eae707a03'
2023-07-24T02:46:10,050451+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (ESM 2018): 365188c1d374d6b07c3c8f240f8ef722433d6a8b'
2023-07-24T02:46:10,054939+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (2019): c0746fd6c5da3ae827864651ad66ae47fe24b3e8'
2023-07-24T02:46:10,059290+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (2021 v1): a8d54bbb3825cfb94fa13c9f8a594a195c107b8d'
2023-07-24T02:46:10,063707+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (2021 v2): 4cf046892d6fd3c9a5b03f98d845f90851dc6a8c'
2023-07-24T02:46:10,068157+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (2021 v3): 100437bb6de6e469b581e61cd66bce3ef4ed53af'
2023-07-24T02:46:10,072613+00:00 Loaded X.509 cert 'Canonical Ltd. Secure Boot Signing (Ubuntu Core 2019): c1d57b8f6b743f23ee41f4f7ee292f06eecadfb9'
2023-07-24T02:46:10,079922+00:00 zswap: loaded using pool lzo/zbud
2023-07-24T02:46:10,083009+00:00 Key type .fscrypt registered
2023-07-24T02:46:10,084764+00:00 Key type fscrypt-provisioning registered
2023-07-24T02:46:10,100782+00:00 Key type encrypted registered
2023-07-24T02:46:10,103442+00:00 AppArmor: AppArmor sha1 policy hashing enabled
2023-07-24T02:46:10,106835+00:00 ima: No TPM chip found, activating TPM-bypass!
2023-07-24T02:46:10,110513+00:00 Loading compiled-in module X.509 certificates
2023-07-24T02:46:10,114715+00:00 Loaded X.509 cert 'Build time autogenerated kernel key: 4919d01b97f8f8ece5362917619ef42f1d265e85'
2023-07-24T02:46:10,120815+00:00 ima: Allocated hash algorithm: sha1
2023-07-24T02:46:10,123511+00:00 ima: No architecture policies found
2023-07-24T02:46:10,126220+00:00 evm: Initialising EVM extended attributes:
2023-07-24T02:46:10,129005+00:00 evm: security.selinux
2023-07-24T02:46:10,130506+00:00 evm: security.SMACK64
2023-07-24T02:46:10,132041+00:00 evm: security.SMACK64EXEC
2023-07-24T02:46:10,133684+00:00 evm: security.SMACK64TRANSMUTE
2023-07-24T02:46:10,135483+00:00 evm: security.SMACK64MMAP
2023-07-24T02:46:10,137135+00:00 evm: security.apparmor
2023-07-24T02:46:10,138720+00:00 evm: security.ima
2023-07-24T02:46:10,140093+00:00 evm: security.capability
2023-07-24T02:46:10,141710+00:00 evm: HMAC attrs: 0x1
2023-07-24T02:46:10,143699+00:00 PM:   Magic number: 15:255:764
2023-07-24T02:46:10,145542+00:00 event_source breakpoint: hash matches
2023-07-24T02:46:10,148638+00:00 RAS: Correctable Errors collector initialized.
2023-07-24T02:46:10,154388+00:00 Freeing unused decrypted memory: 2036K
2023-07-24T02:46:10,158854+00:00 Freeing unused kernel image (initmem) memory: 3240K
2023-07-24T02:46:10,176140+00:00 Write protecting the kernel read-only data: 30720k
2023-07-24T02:46:10,183015+00:00 Freeing unused kernel image (text/rodata gap) memory: 2036K
2023-07-24T02:46:10,189783+00:00 Freeing unused kernel image (rodata/data gap) memory: 1468K
2023-07-24T02:46:10,216143+00:00 usb 1-1: new full-speed USB device number 2 using uhci_hcd
2023-07-24T02:46:10,258923+00:00 x86/mm: Checked W+X mappings: passed, no W+X pages found.
2023-07-24T02:46:10,263398+00:00 x86/mm: Checking user space page tables
2023-07-24T02:46:10,313648+00:00 x86/mm: Checked W+X mappings: passed, no W+X pages found.
2023-07-24T02:46:10,318134+00:00 Run /init as init process
2023-07-24T02:46:10,320723+00:00   with arguments:
2023-07-24T02:46:10,320725+00:00     /init
2023-07-24T02:46:10,320726+00:00   with environment:
2023-07-24T02:46:10,320728+00:00     HOME=/
2023-07-24T02:46:10,320729+00:00     TERM=linux
2023-07-24T02:46:10,320730+00:00     BOOT_IMAGE=/boot/vmlinuz-5.15.0-67-generic
2023-07-24T02:46:10,404759+00:00 usb 1-1: New USB device found, idVendor=0627, idProduct=0001, bcdDevice= 0.00
2023-07-24T02:46:10,410971+00:00 usb 1-1: New USB device strings: Mfr=1, Product=3, SerialNumber=5
2023-07-24T02:46:10,415519+00:00 usb 1-1: Product: QEMU USB Tablet
2023-07-24T02:46:10,418333+00:00 usb 1-1: Manufacturer: QEMU
2023-07-24T02:46:10,420849+00:00 usb 1-1: SerialNumber: 42
2023-07-24T02:46:10,461358+00:00 hid: raw HID events driver (C) Jiri Kosina
2023-07-24T02:46:10,476111+00:00 usbcore: registered new interface driver usbhid
2023-07-24T02:46:10,476735+00:00 input: VirtualPS/2 VMware VMMouse as /devices/platform/i8042/serio1/input/input4
2023-07-24T02:46:10,479370+00:00 virtio_blk virtio1: [vda] 629145600 512-byte logical blocks (322 GB/300 GiB)
2023-07-24T02:46:10,481803+00:00 usbhid: USB HID core driver
2023-07-24T02:46:10,496084+00:00 cryptd: max_cpu_qlen set to 1000
2023-07-24T02:46:10,498272+00:00 FDC 0 is a S82078B
2023-07-24T02:46:10,498393+00:00 input: VirtualPS/2 VMware VMMouse as /devices/platform/i8042/serio1/input/input3
2023-07-24T02:46:10,509955+00:00 AVX2 version of gcm_enc/dec engaged.
2023-07-24T02:46:10,512131+00:00 AES CTR mode by8 optimization enabled
2023-07-24T02:46:10,519678+00:00 virtio_net virtio0 ens3: renamed from eth0
2023-07-24T02:46:10,522402+00:00 input: QEMU QEMU USB Tablet as /devices/pci0000:00/0000:00:01.2/usb1/1-1/1-1:1.0/0003:0627:0001.0001/input/input5
2023-07-24T02:46:10,532529+00:00 hid-generic 0003:0627:0001.0001: input,hidraw0: USB HID v0.01 Mouse [QEMU QEMU USB Tablet] on usb-0000:00:01.2-1/input0
2023-07-24T02:46:10,546322+00:00 GPT:Primary header thinks Alt. header is not at the end of the disk.
2023-07-24T02:46:10,550801+00:00 GPT:4612095 != 629145599
2023-07-24T02:46:10,553113+00:00 GPT:Alternate GPT header not at the end of the disk.
2023-07-24T02:46:10,556835+00:00 GPT:4612095 != 629145599
2023-07-24T02:46:10,559156+00:00 GPT: Use GNU Parted to correct GPT errors.
2023-07-24T02:46:10,562405+00:00  vda: vda1 vda14 vda15
2023-07-24T02:46:12,084100+00:00 raid6: avx512x4 gen() 17815 MB/s
2023-07-24T02:46:12,152097+00:00 raid6: avx512x4 xor()  8435 MB/s
2023-07-24T02:46:12,220170+00:00 raid6: avx512x2 gen() 18168 MB/s
2023-07-24T02:46:12,288108+00:00 raid6: avx512x2 xor() 21559 MB/s
2023-07-24T02:46:12,356171+00:00 raid6: avx512x1 gen() 22898 MB/s
2023-07-24T02:46:12,424107+00:00 raid6: avx512x1 xor() 20856 MB/s
2023-07-24T02:46:12,492168+00:00 raid6: avx2x4   gen() 22079 MB/s
2023-07-24T02:46:12,560107+00:00 raid6: avx2x4   xor()  5386 MB/s
2023-07-24T02:46:12,628170+00:00 raid6: avx2x2   gen() 18797 MB/s
2023-07-24T02:46:12,696113+00:00 raid6: avx2x2   xor() 17522 MB/s
2023-07-24T02:46:12,764173+00:00 raid6: avx2x1   gen() 14020 MB/s
2023-07-24T02:46:12,832112+00:00 raid6: avx2x1   xor() 13023 MB/s
2023-07-24T02:46:12,908156+00:00 raid6: sse2x4   gen() 10304 MB/s
2023-07-24T02:46:12,976111+00:00 raid6: sse2x4   xor()  6602 MB/s
2023-07-24T02:46:13,044179+00:00 raid6: sse2x2   gen() 11303 MB/s
2023-07-24T02:46:13,112113+00:00 raid6: sse2x2   xor()  6655 MB/s
2023-07-24T02:46:13,180162+00:00 raid6: sse2x1   gen() 10202 MB/s
2023-07-24T02:46:13,248105+00:00 raid6: sse2x1   xor()  5254 MB/s
2023-07-24T02:46:13,251168+00:00 raid6: using algorithm avx512x1 gen() 22898 MB/s
2023-07-24T02:46:13,255291+00:00 raid6: .... xor() 20856 MB/s, rmw enabled
2023-07-24T02:46:13,258974+00:00 raid6: using avx512x2 recovery algorithm
2023-07-24T02:46:13,264817+00:00 xor: automatically using best checksumming function   avx       
2023-07-24T02:46:13,269421+00:00 async_tx: api initialized (async)
2023-07-24T02:46:13,428650+00:00 Btrfs loaded, crc32c=crc32c-intel, zoned=yes, fsverity=yes
2023-07-24T02:46:13,651429+00:00 EXT4-fs (vda1): mounted filesystem with ordered data mode. Opts: (null). Quota mode: none.
2023-07-24T02:46:14,464156+00:00 systemd[1]: Inserted module 'autofs4'
2023-07-24T02:46:14,558783+00:00 systemd[1]: systemd 249.11-0ubuntu3.7 running in system mode (+PAM +AUDIT +SELINUX +APPARMOR +IMA +SMACK +SECCOMP +GCRYPT +GNUTLS +OPENSSL +ACL +BLKID +CURL +ELFUTILS +FIDO2 +IDN2 -IDN +IPTC +KMOD +LIBCRYPTSETUP +LIBFDISK +PCRE2 -PWQUALITY -P11KIT -QRENCODE +BZIP2 +LZ4 +XZ +ZLIB +ZSTD -XKBCOMMON +UTMP +SYSVINIT default-hierarchy=unified)
2023-07-24T02:46:14,584440+00:00 systemd[1]: Detected virtualization kvm.
2023-07-24T02:46:14,587591+00:00 systemd[1]: Detected architecture x86-64.
2023-07-24T02:46:14,607187+00:00 systemd[1]: Hostname set to <ubuntu>.
2023-07-24T02:46:14,657680+00:00 systemd[1]: Initializing machine ID from VM UUID.
2023-07-24T02:46:14,664574+00:00 systemd[1]: Installed transient /etc/machine-id file.
2023-07-24T02:46:15,442913+00:00 systemd[1]: Queued start job for default target Graphical Interface.
2023-07-24T02:46:15,450083+00:00 systemd[1]: Created slice Slice /system/modprobe.
2023-07-24T02:46:15,460130+00:00 systemd[1]: Created slice Slice /system/serial-getty.
2023-07-24T02:46:15,468904+00:00 systemd[1]: Created slice Slice /system/systemd-fsck.
2023-07-24T02:46:15,476567+00:00 systemd[1]: Created slice User and Session Slice.
2023-07-24T02:46:15,482895+00:00 systemd[1]: Started Forward Password Requests to Wall Directory Watch.
2023-07-24T02:46:15,489755+00:00 systemd[1]: Set up automount Arbitrary Executable File Formats File System Automount Point.
2023-07-24T02:46:15,497011+00:00 systemd[1]: Reached target Slice Units.
2023-07-24T02:46:15,501378+00:00 systemd[1]: Reached target Mounting snaps.
2023-07-24T02:46:15,505623+00:00 systemd[1]: Reached target Swaps.
2023-07-24T02:46:15,509072+00:00 systemd[1]: Reached target Local Verity Protected Volumes.
2023-07-24T02:46:15,514254+00:00 systemd[1]: Listening on Device-mapper event daemon FIFOs.
2023-07-24T02:46:15,519455+00:00 systemd[1]: Listening on LVM2 poll daemon socket.
2023-07-24T02:46:15,523836+00:00 systemd[1]: Listening on multipathd control socket.
2023-07-24T02:46:15,528429+00:00 systemd[1]: Listening on Syslog Socket.
2023-07-24T02:46:15,532243+00:00 systemd[1]: Listening on fsck to fsckd communication Socket.
2023-07-24T02:46:15,537484+00:00 systemd[1]: Listening on initctl Compatibility Named Pipe.
2023-07-24T02:46:15,542850+00:00 systemd[1]: Listening on Journal Audit Socket.
2023-07-24T02:46:15,547185+00:00 systemd[1]: Listening on Journal Socket (/dev/log).
2023-07-24T02:46:15,551813+00:00 systemd[1]: Listening on Journal Socket.
2023-07-24T02:46:15,555857+00:00 systemd[1]: Listening on Network Service Netlink Socket.
2023-07-24T02:46:15,561506+00:00 systemd[1]: Listening on udev Control Socket.
2023-07-24T02:46:15,568627+00:00 systemd[1]: Listening on udev Kernel Socket.
2023-07-24T02:46:15,576782+00:00 systemd[1]: Mounting Huge Pages File System...
2023-07-24T02:46:15,583301+00:00 systemd[1]: Mounting POSIX Message Queue File System...
2023-07-24T02:46:15,590285+00:00 systemd[1]: Mounting Kernel Debug File System...
2023-07-24T02:46:15,596635+00:00 systemd[1]: Mounting Kernel Trace File System...
2023-07-24T02:46:15,604140+00:00 systemd[1]: Starting Journal Service...
2023-07-24T02:46:15,610287+00:00 systemd[1]: Starting Set the console keyboard layout...
2023-07-24T02:46:15,617384+00:00 systemd[1]: Starting Create List of Static Device Nodes...
2023-07-24T02:46:15,623719+00:00 systemd[1]: Starting Monitoring of LVM2 mirrors, snapshots etc. using dmeventd or progress polling...
2023-07-24T02:46:15,630423+00:00 systemd[1]: Condition check resulted in LXD - agent being skipped.
2023-07-24T02:46:15,634929+00:00 systemd[1]: Starting Load Kernel Module chromeos_pstore...
2023-07-24T02:46:15,640905+00:00 systemd[1]: Starting Load Kernel Module configfs...
2023-07-24T02:46:15,646374+00:00 systemd[1]: Starting Load Kernel Module drm...
2023-07-24T02:46:15,651381+00:00 systemd[1]: Starting Load Kernel Module efi_pstore...
2023-07-24T02:46:15,657411+00:00 systemd[1]: Starting Load Kernel Module fuse...
2023-07-24T02:46:15,664102+00:00 systemd[1]: Starting Load Kernel Module pstore_blk...
2023-07-24T02:46:15,671836+00:00 systemd[1]: Starting Load Kernel Module pstore_zone...
2023-07-24T02:46:15,679772+00:00 systemd[1]: Starting Load Kernel Module ramoops...
2023-07-24T02:46:15,685776+00:00 systemd[1]: Condition check resulted in OpenVSwitch configuration for cleanup being skipped.
2023-07-24T02:46:15,691800+00:00 systemd[1]: Starting File System Check on Root Device...
2023-07-24T02:46:15,699054+00:00 systemd[1]: Starting Load Kernel Modules...
2023-07-24T02:46:15,702759+00:00 systemd[1]: Starting Coldplug All udev Devices...
2023-07-24T02:46:15,708231+00:00 systemd[1]: Started Journal Service.
2023-07-24T02:46:15,956796+00:00 EXT4-fs (vda1): re-mounted. Opts: discard,errors=remount-ro. Quota mode: none.
2023-07-24T02:46:15,989049+00:00 alua: device handler registered
2023-07-24T02:46:15,992436+00:00 emc: device handler registered
2023-07-24T02:46:15,996959+00:00 systemd-journald[413]: Received client request to flush runtime journal.
2023-07-24T02:46:16,017738+00:00 rdac: device handler registered
2023-07-24T02:46:16,293338+00:00 loop0: detected capacity change from 0 to 129608
2023-07-24T02:46:16,295533+00:00 loop1: detected capacity change from 0 to 229272
2023-07-24T02:46:16,300509+00:00 loop2: detected capacity change from 0 to 102072
2023-07-24T02:46:17,343905+00:00 audit: type=1400 audit(1690166777.944:2): apparmor="STATUS" operation="profile_load" profile="unconfined" name="nvidia_modprobe" pid=571 comm="apparmor_parser"
2023-07-24T02:46:17,345252+00:00 audit: type=1400 audit(1690166777.948:3): apparmor="STATUS" operation="profile_load" profile="unconfined" name="nvidia_modprobe//kmod" pid=571 comm="apparmor_parser"
2023-07-24T02:46:17,348803+00:00 audit: type=1400 audit(1690166777.952:4): apparmor="STATUS" operation="profile_load" profile="unconfined" name="lsb_release" pid=570 comm="apparmor_parser"
2023-07-24T02:46:17,368863+00:00 audit: type=1400 audit(1690166777.972:5): apparmor="STATUS" operation="profile_load" profile="unconfined" name="/usr/bin/man" pid=573 comm="apparmor_parser"
2023-07-24T02:46:17,369829+00:00 audit: type=1400 audit(1690166777.972:6): apparmor="STATUS" operation="profile_load" profile="unconfined" name="man_filter" pid=573 comm="apparmor_parser"
2023-07-24T02:46:17,371365+00:00 audit: type=1400 audit(1690166777.972:7): apparmor="STATUS" operation="profile_load" profile="unconfined" name="man_groff" pid=573 comm="apparmor_parser"
2023-07-24T02:46:17,394417+00:00 audit: type=1400 audit(1690166777.996:8): apparmor="STATUS" operation="profile_load" profile="unconfined" name="tcpdump" pid=574 comm="apparmor_parser"
2023-07-24T02:46:17,461137+00:00 audit: type=1400 audit(1690166778.064:9): apparmor="STATUS" operation="profile_load" profile="unconfined" name="/usr/lib/NetworkManager/nm-dhcp-client.action" pid=572 comm="apparmor_parser"
2023-07-24T02:46:17,462808+00:00 audit: type=1400 audit(1690166778.064:10): apparmor="STATUS" operation="profile_load" profile="unconfined" name="/usr/lib/NetworkManager/nm-dhcp-helper" pid=572 comm="apparmor_parser"
2023-07-24T02:46:17,464290+00:00 audit: type=1400 audit(1690166778.068:11): apparmor="STATUS" operation="profile_load" profile="unconfined" name="/usr/lib/connman/scripts/dhclient-script" pid=572 comm="apparmor_parser"
2023-07-24T02:46:27,514190+00:00 EXT4-fs (vda1): resizing filesystem from 548091 to 78614779 blocks
2023-07-24T02:46:28,175049+00:00 EXT4-fs (vda1): resized filesystem to 78614779
2023-07-24T02:46:34,164443+00:00 loop3: detected capacity change from 0 to 8
2023-07-24T02:46:35,057373+00:00 kauditd_printk_skb: 21 callbacks suppressed
2023-07-24T02:46:35,057378+00:00 audit: type=1400 audit(1690166795.660:33): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap-update-ns.lxd" pid=909 comm="apparmor_parser"
2023-07-24T02:46:35,182975+00:00 audit: type=1400 audit(1690166795.784:34): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap.lxd.benchmark" pid=911 comm="apparmor_parser"
2023-07-24T02:46:35,212222+00:00 audit: type=1400 audit(1690166795.816:35): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap.lxd.buginfo" pid=912 comm="apparmor_parser"
2023-07-24T02:46:35,260264+00:00 audit: type=1400 audit(1690166795.864:36): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap.lxd.hook.configure" pid=915 comm="apparmor_parser"
2023-07-24T02:46:35,266303+00:00 audit: type=1400 audit(1690166795.868:37): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap.lxd.daemon" pid=914 comm="apparmor_parser"
2023-07-24T02:46:35,280149+00:00 audit: type=1400 audit(1690166795.884:38): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap.lxd.activate" pid=910 comm="apparmor_parser"
2023-07-24T02:46:35,284226+00:00 audit: type=1400 audit(1690166795.888:39): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap.lxd.check-kernel" pid=913 comm="apparmor_parser"
2023-07-24T02:46:35,289052+00:00 audit: type=1400 audit(1690166795.892:40): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap.lxd.hook.install" pid=920 comm="apparmor_parser"
2023-07-24T02:46:35,368992+00:00 audit: type=1400 audit(1690166795.972:41): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap.lxd.hook.remove" pid=921 comm="apparmor_parser"
2023-07-24T02:46:35,395776+00:00 audit: type=1400 audit(1690166795.996:42): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap.lxd.lxc-to-lxd" pid=923 comm="apparmor_parser"
2023-07-24T07:03:38,264857+00:00 kauditd_printk_skb: 8 callbacks suppressed
2023-07-24T07:03:38,264904+00:00 audit: type=1400 audit(1690182218.868:51): apparmor="STATUS" operation="profile_load" profile="unconfined" name="docker-default" pid=10854 comm="apparmor_parser"
2023-07-24T07:03:38,566836+00:00 bridge: filtering via arp/ip/ip6tables is no longer available by default. Update your scripts to load br_netfilter if you need this.
2023-07-24T07:03:38,569773+00:00 Bridge firewalling registered
2023-07-24T07:03:38,860825+00:00 Initializing XFRM netlink socket
2023-07-24T08:08:19,801415+00:00 audit: type=1400 audit(1690186100.404:52): apparmor="STATUS" operation="profile_load" profile="unconfined" name="/usr/sbin/chronyd" pid=13902 comm="apparmor_parser"
2023-07-24T23:03:24,120322+00:00 audit: type=1400 audit(1690239804.722:53): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="/usr/lib/snapd/snap-confine" pid=93445 comm="apparmor_parser"
2023-07-24T23:03:24,121522+00:00 audit: type=1400 audit(1690239804.722:54): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="/usr/lib/snapd/snap-confine//mount-namespace-capture-helper" pid=93445 comm="apparmor_parser"
2023-07-24T23:03:26,155786+00:00 loop3: detected capacity change from 0 to 8
2023-07-24T23:04:29,989766+00:00 loop3: detected capacity change from 0 to 8
2023-07-24T23:04:30,663317+00:00 audit: type=1400 audit(1690239871.262:55): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap-update-ns.lxd" pid=93854 comm="apparmor_parser"
2023-07-24T23:04:30,663853+00:00 audit: type=1400 audit(1690239871.262:56): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap.lxd.check-kernel" pid=93858 comm="apparmor_parser"
2023-07-24T23:04:30,665637+00:00 audit: type=1400 audit(1690239871.266:57): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap.lxd.activate" pid=93855 comm="apparmor_parser"
2023-07-24T23:04:30,665939+00:00 audit: type=1400 audit(1690239871.266:58): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap.lxd.buginfo" pid=93857 comm="apparmor_parser"
2023-07-24T23:04:30,666556+00:00 audit: type=1400 audit(1690239871.266:59): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap.lxd.benchmark" pid=93856 comm="apparmor_parser"
2023-07-24T23:04:30,667007+00:00 audit: type=1400 audit(1690239871.266:60): apparmor="STATUS" operation="profile_replace" profile="unconfined" name="/snap/snapd/18357/usr/lib/snapd/snap-confine" pid=93853 comm="apparmor_parser"
2023-07-24T23:04:30,692470+00:00 audit: type=1400 audit(1690239871.294:61): apparmor="STATUS" operation="profile_replace" profile="unconfined" name="/snap/snapd/18357/usr/lib/snapd/snap-confine//mount-namespace-capture-helper" pid=93853 comm="apparmor_parser"
2023-07-24T23:04:30,692771+00:00 audit: type=1400 audit(1690239871.294:62): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap.lxd.daemon" pid=93859 comm="apparmor_parser"
2023-07-24T23:04:30,693139+00:00 audit: type=1400 audit(1690239871.294:63): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap.lxd.hook.install" pid=93865 comm="apparmor_parser"
2023-07-24T23:04:30,693464+00:00 audit: type=1400 audit(1690239871.294:64): apparmor="STATUS" operation="profile_replace" info="same as current profile, skipping" profile="unconfined" name="snap.lxd.hook.remove" pid=93866 comm="apparmor_parser"
2023-07-25T10:47:21,979832+00:00 IPVS: Registered protocols (TCP, UDP, SCTP, AH, ESP)
2023-07-25T10:47:21,979884+00:00 IPVS: Connection hash table configured (size=4096, memory=32Kbytes)
2023-07-25T10:47:21,980010+00:00 IPVS: ipvs loaded.
2023-07-25T10:47:21,991143+00:00 IPVS: [rr] scheduler registered.
2023-07-25T10:47:21,997644+00:00 IPVS: [wrr] scheduler registered.
2023-07-25T10:47:22,007815+00:00 IPVS: [sh] scheduler registered.
2023-07-25T12:38:23,678185+00:00 wireguard: WireGuard 1.0.0 loaded. See www.wireguard.com for information.
2023-07-25T12:38:23,678222+00:00 wireguard: Copyright (C) 2015-2019 Jason A. Donenfeld <Jason@zx2c4.com>. All Rights Reserved.
2023-07-26T02:17:22,565844+00:00 IPv6: ADDRCONF(NETDEV_CHANGE): cali6380108b088: link becomes ready
