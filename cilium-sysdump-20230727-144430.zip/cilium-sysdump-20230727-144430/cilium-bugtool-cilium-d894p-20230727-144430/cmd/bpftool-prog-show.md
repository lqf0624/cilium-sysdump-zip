535: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2023-07-25T10:47:22+0000  uid 0
	xlated 64B  jited 41B  memlock 4096B
538: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2023-07-25T10:47:22+0000  uid 0
	xlated 64B  jited 41B  memlock 4096B
12501: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2023-07-25T12:39:58+0000  uid 0
	xlated 64B  jited 41B  memlock 4096B
12551: cgroup_device  tag e3dbd137be8d6168  gpl
	loaded_at 2023-07-25T22:21:09+0000  uid 0
	xlated 504B  jited 310B  memlock 4096B
12552: cgroup_device  tag 8b9c33f36f812014  gpl
	loaded_at 2023-07-25T22:21:09+0000  uid 0
	xlated 744B  jited 448B  memlock 4096B
12553: cgroup_skb  tag 6deef7357e7b4530  gpl
	loaded_at 2023-07-25T22:21:09+0000  uid 0
	xlated 64B  jited 55B  memlock 4096B
12554: cgroup_skb  tag 6deef7357e7b4530  gpl
	loaded_at 2023-07-25T22:21:09+0000  uid 0
	xlated 64B  jited 55B  memlock 4096B
12556: cgroup_device  tag c8b47a902f1cc68b  gpl
	loaded_at 2023-07-25T22:21:09+0000  uid 0
	xlated 464B  jited 289B  memlock 4096B
12557: cgroup_device  tag 28a890580b33b0dc  gpl
	loaded_at 2023-07-25T22:21:09+0000  uid 0
	xlated 560B  jited 352B  memlock 4096B
12558: cgroup_device  tag 0ecd07b7b633809f  gpl
	loaded_at 2023-07-25T22:21:09+0000  uid 0
	xlated 496B  jited 308B  memlock 4096B
12559: cgroup_skb  tag 6deef7357e7b4530  gpl
	loaded_at 2023-07-25T22:21:09+0000  uid 0
	xlated 64B  jited 55B  memlock 4096B
12560: cgroup_skb  tag 6deef7357e7b4530  gpl
	loaded_at 2023-07-25T22:21:09+0000  uid 0
	xlated 64B  jited 55B  memlock 4096B
12561: cgroup_device  tag e3dbd137be8d6168  gpl
	loaded_at 2023-07-25T22:21:09+0000  uid 0
	xlated 504B  jited 310B  memlock 4096B
12562: cgroup_skb  tag 6deef7357e7b4530  gpl
	loaded_at 2023-07-25T22:21:09+0000  uid 0
	xlated 64B  jited 55B  memlock 4096B
12563: cgroup_skb  tag 6deef7357e7b4530  gpl
	loaded_at 2023-07-25T22:21:09+0000  uid 0
	xlated 64B  jited 55B  memlock 4096B
12693: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2023-07-27T06:40:40+0000  uid 0
	xlated 64B  jited 41B  memlock 4096B
13458: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2023-07-27T06:44:13+0000  uid 0
	xlated 64B  jited 41B  memlock 4096B
