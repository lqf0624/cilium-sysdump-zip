ls: cannot access '/proc/1/fd/21': No such file or directory
total 0
dr-x------ 2 root root  0 Jul 27 06:44 .
dr-xr-xr-x 9 root root  0 Jul 27 06:44 ..
lrwx------ 1 root root 64 Jul 27 06:44 0 -> /dev/null
l-wx------ 1 root root 64 Jul 27 06:44 1 -> pipe:[8908423]
lrwx------ 1 root root 64 Jul 27 06:44 10 -> anon_inode:bpf-map
lrwx------ 1 root root 64 Jul 27 06:44 11 -> anon_inode:bpf-map
lrwx------ 1 root root 64 Jul 27 06:44 12 -> anon_inode:bpf-map
lrwx------ 1 root root 64 Jul 27 06:44 13 -> anon_inode:bpf-map
lrwx------ 1 root root 64 Jul 27 06:44 14 -> anon_inode:bpf-map
lrwx------ 1 root root 64 Jul 27 06:44 15 -> anon_inode:bpf-map
lrwx------ 1 root root 64 Jul 27 06:44 16 -> socket:[8910617]
lrwx------ 1 root root 64 Jul 27 06:44 17 -> socket:[8910618]
lrwx------ 1 root root 64 Jul 27 06:44 18 -> socket:[8910624]
lrwx------ 1 root root 64 Jul 27 06:44 19 -> socket:[8910625]
l-wx------ 1 root root 64 Jul 27 06:44 2 -> pipe:[8908424]
lrwx------ 1 root root 64 Jul 27 06:44 20 -> socket:[8912453]
l????????? ? ?    ?     ?            ? 21
lrwx------ 1 root root 64 Jul 27 06:44 3 -> anon_inode:[eventpoll]
lr-x------ 1 root root 64 Jul 27 06:44 4 -> pipe:[8911630]
l-wx------ 1 root root 64 Jul 27 06:44 5 -> pipe:[8911630]
lrwx------ 1 root root 64 Jul 27 06:44 6 -> socket:[8911632]
lrwx------ 1 root root 64 Jul 27 06:44 7 -> socket:[8912431]
lrwx------ 1 root root 64 Jul 27 06:44 8 -> socket:[8909660]
lrwx------ 1 root root 64 Jul 27 06:44 9 -> anon_inode:bpf-map
> Error while running 'ls -la /proc/$(pidof cilium-agent)/fd':  exit status 1

