alloc: 9.14MB (9586352 bytes)
total-alloc: 14.25MB (14940504 bytes)
sys: 24.91MB (26124455 bytes)
lookups: 0
mallocs: 81764
frees: 40657
heap-alloc: 9.14MB (9586352 bytes)
heap-sys: 14.84MB (15564800 bytes)
heap-idle: 3.23MB (3391488 bytes)
heap-in-use: 11.61MB (12173312 bytes)
heap-released: 3.10MB (3252224 bytes)
heap-objects: 41107
stack-in-use: 1.16MB (1212416 bytes)
stack-sys: 1.16MB (1212416 bytes)
stack-mspan-inuse: 161.90KB (165784 bytes)
stack-mspan-sys: 176.00KB (180224 bytes)
stack-mcache-inuse: 9.38KB (9600 bytes)
stack-mcache-sys: 16.00KB (16384 bytes)
other-sys: 1.95MB (2045961 bytes)
gc-sys: 5.31MB (5563152 bytes)
next-gc: when heap-alloc >= 9.66MB (10130800 bytes)
last-gc: 2023-07-27 06:44:13.706786938 +0000 UTC
gc-pause-total: 566.352µs
gc-pause: 106006
gc-pause-end: 1690440253706786938
num-gc: 4
num-forced-gc: 0
gc-cpu-fraction: 0.01832973073859058
enable-gc: true
debug-gc: false
