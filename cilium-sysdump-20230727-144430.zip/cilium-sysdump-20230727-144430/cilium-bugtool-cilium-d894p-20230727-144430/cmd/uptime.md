 06:44:32 up 3 days,  3:58,  0 users,  load average: 0.07, 0.24, 0.42
