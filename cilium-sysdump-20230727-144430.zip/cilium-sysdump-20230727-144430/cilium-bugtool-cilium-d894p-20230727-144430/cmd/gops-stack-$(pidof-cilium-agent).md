goroutine 68 [running]:
runtime/pprof.writeGoroutineStacks({0x2e7a900, 0xc00000e880})
	/usr/local/go/src/runtime/pprof/pprof.go:693 +0x70
runtime/pprof.writeGoroutine({0x2e7a900, 0xc00000e880}, 0xc00009c800)
	/usr/local/go/src/runtime/pprof/pprof.go:682 +0x2b
runtime/pprof.(*Profile).WriteTo(0x2a36c50, {0x2e7a900, 0xc00000e880}, 0xd)
	/usr/local/go/src/runtime/pprof/pprof.go:331 +0x14b
github.com/google/gops/agent.handle({0x7f230813ad18, 0xc00000e880}, {0xc00014e0f0, 0x1, 0x1})
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:201 +0x15d
github.com/google/gops/agent.listen()
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:145 +0x19a
created by github.com/google/gops/agent.Listen
	/go/src/github.com/cilium/cilium/vendor/github.com/google/gops/agent/agent.go:123 +0x365

goroutine 1 [select]:
github.com/cilium/cilium/pkg/backoff.(*Exponential).Wait(0xc000a1c3d8, {0x2ed2210, 0xc0002d2680})
	/go/src/github.com/cilium/cilium/pkg/backoff/backoff.go:91 +0x294
github.com/cilium/cilium/pkg/k8s.waitForNodeInformation({0x2ed2210, 0xc0002d2680}, {0x2e70de0, 0xc00069a400}, {0xc00007402e, 0x11})
	/go/src/github.com/cilium/cilium/pkg/k8s/init.go:53 +0x148
github.com/cilium/cilium/pkg/k8s.WaitForNodeInformation({0x2ed2210, 0xc0002d2680}, {0x2e70de0, 0xc00069a400})
	/go/src/github.com/cilium/cilium/pkg/k8s/init.go:238 +0x17e
github.com/cilium/cilium/daemon/cmd.NewDaemon({0x2ed2210, 0xc0002d2680}, 0xc0007a22f0, 0xc0001e0690, {0x2f33028, 0xc0001e07e0})
	/go/src/github.com/cilium/cilium/daemon/cmd/daemon.go:646 +0x210b
github.com/cilium/cilium/daemon/cmd.runDaemon()
	/go/src/github.com/cilium/cilium/daemon/cmd/daemon_main.go:1654 +0x7ce
github.com/cilium/cilium/daemon/cmd.glob..func1(0x4728280, {0x2a26314, 0x1, 0x1})
	/go/src/github.com/cilium/cilium/daemon/cmd/daemon_main.go:127 +0x3ca
github.com/spf13/cobra.(*Command).execute(0x4728280, {0xc00006e050, 0x1, 0x1})
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:860 +0x5f8
github.com/spf13/cobra.(*Command).ExecuteC(0x4728280)
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:974 +0x3bc
github.com/spf13/cobra.(*Command).Execute(...)
	/go/src/github.com/cilium/cilium/vendor/github.com/spf13/cobra/command.go:902
github.com/cilium/cilium/daemon/cmd.Execute()
	/go/src/github.com/cilium/cilium/daemon/cmd/daemon_main.go:141 +0x45
main.main()
	/go/src/github.com/cilium/cilium/daemon/main.go:16 +0x17

goroutine 6 [chan receive]:
k8s.io/klog/v2.(*loggingT).flushDaemon(0x0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/klog/v2/klog.go:1181 +0x6a
created by k8s.io/klog/v2.init.0
	/go/src/github.com/cilium/cilium/vendor/k8s.io/klog/v2/klog.go:420 +0xfb

goroutine 7 [select]:
io.(*pipe).Read(0xc0000dc840, {0xc000380000, 0x1000, 0x1})
	/usr/local/go/src/io/pipe.go:57 +0xb7
io.(*PipeReader).Read(0x0, {0xc000380000, 0x0, 0x0})
	/usr/local/go/src/io/pipe.go:134 +0x25
bufio.(*Scanner).Scan(0xc0000c6f28)
	/usr/local/go/src/bufio/scan.go:215 +0x865
github.com/sirupsen/logrus.(*Entry).writerScanner(0x0, 0xc00000e920, 0xc00034da70)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:59 +0xa5
created by github.com/sirupsen/logrus.(*Entry).WriterLevel
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:51 +0x3d6

goroutine 8 [select]:
io.(*pipe).Read(0xc0000dc8a0, {0xc00011e000, 0x1000, 0x1})
	/usr/local/go/src/io/pipe.go:57 +0xb7
io.(*PipeReader).Read(0x0, {0xc00011e000, 0x0, 0x0})
	/usr/local/go/src/io/pipe.go:134 +0x25
bufio.(*Scanner).Scan(0xc000124f28)
	/usr/local/go/src/bufio/scan.go:215 +0x865
github.com/sirupsen/logrus.(*Entry).writerScanner(0x0, 0xc00000e930, 0xc00034da90)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:59 +0xa5
created by github.com/sirupsen/logrus.(*Entry).WriterLevel
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:51 +0x3d6

goroutine 9 [select]:
io.(*pipe).Read(0xc0000dc900, {0xc000381000, 0x1000, 0x1})
	/usr/local/go/src/io/pipe.go:57 +0xb7
io.(*PipeReader).Read(0x0, {0xc000381000, 0x0, 0x0})
	/usr/local/go/src/io/pipe.go:134 +0x25
bufio.(*Scanner).Scan(0xc0000c7f28)
	/usr/local/go/src/bufio/scan.go:215 +0x865
github.com/sirupsen/logrus.(*Entry).writerScanner(0x0, 0xc00000e940, 0xc00034dab0)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:59 +0xa5
created by github.com/sirupsen/logrus.(*Entry).WriterLevel
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:51 +0x3d6

goroutine 10 [select]:
io.(*pipe).Read(0xc0000dc960, {0xc00038a000, 0x1000, 0x1})
	/usr/local/go/src/io/pipe.go:57 +0xb7
io.(*PipeReader).Read(0x0, {0xc00038a000, 0x0, 0x0})
	/usr/local/go/src/io/pipe.go:134 +0x25
bufio.(*Scanner).Scan(0xc0000c8f28)
	/usr/local/go/src/bufio/scan.go:215 +0x865
github.com/sirupsen/logrus.(*Entry).writerScanner(0x0, 0xc00000e950, 0xc00034dad0)
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:59 +0xa5
created by github.com/sirupsen/logrus.(*Entry).WriterLevel
	/go/src/github.com/cilium/cilium/vendor/github.com/sirupsen/logrus/writer.go:51 +0x3d6

goroutine 13 [sleep]:
time.Sleep(0x37e11d600)
	/usr/local/go/src/runtime/time.go:193 +0x12e
github.com/cilium/cilium/pkg/datapath/link.init.0.func1()
	/go/src/github.com/cilium/cilium/pkg/datapath/link/link.go:28 +0x65
created by github.com/cilium/cilium/pkg/datapath/link.init.0
	/go/src/github.com/cilium/cilium/pkg/datapath/link/link.go:21 +0x25

goroutine 81 [syscall]:
os/signal.signal_recv()
	/usr/local/go/src/runtime/sigqueue.go:169 +0x98
os/signal.loop()
	/usr/local/go/src/os/signal/signal_unix.go:24 +0x19
created by os/signal.Notify.func1.1
	/usr/local/go/src/os/signal/signal.go:151 +0x2c

goroutine 67 [chan receive]:
github.com/cilium/cilium/daemon/cmd.(*daemonCleanup).registerSigHandler.func1()
	/go/src/github.com/cilium/cilium/daemon/cmd/cleanup.go:64 +0x4f
created by github.com/cilium/cilium/daemon/cmd.(*daemonCleanup).registerSigHandler
	/go/src/github.com/cilium/cilium/daemon/cmd/cleanup.go:63 +0x145

goroutine 164 [select]:
github.com/cilium/cilium/pkg/controller.(*Controller).runController(0xc00079e240)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:262 +0xd6c
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0xb67

goroutine 28 [chan receive]:
github.com/cilium/cilium/pkg/cleanup.DeferTerminationCleanupFunction.func1()
	/go/src/github.com/cilium/cilium/pkg/cleanup/cleanup.go:19 +0x67
created by github.com/cilium/cilium/pkg/cleanup.DeferTerminationCleanupFunction
	/go/src/github.com/cilium/cilium/pkg/cleanup/cleanup.go:17 +0xa5

goroutine 168 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0xc0001eea00, 0xc000427760)
	/usr/local/go/src/sync/once.go:68 +0xd2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:59
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x0)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x7b

goroutine 169 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x0, 0x43f625)
	/usr/local/go/src/sync/once.go:68 +0xd2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:59
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0x0)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x7b

goroutine 167 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc000611b80)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:206 +0x387
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:119 +0x1bf

goroutine 162 [IO wait]:
internal/poll.runtime_pollWait(0x7f23082a8da8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:303 +0x85
internal/poll.(*pollDesc).wait(0xc0007c2580, 0xc000614000, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Read(0xc0007c2580, {0xc000614000, 0x2f49, 0x2f49})
	/usr/local/go/src/internal/poll/fd_unix.go:167 +0x25a
net.(*netFD).Read(0xc0007c2580, {0xc000614000, 0x2ee9, 0xc00014d2a0})
	/usr/local/go/src/net/fd_posix.go:56 +0x29
net.(*conn).Read(0xc000388bd0, {0xc000614000, 0xc00061405b, 0x5})
	/usr/local/go/src/net/net.go:183 +0x45
crypto/tls.(*atLeastReader).Read(0xc000bda9d8, {0xc000614000, 0x0, 0x409dcd})
	/usr/local/go/src/crypto/tls/conn.go:777 +0x3d
bytes.(*Buffer).ReadFrom(0xc0002d6278, {0x2e6b7e0, 0xc000bda9d8})
	/usr/local/go/src/bytes/buffer.go:204 +0x98
crypto/tls.(*Conn).readFromUntil(0xc0002d6000, {0x7f2307f16158, 0xc000385980}, 0x2eee)
	/usr/local/go/src/crypto/tls/conn.go:799 +0xe5
crypto/tls.(*Conn).readRecordOrCCS(0xc0002d6000, 0x0)
	/usr/local/go/src/crypto/tls/conn.go:606 +0x112
crypto/tls.(*Conn).readRecord(...)
	/usr/local/go/src/crypto/tls/conn.go:574
crypto/tls.(*Conn).Read(0xc0002d6000, {0xc000469000, 0x1000, 0xc7c580})
	/usr/local/go/src/crypto/tls/conn.go:1277 +0x16f
bufio.(*Reader).Read(0xc0001b1200, {0xc000436200, 0x9, 0xc8a542})
	/usr/local/go/src/bufio/bufio.go:227 +0x1b4
io.ReadAtLeast({0x2e6b620, 0xc0001b1200}, {0xc000436200, 0x9, 0x9}, 0x9)
	/usr/local/go/src/io/io.go:328 +0x9a
io.ReadFull(...)
	/usr/local/go/src/io/io.go:347
golang.org/x/net/http2.readFrameHeader({0xc000436200, 0x9, 0xc001bd5a70}, {0x2e6b620, 0xc0001b1200})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:237 +0x6e
golang.org/x/net/http2.(*Framer).ReadFrame(0xc0004361c0)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/frame.go:498 +0x95
golang.org/x/net/http2.(*clientConnReadLoop).run(0xc00010ff98)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2101 +0x130
golang.org/x/net/http2.(*ClientConn).readLoop(0xc000210000)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1997 +0x6f
created by golang.org/x/net/http2.(*Transport).newClientConn
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:725 +0xac5

goroutine 89 [select]:
github.com/cilium/cilium/pkg/controller.(*Controller).runController(0xc0006f5b00)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:262 +0xd6c
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0xb67

goroutine 93 [select]:
github.com/cilium/cilium/pkg/node/manager.(*Manager).backgroundSync(0xc0000d1520)
	/go/src/github.com/cilium/cilium/pkg/node/manager/manager.go:342 +0x2a7
created by github.com/cilium/cilium/pkg/node/manager.NewManager
	/go/src/github.com/cilium/cilium/pkg/node/manager/manager.go:228 +0x747

goroutine 94 [chan receive]:
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run.func1()
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:235 +0x7e
sync.(*Once).doSlow(0x0, 0x43f625)
	/usr/local/go/src/sync/once.go:68 +0xd2
sync.(*Once).Do(...)
	/usr/local/go/src/sync/once.go:59
github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).run(0xc000834160)
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:233 +0x45
created by github.com/cilium/cilium/pkg/eventqueue.(*EventQueue).Run
	/go/src/github.com/cilium/cilium/pkg/eventqueue/eventqueue.go:229 +0x7b

goroutine 170 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc00079c150, 0x0)
	/usr/local/go/src/runtime/sema.go:513 +0x13d
sync.(*Cond).Wait(0x0)
	/usr/local/go/src/sync/cond.go:56 +0x8c
github.com/cilium/cilium/pkg/policy.(*SelectorCache).handleUserNotifications(0xc0001ffd50)
	/go/src/github.com/cilium/cilium/pkg/policy/selectorcache.go:255 +0xec
created by github.com/cilium/cilium/pkg/policy.NewSelectorCache
	/go/src/github.com/cilium/cilium/pkg/policy/selectorcache.go:292 +0x130

goroutine 171 [select]:
github.com/cilium/cilium/pkg/trigger.(*Trigger).waiter(0xc000611c20)
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:206 +0x387
created by github.com/cilium/cilium/pkg/trigger.NewTrigger
	/go/src/github.com/cilium/cilium/pkg/trigger/trigger.go:119 +0x1bf

goroutine 173 [select]:
github.com/cilium/cilium/pkg/controller.(*Controller).runController(0xc0009c2900)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:262 +0xd6c
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0xb67

goroutine 174 [chan receive]:
github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).k8sServiceHandler(0xc00069a400)
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/watcher.go:533 +0xe5
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).RunK8sServiceHandler
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/watcher.go:542 +0x5b

goroutine 175 [IO wait]:
internal/poll.runtime_pollWait(0x7f23082a8f88, 0x72)
	/usr/local/go/src/runtime/netpoll.go:303 +0x85
internal/poll.(*pollDesc).wait(0xc0004a4800, 0x416a0f, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc0004a4800)
	/usr/local/go/src/internal/poll/fd_unix.go:402 +0x22c
net.(*netFD).accept(0xc0004a4800)
	/usr/local/go/src/net/fd_unix.go:173 +0x35
net.(*UnixListener).accept(0xc000a2c088)
	/usr/local/go/src/net/unixsock_posix.go:167 +0x1c
net.(*UnixListener).Accept(0xc0009c7470)
	/usr/local/go/src/net/unixsock.go:260 +0x3d
google.golang.org/grpc.(*Server).Serve(0xc0006d3180, {0x2eb4f90, 0xc0009c7470})
	/go/src/github.com/cilium/cilium/vendor/google.golang.org/grpc/server.go:779 +0x362
github.com/cilium/cilium/pkg/envoy.startXDSGRPCServer.func1()
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:51 +0xb1
created by github.com/cilium/cilium/pkg/envoy.startXDSGRPCServer
	/go/src/github.com/cilium/cilium/pkg/envoy/grpc.go:49 +0x2d5

goroutine 176 [IO wait]:
internal/poll.runtime_pollWait(0x7f23082a9078, 0x72)
	/usr/local/go/src/runtime/netpoll.go:303 +0x85
internal/poll.(*pollDesc).wait(0xc0004a4a00, 0x0, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc0004a4a00)
	/usr/local/go/src/internal/poll/fd_unix.go:402 +0x22c
net.(*netFD).accept(0xc0004a4a00)
	/usr/local/go/src/net/fd_unix.go:173 +0x35
net.(*UnixListener).accept(0x0)
	/usr/local/go/src/net/unixsock_posix.go:167 +0x1c
net.(*UnixListener).AcceptUnix(0xc0009c7a10)
	/usr/local/go/src/net/unixsock.go:247 +0x3d
github.com/cilium/cilium/pkg/envoy.StartAccessLogServer.func1()
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:66 +0x47
created by github.com/cilium/cilium/pkg/envoy.StartAccessLogServer
	/go/src/github.com/cilium/cilium/pkg/envoy/accesslog_server.go:62 +0x665

goroutine 177 [select]:
github.com/cilium/cilium/pkg/controller.(*Controller).runController(0xc0009c3200)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:262 +0xd6c
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0xb67

goroutine 180 [IO wait]:
internal/poll.runtime_pollWait(0x7f23082a8cb8, 0x72)
	/usr/local/go/src/runtime/netpoll.go:303 +0x85
internal/poll.(*pollDesc).wait(0xc0004a4c80, 0xc0009fa800, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).ReadMsg(0xc0004a4c80, {0xc0009fa800, 0x200, 0x200}, {0xc0009d8990, 0x2c, 0x2c}, 0xc00009c800)
	/usr/local/go/src/internal/poll/fd_unix.go:250 +0x31c
net.(*netFD).readMsg(0xc0004a4c80, {0xc0009fa800, 0xc, 0x0}, {0xc0009d8990, 0xffffffffffffffff, 0x0}, 0x0)
	/usr/local/go/src/net/fd_posix.go:68 +0x37
net.(*UDPConn).readMsg(0x4750640, {0xc0009fa800, 0x4d32d3, 0x7f23082a8cb8}, {0xc0009d8990, 0x40d094, 0xc000a22b90})
	/usr/local/go/src/net/udpsock_posix.go:62 +0x45
net.(*UDPConn).ReadMsgUDP(0xc000388cf0, {0xc0009fa800, 0xc00061e960, 0x0}, {0xc0009d8990, 0xc000a22bf0, 0x40d3e7})
	/usr/local/go/src/net/udpsock.go:144 +0x3c
github.com/cilium/cilium/pkg/fqdn/dnsproxy.(*sessionUDPFactory).ReadRequest(0xc000388cf0, 0xc000388cf0)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/udp.go:163 +0x5f
github.com/miekg/dns.(*Server).readUDP(0xc0007fe780, 0xc000388cf0, 0xc0006506e0)
	/go/src/github.com/cilium/cilium/vendor/github.com/miekg/dns/server.go:632 +0xed
github.com/miekg/dns.defaultReader.ReadUDP({0xa22c80}, 0x2e7a8a0, 0xc0006506e0)
	/go/src/github.com/cilium/cilium/vendor/github.com/miekg/dns/server.go:154 +0x19
github.com/miekg/dns.(*Server).serveUDP(0xc0007fe780, 0xc000388cf0)
	/go/src/github.com/cilium/cilium/vendor/github.com/miekg/dns/server.go:460 +0x18c
github.com/miekg/dns.(*Server).ActivateAndServe(0xc0007fe780)
	/go/src/github.com/cilium/cilium/vendor/github.com/miekg/dns/server.go:329 +0x13f
github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy.func1(0xc0007fe780)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:431 +0x8b
created by github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:426 +0xa25

goroutine 181 [IO wait]:
internal/poll.runtime_pollWait(0x7f23082a8e98, 0x72)
	/usr/local/go/src/runtime/netpoll.go:303 +0x85
internal/poll.(*pollDesc).wait(0xc0004a4c00, 0x0, 0x0)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:84 +0x32
internal/poll.(*pollDesc).waitRead(...)
	/usr/local/go/src/internal/poll/fd_poll_runtime.go:89
internal/poll.(*FD).Accept(0xc0004a4c00)
	/usr/local/go/src/internal/poll/fd_unix.go:402 +0x22c
net.(*netFD).accept(0xc0004a4c00)
	/usr/local/go/src/net/fd_unix.go:173 +0x35
net.(*TCPListener).accept(0xc0007a0810)
	/usr/local/go/src/net/tcpsock_posix.go:140 +0x28
net.(*TCPListener).Accept(0xc0007a0810)
	/usr/local/go/src/net/tcpsock.go:262 +0x3d
github.com/miekg/dns.(*Server).serveTCP(0xc0007fe870, {0x2eb4f60, 0xc0007a0810})
	/go/src/github.com/cilium/cilium/vendor/github.com/miekg/dns/server.go:417 +0x14e
github.com/miekg/dns.(*Server).ActivateAndServe(0xc0007fe870)
	/go/src/github.com/cilium/cilium/vendor/github.com/miekg/dns/server.go:335 +0x1a5
github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy.func1(0xc0007fe870)
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:431 +0x8b
created by github.com/cilium/cilium/pkg/fqdn/dnsproxy.StartDNSProxy
	/go/src/github.com/cilium/cilium/pkg/fqdn/dnsproxy/proxy.go:426 +0xa25

goroutine 212 [select]:
github.com/cilium/cilium/pkg/controller.(*Controller).runController(0xc000658ea0)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:262 +0xd6c
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0xb67

goroutine 241 [select]:
golang.org/x/net/http2.(*clientStream).writeRequest(0xc000aa4300, 0xc000a9aa00)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1323 +0xaa8
golang.org/x/net/http2.(*clientStream).doRequest(0xc0003a9768, 0xc0003a9778)
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1185 +0x1e
created by golang.org/x/net/http2.(*ClientConn).RoundTrip
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:1114 +0x30f

goroutine 46 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc0009e5748, 0x1)
	/usr/local/go/src/runtime/sema.go:513 +0x13d
sync.(*Cond).Wait(0xc00006e8c0)
	/usr/local/go/src/sync/cond.go:56 +0x8c
k8s.io/client-go/tools/cache.(*DeltaFIFO).Pop(0xc0009e5720, 0xc000680b80)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/delta_fifo.go:527 +0x233
k8s.io/client-go/tools/cache.(*controller).processLoop(0xc0009fc1b0)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:183 +0x36
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x7f23081727c8)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:155 +0x67
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xf8dbe8, {0x2e7a460, 0xc0009e64b0}, 0x1, 0xc0000c4180)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:156 +0xb6
k8s.io/apimachinery/pkg/util/wait.JitterUntil(0xc0009fc218, 0x3b9aca00, 0x0, 0x0, 0x7f2307f1c828)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:133 +0x89
k8s.io/apimachinery/pkg/util/wait.Until(...)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:90
k8s.io/client-go/tools/cache.(*controller).Run(0xc0009fc1b0, 0xc0000c4180)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:154 +0x2fb
created by github.com/cilium/cilium/pkg/k8s/watchers.(*K8sWatcher).NodesInit.func1
	/go/src/github.com/cilium/cilium/pkg/k8s/watchers/node.go:97 +0x426

goroutine 192 [chan receive]:
k8s.io/client-go/tools/cache.(*controller).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:130 +0x28
created by k8s.io/client-go/tools/cache.(*controller).Run
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/controller.go:129 +0x105

goroutine 225 [select]:
k8s.io/client-go/tools/cache.(*Reflector).watchHandler(0xc000436540, {0x0, 0x0, 0x4750640}, {0x2ea20d8, 0xc0005c0300}, 0xc000b01d18, 0xc000205020, 0xc0000c4180)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:469 +0x1b6
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch(0xc000436540, 0xc0000c4180)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:429 +0x696
k8s.io/client-go/tools/cache.(*Reflector).Run.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:221 +0x26
k8s.io/apimachinery/pkg/util/wait.BackoffUntil.func1(0x7f23081727c8)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:155 +0x67
k8s.io/apimachinery/pkg/util/wait.BackoffUntil(0xc00040f5c0, {0x2e7a440, 0xc0000c3720}, 0x1, 0xc0000c4180)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:156 +0xb6
k8s.io/client-go/tools/cache.(*Reflector).Run(0xc000436540, 0xc0000c4180)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:220 +0x1f8
k8s.io/apimachinery/pkg/util/wait.(*Group).StartWithChannel.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:56 +0x22
k8s.io/apimachinery/pkg/util/wait.(*Group).Start.func1()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:73 +0x5a
created by k8s.io/apimachinery/pkg/util/wait.(*Group).Start
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/wait/wait.go:71 +0x88

goroutine 48 [select]:
k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch.func2()
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:374 +0x12d
created by k8s.io/client-go/tools/cache.(*Reflector).ListAndWatch
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/tools/cache/reflector.go:368 +0x378

goroutine 52 [select]:
github.com/cilium/cilium/pkg/controller.(*Controller).runController(0xc0005ba5a0)
	/go/src/github.com/cilium/cilium/pkg/controller/controller.go:262 +0xd6c
created by github.com/cilium/cilium/pkg/controller.(*Manager).updateController
	/go/src/github.com/cilium/cilium/pkg/controller/manager.go:111 +0xb67

goroutine 53 [sync.Cond.Wait]:
sync.runtime_notifyListWait(0xc000aa4348, 0x0)
	/usr/local/go/src/runtime/sema.go:513 +0x13d
sync.(*Cond).Wait(0xc000aa4338)
	/usr/local/go/src/sync/cond.go:56 +0x8c
golang.org/x/net/http2.(*pipe).Read(0xc000aa4330, {0xc0005f405c, 0x4, 0x4})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/pipe.go:76 +0xeb
golang.org/x/net/http2.transportResponseBody.Read({0x0}, {0xc0005f405c, 0x40ae2a, 0x2634ee0})
	/go/src/github.com/cilium/cilium/vendor/golang.org/x/net/http2/transport.go:2384 +0x85
io.ReadAtLeast({0x7f2307f19b58, 0xc000aa4300}, {0xc0005f405c, 0x4, 0x4}, 0x4)
	/usr/local/go/src/io/io.go:328 +0x9a
k8s.io/apimachinery/pkg/util/framer.(*lengthDelimitedFrameReader).Read(0xc0005d21f8, {0xc000b82000, 0x400, 0x400})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/util/framer/framer.go:76 +0x7e
k8s.io/apimachinery/pkg/runtime/serializer/streaming.(*decoder).Decode(0xc0005d4140, 0x0, {0x2ea1f20, 0xc0005c0340})
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/runtime/serializer/streaming/streaming.go:77 +0xa7
k8s.io/client-go/rest/watch.(*Decoder).Decode(0xc0005be140)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/client-go/rest/watch/decoder.go:49 +0x4f
k8s.io/apimachinery/pkg/watch.(*StreamWatcher).receive(0xc0005c0300)
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:105 +0x11c
created by k8s.io/apimachinery/pkg/watch.NewStreamWatcher
	/go/src/github.com/cilium/cilium/vendor/k8s.io/apimachinery/pkg/watch/streamwatcher.go:76 +0x135
