USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root         131  3.0  0.0 709384  6496 ?        Rsl  06:44   0:00 cilium-bugtool --archiveType=gz
root         155  0.0  0.0   5900  3044 ?        R    06:44   0:00  \_ ps auxfw
root         158  0.0  0.0   4784   768 ?        R    06:44   0:00  \_ ss -t -p -a -i -s
root         159  0.0  0.0    360     4 ?        R    06:44   0:00  \_ [ss]
root         161  0.0  0.0   3984  2932 ?        R    06:44   0:00  \_ bash -c tc qdisc show
root         162  0.0  0.0   1544     4 ?        R    06:44   0:00  \_ bash -c uname -a
root           1  1.2  0.4 783172 66816 ?        Ssl  06:44   0:00 cilium-agent --config-dir=/tmp/cilium/config-map
