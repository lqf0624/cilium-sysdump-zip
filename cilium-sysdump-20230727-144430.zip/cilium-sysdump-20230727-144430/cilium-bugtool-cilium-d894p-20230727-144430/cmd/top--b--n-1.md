top - 06:44:33 up 3 days,  3:58,  0 users,  load average: 0.63, 0.35, 0.45
Tasks:  10 total,   8 running,   2 sleeping,   0 stopped,   0 zombie
%Cpu(s): 21.8 us, 37.0 sy,  0.0 ni, 41.2 id,  0.0 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :  15622.6 total,   9653.1 free,    643.0 used,   5326.4 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.  14645.3 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    206 root      20   0    3204    860    756 R  40.0   0.0   0:00.06 bpftool
    228 root      20   0    3204    792    688 R  33.3   0.0   0:00.05 bpftool
    269 root      20   0    2660    516    452 R  26.7   0.0   0:00.04 cat
    274 root      20   0  768552  45316  32716 R  26.7   0.3   0:00.04 cilium
    276 root      20   0  768296  35940  28580 R  26.7   0.2   0:00.04 cilium
    131 root      20   0  709640   8136   5608 S  13.3   0.1   0:00.05 cilium-+
    275 root      20   0  768296  38776  30868 R  13.3   0.2   0:00.02 cilium
    296 root      20   0  766696  33000  26360 R   6.7   0.2   0:00.01 cilium
      1 root      20   0  783172  67068  47852 S   0.0   0.4   0:00.25 cilium-+
    163 root      20   0    5972   3232   2812 R   0.0   0.0   0:00.00 top
