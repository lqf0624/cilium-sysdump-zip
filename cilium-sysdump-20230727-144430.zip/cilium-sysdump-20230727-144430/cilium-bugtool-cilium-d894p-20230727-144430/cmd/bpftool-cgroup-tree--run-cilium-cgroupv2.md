CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    12551    device          multi                          
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    12560    ingress         multi                          
    12559    egress          multi                          
    12558    device          multi                          
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    12563    ingress         multi                          
    12562    egress          multi                          
    12561    device          multi                          
/run/cilium/cgroupv2/system.slice/chrony.service
    12557    device          multi                          
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    12556    device          multi                          
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    12554    ingress         multi                          
    12553    egress          multi                          
    12552    device          multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod10029831_577b_4a75_a894_47f634572ed3.slice/docker-0639d750ab018191ebd2ad220edd533362e6fb51193c03d5c2a5c709aa1f9331.scope
    12693    device          multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod10029831_577b_4a75_a894_47f634572ed3.slice/docker-1a4423f764838baccce054e1329d36343dcb88c094d65f199940317bebe75916.scope
    13458    device          multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6ec7546e_31ef_4a92_aa9c_407cf2508770.slice/docker-336813ec856799a82cb4e0c9c87a4471be2e61752fa427132f952a568bd3018c.scope
    538      device          multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6ec7546e_31ef_4a92_aa9c_407cf2508770.slice/docker-5637284987d04aa748abc360585a7d85f84368449380d360adb806f868605d8e.scope
    535      device          multi                          
