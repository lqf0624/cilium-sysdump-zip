CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    9353     device          multi                          
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    9362     ingress         multi                          
    9361     egress          multi                          
    9360     device          multi                          
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    9358     ingress         multi                          
    9357     egress          multi                          
    9356     device          multi                          
/run/cilium/cgroupv2/system.slice/chrony.service
    9359     device          multi                          
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    9352     device          multi                          
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    9367     ingress         multi                          
    9366     egress          multi                          
    9365     device          multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6137345aa66885d8f876401b160522ee.slice/docker-5367e6e966bdae3a7c4e936efbd1ad1957b587b3f13ddb18e375a7c836354ac0.scope
    797      device          multi                          
    9351     device          multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod6137345aa66885d8f876401b160522ee.slice/docker-4a2ae73cb7291c15151f468d06bd5e2fe4aba4a3acf2b617f1744f87a6c29712.scope
    779      device          multi                          
    9354     device          multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod34f6084b_5501_43fd_a721_111b8c2bbb52.slice/docker-f3e2eafe31d63e203e1066becaf21d35e8ee3685dffdcf6e8aeb9673328ea74e.scope
    9496     device          multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod34f6084b_5501_43fd_a721_111b8c2bbb52.slice/docker-46cc917297b8362dfa5cfcd4152f03c55cdc671888cba2e771a7962f20287f86.scope
    9483     device          multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb105fb5986b1e3d3ab2cd3eecbb8232d.slice/docker-f7e61de0cbfa85c68e614a839302451c1ea694f1b16f40a1c6831c00b52c3f8f.scope
    9452     device          multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb105fb5986b1e3d3ab2cd3eecbb8232d.slice/docker-3e1a56679f663d4ec08db8776fa5f889d6a9dbc7719b7bbdaa6a58ef658678f1.scope
    783      device          multi                          
    9355     device          multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podedab05b459d2bea25d90211bba8c1618.slice/docker-a7cbbfcd4f4c07b6cb73038b874872401d86e3b9203e2b0f78c6177aed644db3.scope
    9490     device          multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podedab05b459d2bea25d90211bba8c1618.slice/docker-2a622bc90138e854709d369988ef61f3396e8280c615395929d6d09aff744342.scope
    772      device          multi                          
    9368     device          multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5bc722f9_8da8_4848_80a8_7639134f129e.slice/docker-14815728e388e784be3ff6f561cf90fd952ac2608ea68ff0e2613724e3a1cb6d.scope
    793      device          multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5bc722f9_8da8_4848_80a8_7639134f129e.slice/docker-e06357f3d81730104c9cc6093c60fdd1188022f0e36cfbe8e89dbff86b2f0a68.scope
    775      device          multi                          
